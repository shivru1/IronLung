# Iron Lung

A personal Android app to cut down smoking.

- **Tracker**: count today's cigarettes, see the time since the last one, crush cravings, talk to a blunt AI coach.
- **Stats**: daily chart, the 3 hours you smoke most, your top triggers.
- **Brain Dump**: say what is on your mind; the AI turns it into a headline, a mood and tasks.
- **Real Talk**: a weekly briefing that links your stress to your smoking, plus Quick Settings.

Everything is saved on the phone first, so the app is instant and works offline.
The AI parts need internet and your own API key.

---

## 1. Build it

You need a computer with **Node.js 20 or newer**. This folder is the project.
Open a terminal inside it and run the three steps below.

**Step 1. Install Expo**

```
npm install expo@latest
```

**Step 2. Install the libraries** (Expo picks the versions that fit together)

```
npx expo install react react-native expo-dev-client expo-system-ui expo-notifications expo-task-manager expo-haptics expo-secure-store expo-font expo-linear-gradient expo-status-bar expo-speech-recognition react-native-svg react-native-safe-area-context react-native-mmkv react-native-nitro-modules zustand @expo-google-fonts/inter @expo-google-fonts/barlow-condensed @expo-google-fonts/jetbrains-mono

npx expo install typescript @types/react jest jest-expo @types/jest -- --save-dev
```

**Step 3. Make the app.** Pick one way:

| Way | What to do |
| --- | --- |
| **A. Straight to your phone** (needs Android Studio and JDK 17 installed) | Turn on USB debugging on the phone, plug it in, run `npx expo run:android` |
| **B. An APK file, built in the cloud** (no Android Studio) | `npm install -g eas-cli`, then `eas login`, then `eas build --platform android --profile preview`. Download the APK from the link it prints and install it. |
| **C. Open in Android Studio** | `npx expo prebuild --platform android`, then open the new `android` folder in Android Studio and press Run |

The first build is slow. That is normal.

> **Expo Go will not work.** The app uses native parts (fast storage, speech, lock-screen buttons) that Expo Go does not have. Use one of the three ways above.

If a step prints an error, copy the error text and send it to me. I could not run these steps on the machine where the code was written (see section 8).

---

## 2. First run on the phone

1. Allow **notifications** and the **microphone** when the app asks.
2. Go to **REAL TALK**, scroll to **QUICK SETTINGS**, paste your **AI API Key**. A Gemini key (`AIza...`), an OpenAI key (`sk-...`) or a Claude key (`sk-ant-...`) all work. The line next to the box should say `SAVED · GEMINI` (or OPENAI / CLAUDE).
3. Set your **Daily Baseline** (what you smoked before), **Daily Target** and **Cost per Cigarette**.
4. **Test the lock-screen buttons first.** This is the one part I am least sure about:
   - Open the app, press Home. Pull down the notifications. Tap **+1 Smoke**. Open the app: the count should be one higher.
   - Now swipe the app away from the recent-apps list and tap **Craving Crushed** on the notification. Open the app: the craving count should be one higher.
   - If the second test fails, tell me. There are other ways to do it, but they need extra native code.

---

## 3. How to use it

| You do this | This happens |
| --- | --- |
| Tap **CRUSH CRAVING** | Counts a craving you beat, adds money saved, strong buzz |
| Tap **+1 LOG SMOKE** | Logs a cigarette with the selected trigger chip |
| Tap a **trigger chip** | That trigger is used for the next cigarette (also from the lock screen) |
| **Hold** a trigger chip | Also re-tags the last cigarette |
| Tap **-15m** | The next cigarette is logged 15 minutes back. Tap again for 30, 45 ... up to 2 hours |
| Tap **UNDO** | Removes the last cigarette |
| Type to the coach | The Blunt Coach answers. He knows today's numbers and your brain dumps |
| **Hold the mic** and talk | Records. Let go to save. A quick tap also works: tap, talk, tap again |
| Tap **TYPE INSTEAD** | Type the dump. Words already heard move into the text box |
| Tap a task | Ticks it off |
| **Hold** a dump card | Deletes it (asks first) |
| Tap **GENERATE BRIEFING** | Builds the weekly Real Talk from the last 7 finished days |
| Tap the **gear** on the Tracker | Jumps to Quick Settings |
| Phone **back** button | Returns to the Tracker |

---

## 4. The rules the app follows

- **A day starts at 04:00.** A cigarette at 1:30 at night counts for the day before.
- **Money saved.** During the day: cravings crushed × price. When the day is over: the larger of that and (baseline − cigarettes smoked) × price.
- **Target gap.** Starts as 16 waking hours ÷ daily target. The coach can change it.
- **Peak danger window.** The 3 hours in a row with the most cigarettes over the last 7 days. The phone warns you 10 minutes before it starts.
- **AI memory.** The coach sees the last 6 chat messages, today's brain dump headlines and up to 10 notes he wrote about you.
- **Weekly briefing.** Covers the 7 finished days before today. The numbers on it are worked out by the app; the AI only writes the sentences.
- **No internet or no key?** Tracking still works. Brain dumps are kept and sent to the AI later.

---

## 5. What is in this folder

```
App.tsx                 the app shell: fonts, the four tabs
index.ts                where the app starts (also wires the lock-screen buttons)
app.json                app name, package name, permissions
assets/                 app icon and notification icon
src/
  types/schema.ts       the shape of every saved document
  config/appConfig.ts   everything you may want to change (defaults, AI model names, language)
  utils/                dates (the 04:00 rule), number and time formatting, ids
  services/
    rollupEngine.ts     daily roll-up: averages, danger window, chart data
    smokeEngine.ts      logging, undo, gaps, money saved
    statsEngine.ts      numbers for the Stats screen
    realTalkEngine.ts   numbers for the weekly briefing
    aiPrompts.ts        the three AI instructions (coach, brain dump, weekly briefing)
    aiPipelines.ts      the three AI flows and what they save
    llmClient.ts        talks to Gemini, OpenAI or Claude and asks for JSON
    nativeAndroidService.ts   vibration, notifications, speech-to-text
    trackerActions.ts   log / undo / crush, shared by the screens and the lock-screen buttons
    firestoreSync.ts    optional cloud backup
    appBootstrap.ts     starts the background helpers
  storage/              fast on-phone storage (MMKV) and the secure place for the API key
  store/                the app's state and every action that changes it
  hooks/                useSmokeTracker, useStats, useBrainDump, useRealTalk, useSettings
  ui/
    theme.ts            colours, fonts, the scale that fits the design to any phone width
    icons.ts            the icons as vector shapes
    primitives.tsx      text styles, cards, badges, checkbox, task row
    screens/            the four screens
    components/         the gap gauge and the daily chart
```

Files named `*.test.ts` are checks for the logic. Run them with `npm test`.

---

## 6. Things you can change easily

| Change | Where |
| --- | --- |
| App name, package name | `app.json` |
| Starting baseline / target / price | `src/config/appConfig.ts` → `defaults` |
| AI model names | `src/config/appConfig.ts` → `ai.models` |
| Voice language (now `en-IN`) | `src/config/appConfig.ts` → `speech.language` |
| Colours and fonts | `src/ui/theme.ts` |
| How the coach talks | `src/services/aiPrompts.ts` |

---

## 7. Cloud backup (optional, off by default)

The app works fully without it. Turn it on only if you want a copy of your data in Firebase.

1. Create a project at console.firebase.google.com.
2. **Authentication** → Sign-in method → turn on **Email/Password** → add one user (your email and a password).
3. **Firestore Database** → Create database.
4. Firestore → **Rules** → paste this and publish:
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId}/{document=**} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
     }
   }
   ```
5. Project settings → copy the **Web API key** and the **Project ID**.
6. Put the four values in `src/config/appConfig.ts` → `firebase` and build again.

The phone always wins: the cloud only receives copies, and is read once when the app is installed fresh.
Do not share the project folder or the APK with the password inside.

Without cloud backup, uninstalling the app deletes all its data.

---

## 8. What was checked, and what was not

Checked on the machine where the code was written:

- The whole project passes the TypeScript compiler in strict mode: **67 files, 0 errors**.
- **391 logic tests pass**, in four different time zones (dates and the 04:00 rule, averages, danger window, money, the store, AI answer parsing, sync).
- All four screens were drawn through a browser stand-in and measured against your design export. Card edges, text lines and icons land within about 1 design pixel of the design.
- The icons are the exact outlines from your design file (two of them, the robot and the target, are redrawn from Font Awesome because the design file only had them as pictures).

Not checked, because that machine has no Node.js, no Android tools and no phone:

- The libraries were never installed, and the app was never built or run on Android.
- Calls into the libraries (Expo, React Native, MMKV, Zustand) were checked against my own notes of their APIs, not the real packages.
- The screens were never drawn by React Native itself. The stand-in used other fonts, so letter shapes and text widths in the check were not the real ones.
- Notifications, vibration, speech and the AI calls were not exercised at all.

So expect a few small fixes on the first real build. Send me the error text or a screenshot and I will fix it.

---

## 9. Credits

- Fonts: Barlow Condensed, Inter, JetBrains Mono (SIL Open Font License), loaded from the `@expo-google-fonts` packages.
- Icons: Font Awesome Free 6 (fontawesome.com), licence CC BY 4.0.
