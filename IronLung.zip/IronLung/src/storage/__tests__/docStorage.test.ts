import type { BrainDumpDoc, DailyLogDoc, SettingsDoc } from '../../types/schema';
import { DocStorage } from '../docStorage';
import type { PersistedState } from '../docStorage';
import { createMemoryKv } from '../kv';
import type { KeyValueStore } from '../kv';

const SETTINGS: SettingsDoc = {
  daily_baseline: 15,
  daily_target: 8,
  cost_per_cig_inr: 20,
  selected_trigger: 'Craving',
  updated_at: '2026-11-19T10:00:00.000+05:30',
};

const EMPTY: PersistedState = {
  settings: SETTINGS,
  dailyLogs: {},
  rollingMemory: null,
  brainDumps: {},
  briefings: {},
};

function dayLog(logicalDate: string, totalCount = 0): DailyLogDoc {
  return {
    logical_date: logicalDate,
    total_count: totalCount,
    daily_target: 8,
    daily_baseline: 15,
    cost_per_cig_inr: 20,
    smoke_entries: [],
    cravings_crushed: 0,
    money_saved_inr: 0,
    active_target_gap_mins: 120,
    todays_brain_dump_headlines: [],
    chat_buffer: [],
    is_finalized: false,
  };
}

function brainDump(id: string): BrainDumpDoc {
  return {
    id,
    logical_date: '2026-11-19',
    created_at: '2026-11-19T10:00:00.000+05:30',
    raw_transcript: 'transcript',
    ai_processed: { headline: 'Headline', mood_detected: 'Calm', category: 'Work', action_items: [] },
    ai_status: 'done',
  };
}

/** A store that also remembers which keys were written and removed. */
function recordingKv(): { kv: KeyValueStore; written: string[]; removed: string[] } {
  const inner = createMemoryKv();
  const written: string[] = [];
  const removed: string[] = [];
  const kv: KeyValueStore = {
    getString: (key) => inner.getString(key),
    getAllKeys: () => inner.getAllKeys(),
    set: (key, value) => {
      written.push(key);
      inner.set(key, value);
    },
    remove: (key) => {
      removed.push(key);
      inner.remove(key);
    },
  };
  return { kv, written, removed };
}

describe('DocStorage', () => {
  it('returns null when nothing was ever saved', () => {
    const storage = new DocStorage(createMemoryKv(), EMPTY);

    expect(storage.getItem('app')).toBeNull();
  });

  it('gives back what was saved', () => {
    const kv = createMemoryKv();
    const state: PersistedState = {
      ...EMPTY,
      dailyLogs: { '2026-11-18': dayLog('2026-11-18', 4), '2026-11-19': dayLog('2026-11-19', 2) },
      brainDumps: { d1: brainDump('d1') },
    };
    new DocStorage(kv, EMPTY).setItem('app', { state, version: 1 });

    const loaded = new DocStorage(kv, EMPTY).getItem('app');

    expect(loaded).toEqual({ state, version: 1 });
  });

  it('stores every document under its own key', () => {
    const kv = createMemoryKv();
    const state: PersistedState = {
      ...EMPTY,
      dailyLogs: { '2026-11-19': dayLog('2026-11-19') },
      brainDumps: { d1: brainDump('d1') },
    };

    new DocStorage(kv, EMPTY).setItem('app', { state, version: 1 });

    expect(kv.getAllKeys().sort()).toEqual([
      'doc:brain_dumps/d1',
      'doc:daily_logs/2026-11-19',
      'doc:settings/app',
      'meta:dirty',
      'meta:version',
    ]);
  });

  it('rewrites only the document that changed', () => {
    const { kv, written } = recordingKv();
    const storage = new DocStorage(kv, EMPTY);
    const first: PersistedState = {
      ...EMPTY,
      dailyLogs: { '2026-11-18': dayLog('2026-11-18', 4), '2026-11-19': dayLog('2026-11-19', 2) },
    };
    storage.setItem('app', { state: first, version: 1 });
    storage.clearDirtyPaths(storage.getDirtyPaths());
    written.length = 0;
    const second: PersistedState = {
      ...first,
      dailyLogs: { ...first.dailyLogs, '2026-11-19': dayLog('2026-11-19', 3) },
    };

    storage.setItem('app', { state: second, version: 1 });

    expect(written).toEqual(['doc:daily_logs/2026-11-19', 'meta:dirty']);
  });

  it('writes nothing when the same state is saved again', () => {
    const { kv, written } = recordingKv();
    const storage = new DocStorage(kv, EMPTY);
    const state: PersistedState = { ...EMPTY, dailyLogs: { '2026-11-19': dayLog('2026-11-19') } };
    storage.setItem('app', { state, version: 1 });
    written.length = 0;

    storage.setItem('app', { state: { ...state }, version: 1 });

    expect(written).toEqual([]);
  });

  it('writes nothing for unchanged documents after a reload', () => {
    const { kv, written } = recordingKv();
    const state: PersistedState = { ...EMPTY, dailyLogs: { '2026-11-19': dayLog('2026-11-19') } };
    new DocStorage(kv, EMPTY).setItem('app', { state, version: 1 });
    const reopened = new DocStorage(kv, EMPTY);
    const loaded = reopened.getItem('app');
    written.length = 0;

    reopened.setItem('app', { state: { ...(loaded?.state ?? EMPTY) }, version: 1 });

    expect(written).toEqual([]);
  });

  it('removes the key of a deleted document', () => {
    const { kv, removed } = recordingKv();
    const storage = new DocStorage(kv, EMPTY);
    const first: PersistedState = { ...EMPTY, brainDumps: { d1: brainDump('d1'), d2: brainDump('d2') } };
    storage.setItem('app', { state: first, version: 1 });

    storage.setItem('app', { state: { ...first, brainDumps: { d2: first.brainDumps.d2 as BrainDumpDoc } }, version: 1 });

    expect(removed).toEqual(['doc:brain_dumps/d1']);
    expect(storage.listDocPaths()).toEqual(['brain_dumps/d2', 'settings/app']);
  });

  it('skips a document that cannot be read and falls back to the default settings', () => {
    const kv = createMemoryKv({
      'meta:version': '1',
      'doc:daily_logs/2026-11-18': '{broken',
      'doc:daily_logs/2026-11-19': JSON.stringify(dayLog('2026-11-19', 5)),
    });

    const loaded = new DocStorage(kv, EMPTY).getItem('app');

    expect(loaded?.state.settings).toEqual(SETTINGS);
    expect(Object.keys(loaded?.state.dailyLogs ?? {})).toEqual(['2026-11-19']);
  });

  it('fills in settings fields added after the settings were saved', () => {
    const kv = createMemoryKv({
      'meta:version': '1',
      'doc:settings/app': JSON.stringify({ daily_target: 5 }),
    });

    const loaded = new DocStorage(kv, EMPTY).getItem('app');

    expect(loaded?.state.settings).toEqual({ ...SETTINGS, daily_target: 5 });
  });

  it('deletes everything it wrote', () => {
    const kv = createMemoryKv({ other: 'kept' });
    const storage = new DocStorage(kv, EMPTY);
    storage.setItem('app', { state: { ...EMPTY, brainDumps: { d1: brainDump('d1') } }, version: 1 });

    storage.removeItem('app');

    expect(kv.getAllKeys()).toEqual(['other']);
    expect(storage.getItem('app')).toBeNull();
  });
});

describe('DocStorage dirty paths', () => {
  it('remembers every written path until it is cleared', () => {
    const storage = new DocStorage(createMemoryKv(), EMPTY);
    const state: PersistedState = { ...EMPTY, dailyLogs: { '2026-11-19': dayLog('2026-11-19') } };

    storage.setItem('app', { state, version: 1 });

    expect(storage.getDirtyPaths()).toEqual(['daily_logs/2026-11-19', 'settings/app']);
  });

  it('forgets cleared paths and keeps the rest', () => {
    const storage = new DocStorage(createMemoryKv(), EMPTY);
    storage.setItem('app', {
      state: { ...EMPTY, dailyLogs: { '2026-11-19': dayLog('2026-11-19') } },
      version: 1,
    });

    storage.clearDirtyPaths(['settings/app']);

    expect(storage.getDirtyPaths()).toEqual(['daily_logs/2026-11-19']);
  });

  it('marks a deleted document as dirty so the cloud copy can be deleted too', () => {
    const storage = new DocStorage(createMemoryKv(), EMPTY);
    const first: PersistedState = { ...EMPTY, brainDumps: { d1: brainDump('d1') } };
    storage.setItem('app', { state: first, version: 1 });
    storage.clearDirtyPaths(storage.getDirtyPaths());

    storage.setItem('app', { state: { ...first, brainDumps: {} }, version: 1 });

    expect(storage.getDirtyPaths()).toEqual(['brain_dumps/d1']);
    expect(storage.readDoc('brain_dumps/d1')).toBeUndefined();
  });

  it('keeps the dirty list across restarts', () => {
    const kv = createMemoryKv();
    new DocStorage(kv, EMPTY).setItem('app', { state: EMPTY, version: 1 });

    const reopened = new DocStorage(kv, EMPTY);

    expect(reopened.getDirtyPaths()).toEqual(['settings/app']);
  });

  it('can queue every document again', () => {
    const storage = new DocStorage(createMemoryKv(), EMPTY);
    storage.setItem('app', {
      state: { ...EMPTY, dailyLogs: { '2026-11-19': dayLog('2026-11-19') } },
      version: 1,
    });
    storage.clearDirtyPaths(storage.getDirtyPaths());

    storage.markAllDirty();

    expect(storage.getDirtyPaths()).toEqual(['daily_logs/2026-11-19', 'settings/app']);
  });
});
