/**
 * Data contracts for the whole app.
 *
 * Every document that is kept on the phone, synced to Firestore or sent to the
 * AI is described here. Field names are snake_case because they are also the
 * Firestore field names.
 *
 * Dates come in two forms:
 * - "logical date": `YYYY-MM-DD`, where the day starts at 04:00 local time
 *   (see `utils/dateUtils.ts`).
 * - "timestamp": a full ISO-8601 string that includes the phone's UTC offset,
 *   for example `2026-11-19T01:30:00.000+05:30`.
 */

// ---------------------------------------------------------------------------
// Smoking
// ---------------------------------------------------------------------------

/** Every trigger the user can pick for a cigarette. */
export const TRIGGER_TYPES = [
  'Work Stress',
  'Post-Meal',
  'Boredom',
  'Social',
  'Late Night',
  'Craving',
] as const;

export type TriggerType = (typeof TRIGGER_TYPES)[number];

/** One logged cigarette. */
export interface SmokeEntry {
  id: string;
  /** When the cigarette was smoked (already moved back by `backdated_mins`). */
  timestamp: string;
  trigger: TriggerType;
  /**
   * Minutes since the previous cigarette on record, even if that one was on
   * the day before. `null` when there is no earlier cigarette.
   */
  gap_from_previous_mins: number | null;
  /** How long before "now" the user said it happened. 0 when logged live. */
  backdated_mins: number;
}

export type ChatRole = 'user' | 'assistant';

/** One line of the conversation with the Smoke Coach. */
export interface ChatMessage {
  id: string;
  role: ChatRole;
  text: string;
  timestamp: string;
}

/** The coach conversation kept on each day is capped at this many messages. */
export const CHAT_BUFFER_LIMIT = 6;

/**
 * Layer 1 of the AI context: the live state of one logical day.
 * Stored at `daily_logs/{logical_date}`.
 */
export interface DailyLogDoc {
  /** The document key, `YYYY-MM-DD`. */
  logical_date: string;
  /** Cigarettes smoked this day. Always equal to `smoke_entries.length`. */
  total_count: number;
  /** The most cigarettes the user wants to smoke this day. */
  daily_target: number;
  /** Cigarettes per day before cutting down, as it was set on this day. */
  daily_baseline: number;
  /** Price of one cigarette in rupees, as it was set on this day. */
  cost_per_cig_inr: number;
  smoke_entries: SmokeEntry[];
  /** Times the user wanted a cigarette and did not smoke. */
  cravings_crushed: number;
  /**
   * Rupees saved this day. While the day is running it counts crushed
   * cravings only; once the day is over it becomes the larger of that and the
   * cigarettes smoked under the baseline.
   */
  money_saved_inr: number;
  /** Minutes the coach currently wants the user to wait between cigarettes. */
  active_target_gap_mins: number;
  /** Headlines of today's brain dumps, so the coach knows what is on the user's mind. */
  todays_brain_dump_headlines: string[];
  /** The most recent coach conversation, capped at `CHAT_BUFFER_LIMIT` messages. */
  chat_buffer: ChatMessage[];
  /** True once the day is over and `money_saved_inr` has its final value. */
  is_finalized: boolean;
}

// ---------------------------------------------------------------------------
// Rolling memory
// ---------------------------------------------------------------------------

/** Numbers summarising the days before today. */
export interface RollingStats {
  current_daily_target: number;
  /** Average cigarettes per day over the last 7 days. `null` when no day was recorded. */
  avg_7_day: number | null;
  /** Average cigarettes per day over the last 30 days. `null` when no day was recorded. */
  avg_30_day: number | null;
  /**
   * Longest wait between two cigarettes of the same logical day in the last
   * 7 days. `null` when no day had two cigarettes.
   */
  longest_gap_7_day_mins: number | null;
  /**
   * The 3 hours of the day with the most cigarettes over the last 7 days,
   * for example `"15:00 - 18:00"`. `null` when nothing was smoked.
   */
  peak_danger_window: string | null;
  /** How often each trigger was picked in the last 7 days. */
  top_triggers_7_day: Record<TriggerType, number>;
  /** Rupees saved on every finished day so far (today is not included). */
  total_money_saved_all_time: number;
}

/** One day on a chart. */
export interface ChartPoint {
  /** Logical date, `YYYY-MM-DD`. */
  date: string;
  count: number;
  target: number;
  /** Average count over the 7 days ending on `date`. */
  rolling_7d_avg: number;
  cravings_crushed: number;
}

/** The AI keeps at most this many notes about the user. */
export const MAX_MEMORY_NOTES = 10;

/**
 * Layer 2 of the AI context: a summary of the past, rebuilt once per logical
 * day. Stored as the single document `ai_context/rolling_memory`.
 */
export interface RollingMemoryDoc {
  /** The last finished logical day this summary includes (normally yesterday). */
  last_computed_date: string;
  stats: RollingStats;
  /** Things the AI has learned about the user. At most `MAX_MEMORY_NOTES`, oldest dropped first. */
  ai_memory_notes: string[];
  /**
   * Ready-made chart data for the last 30 finished days, oldest first.
   * Days with no record are left out.
   */
  chart_cache_30_days: ChartPoint[];
}

// ---------------------------------------------------------------------------
// Brain dumps
// ---------------------------------------------------------------------------

export const MOOD_TYPES = ['Calm', 'Stressed', 'Excited', 'Tired'] as const;

export type MoodType = (typeof MOOD_TYPES)[number];

export const BRAIN_DUMP_CATEGORIES = ['Work', 'Personal', 'Idea'] as const;

export type BrainDumpCategory = (typeof BRAIN_DUMP_CATEGORIES)[number];

export interface ActionItem {
  id: string;
  task: string;
  done: boolean;
  /** Deadline as a 24-hour clock time (`HH:mm`) when the user mentioned one. */
  due_time?: string | null;
}

/** What the AI extracts from a brain dump transcript. */
export interface BrainDumpAiResult {
  /** At most 8 words. */
  headline: string;
  mood_detected: MoodType;
  category: BrainDumpCategory;
  action_items: ActionItem[];
}

/**
 * `pending`: saved on the phone, the AI has not processed it yet (no internet,
 * no API key or the request failed). `ai_processed` then holds a placeholder.
 */
export type BrainDumpAiStatus = 'pending' | 'done';

/** One spoken or typed brain dump. Stored at `brain_dumps/{id}`. */
export interface BrainDumpDoc {
  id: string;
  logical_date: string;
  created_at: string;
  raw_transcript: string;
  ai_processed: BrainDumpAiResult;
  ai_status: BrainDumpAiStatus;
}

// ---------------------------------------------------------------------------
// Real Talk weekly briefing
// ---------------------------------------------------------------------------

/** An unfinished task carried into the next week. */
export interface CarryoverTask {
  /** Same id as the action item it was copied from. */
  id: string;
  task: string;
  /** Logical date of the brain dump the task came from. */
  source_date: string;
  /** The brain dump that owns the task, so ticking it off updates one place only. */
  dump_id: string;
}

/** Numbers behind a weekly briefing. Worked out in code, never by the AI. */
export interface RealTalkStats {
  /** Recorded days in the 7-day period. */
  days_recorded: number;
  smokes_this_week: number;
  /** `null` when the week before has no recorded day. */
  smokes_last_week: number | null;
  /** Change against the week before in percent (negative means fewer). */
  change_pct: number | null;
  /** Average wait between cigarettes of the same day, in minutes. */
  avg_gap_mins: number | null;
  /** Change of `avg_gap_mins` against the week before. */
  avg_gap_delta_mins: number | null;
  /** Days on which the count stayed at or under the target. */
  days_on_target: number;
  /** The day with the most cigarettes. */
  worst_day: { date: string; count: number } | null;
  /** Average cigarettes on days with a "Stressed" brain dump. */
  stressed_days_avg: number | null;
  /** Average cigarettes on days with a "Calm" brain dump and no "Stressed" one. */
  calm_days_avg: number | null;
  /** Logical dates of the days with a "Stressed" brain dump. */
  stressed_dates: string[];
}

/** Stored at `real_talk_briefings/{week_id}`. */
export interface RealTalkBriefingDoc {
  /** ISO week of the last day of the period, for example `2026-W47`. */
  week_id: string;
  generated_at: string;
  /** First and last logical date of the 7 days the briefing covers. */
  period_start: string;
  period_end: string;
  /** Texts may mark emphasis with `**double asterisks**`. */
  smoke_trend_summary: string;
  brain_habit_correlation: string;
  next_week_micro_goal: string;
  micro_goal_reward: string;
  carryover_tasks: CarryoverTask[];
  stats: RealTalkStats;
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

/** Stored at `settings/app`. The AI API key is kept separately in secure storage. */
export interface SettingsDoc {
  /** Cigarettes per day before cutting down. */
  daily_baseline: number;
  /** Today's limit. */
  daily_target: number;
  /** Price of one cigarette in rupees. */
  cost_per_cig_inr: number;
  /** Trigger used for the next logged cigarette, including lock-screen logs. */
  selected_trigger: TriggerType;
  updated_at: string;
}
