/**
 * Everything the Tracker screen shows and does, with no logic left for the
 * view: bind the returned values to the UI and call the returned actions.
 */

import { useCallback, useEffect, useMemo, useState } from 'react';

import { APP_CONFIG } from '../config/appConfig';
import { triggerSmokeCoachAI } from '../services/aiService';
import { formatDangerWindow, isInDangerWindow, minutesUntilWindowOpens, parseDangerWindow } from '../services/dangerWindow';
import { triggerChipSelectHaptic } from '../services/nativeAndroidService';
import { findLastSmoke, getElapsedMins, getGapProgressPercent } from '../services/smokeEngine';
import { buildChartSlots, rankTriggersInRange } from '../services/statsEngine';
import type { ChartSlot, TriggerRank } from '../services/statsEngine';
import { performCrushCraving, performLogSmoke, performUndoLastSmoke } from '../services/trackerActions';
import { useAppStore } from '../store/useAppStore';
import type { ChatMessage, SmokeEntry, TriggerType } from '../types/schema';
import { getLogicalDateString } from '../utils/dateUtils';
import { useNow } from './useNow';

export interface DangerWindowStatus {
  /** `15:00 – 18:00`. */
  label: string;
  /** True while the current time is inside the window. */
  isOpen: boolean;
  /** Minutes until the window opens; 0 while it is open. */
  minsUntilOpen: number;
}

export interface SmokeTracker {
  countToday: number;
  dailyTarget: number;
  /** Whole minutes since the last cigarette, or `null` when none was ever logged. */
  elapsedMinsSinceLastSmoke: number | null;
  activeTargetGapMins: number;
  /** 0-100: how far the current wait is toward the target. */
  gapProgressPercent: number;
  /** Minutes still to wait to reach the target; 0 once it is reached. */
  minsToGo: number;
  /** 0-100: where the wait before the last cigarette ended, as a mark to beat. `null` when unknown. */
  lastGapPercent: number | null;
  moneySavedToday: number;
  cravingsCrushedToday: number;
  costPerCigInr: number;
  /** Trigger of the most recent cigarette. */
  lastTrigger: TriggerType | null;
  /** Trigger the next logged cigarette gets. */
  selectedTrigger: TriggerType;
  /** Minutes the next logged cigarette is moved back in time. */
  backdateMins: number;
  /** The peak danger window from the rolling memory, or `null` while there is not enough history. */
  dangerWindow: DangerWindowStatus | null;
  chatMessages: ChatMessage[];
  isAiLoading: boolean;
  /** A short message when the coach could not answer (no key, no internet). */
  coachNotice: string | null;
  chartData7d: ChartSlot[];
  chartData30d: ChartSlot[];
  /** Triggers of the last 7 days, most used first. */
  triggerBreakdown: TriggerRank[];

  /** Logs a cigarette. Without arguments it uses the selected trigger and the current backdate. */
  logSmoke: (trigger?: TriggerType, backdateMins?: number) => SmokeEntry;
  /** Removes the most recent cigarette. Returns false when there was nothing recent to undo. */
  undoLastSmoke: () => boolean;
  crushCraving: () => void;
  sendChatMessage: (text: string) => Promise<void>;
  selectTrigger: (trigger: TriggerType) => void;
  /** Changes the trigger of the cigarette logged last (for example one logged from the lock screen). */
  retagLastSmoke: (trigger: TriggerType) => void;
  /** Each call moves the next cigarette 15 minutes further back, then wraps to 0. */
  cycleBackdate: () => void;
}

export function useSmokeTracker(): SmokeTracker {
  const now = useNow();
  const todayDate = getLogicalDateString(now);
  const today = useAppStore((state) => state.dailyLogs[todayDate]);
  const dailyLogs = useAppStore((state) => state.dailyLogs);
  const rollingMemory = useAppStore((state) => state.rollingMemory);
  const settings = useAppStore((state) => state.settings);
  const isAiLoading = useAppStore((state) => state.isCoachLoading);

  const [backdateMins, setBackdateMins] = useState(0);
  const [coachNotice, setCoachNotice] = useState<string | null>(null);

  // Starts the new day's log when the logical date changes while the app is open.
  useEffect(() => {
    useAppStore.getState().ensureToday(new Date());
  }, [todayDate]);

  const lastSmoke = useMemo(() => findLastSmoke(dailyLogs), [dailyLogs]);
  const activeTargetGapMins = today ? today.active_target_gap_mins : 0;
  const elapsedMinsSinceLastSmoke = getElapsedMins(lastSmoke ? lastSmoke.entry : null, now.getTime());
  const lastGap = lastSmoke ? lastSmoke.entry.gap_from_previous_mins : null;

  const dangerWindow = useMemo<DangerWindowStatus | null>(() => {
    const window = parseDangerWindow(rollingMemory?.stats.peak_danger_window);
    if (!window) {
      return null;
    }
    return {
      label: formatDangerWindow(window, 'spaced'),
      isOpen: isInDangerWindow(window, now),
      minsUntilOpen: minutesUntilWindowOpens(window, now),
    };
  }, [rollingMemory, now]);

  const chartCache = rollingMemory?.chart_cache_30_days;
  const chartData7d = useMemo(
    () => buildChartSlots({ chartCache: chartCache ?? [], todayLog: today, todayDate, numDays: 7 }),
    [chartCache, today, todayDate],
  );
  const chartData30d = useMemo(
    () => buildChartSlots({ chartCache: chartCache ?? [], todayLog: today, todayDate, numDays: 30 }),
    [chartCache, today, todayDate],
  );
  const triggerBreakdown = useMemo(() => rankTriggersInRange(dailyLogs, todayDate, 7), [dailyLogs, todayDate]);

  const logSmoke = useCallback(
    (trigger?: TriggerType, backdate?: number) => {
      const entry = performLogSmoke({ trigger, backdateMins: backdate ?? backdateMins });
      setBackdateMins(0);
      return entry;
    },
    [backdateMins],
  );

  const undoLastSmoke = useCallback(() => performUndoLastSmoke() !== null, []);

  const crushCraving = useCallback(() => performCrushCraving(), []);

  const sendChatMessage = useCallback(async (text: string) => {
    if (!text.trim()) {
      return;
    }
    setCoachNotice(null);
    const outcome = await triggerSmokeCoachAI({ type: 'USER_CHAT_MESSAGE', text });
    setCoachNotice(outcome.ok ? null : outcome.message);
  }, []);

  const selectTrigger = useCallback((trigger: TriggerType) => {
    triggerChipSelectHaptic();
    useAppStore.getState().selectTrigger(trigger);
  }, []);

  const retagLastSmoke = useCallback((trigger: TriggerType) => {
    if (useAppStore.getState().retagLastSmoke(trigger)) {
      triggerChipSelectHaptic();
    }
  }, []);

  const cycleBackdate = useCallback(() => {
    triggerChipSelectHaptic();
    setBackdateMins((current) => {
      const next = current + APP_CONFIG.backdate.stepMins;
      return next > APP_CONFIG.backdate.maxMins ? 0 : next;
    });
  }, []);

  return {
    countToday: today ? today.total_count : 0,
    dailyTarget: today ? today.daily_target : settings.daily_target,
    elapsedMinsSinceLastSmoke,
    activeTargetGapMins,
    gapProgressPercent: getGapProgressPercent(elapsedMinsSinceLastSmoke, activeTargetGapMins),
    minsToGo:
      elapsedMinsSinceLastSmoke === null ? activeTargetGapMins : Math.max(0, activeTargetGapMins - elapsedMinsSinceLastSmoke),
    lastGapPercent: lastGap === null ? null : getGapProgressPercent(lastGap, activeTargetGapMins),
    moneySavedToday: today ? today.money_saved_inr : 0,
    cravingsCrushedToday: today ? today.cravings_crushed : 0,
    costPerCigInr: settings.cost_per_cig_inr,
    lastTrigger: lastSmoke ? lastSmoke.entry.trigger : null,
    selectedTrigger: settings.selected_trigger,
    backdateMins,
    dangerWindow,
    chatMessages: today ? today.chat_buffer : [],
    isAiLoading,
    coachNotice,
    chartData7d,
    chartData30d,
    triggerBreakdown,
    logSmoke,
    undoLastSmoke,
    crushCraving,
    sendChatMessage,
    selectTrigger,
    retagLastSmoke,
    cycleBackdate,
  };
}
