import { createMemoryKv } from '../../storage/kv';
import type { BrainDumpDoc } from '../../types/schema';
import { createAppStore } from '../createAppStore';

// Dates are built with the local-time constructor, so the tests give the same
// result in every time zone.

/** A moment on a day of November 2026, on the phone's clock. */
function november(day: number, hour: number, minute = 0): Date {
  return new Date(2026, 10, day, hour, minute);
}

function newStore() {
  return createAppStore(createMemoryKv()).useStore;
}

function pendingDump(id: string, logicalDate: string): BrainDumpDoc {
  return {
    id,
    logical_date: logicalDate,
    created_at: `${logicalDate}T10:00:00.000+05:30`,
    raw_transcript: 'Need to send the deck.',
    ai_processed: { headline: 'Need to send the deck', mood_detected: 'Calm', category: 'Personal', action_items: [] },
    ai_status: 'pending',
  };
}

describe('ensureToday', () => {
  it('creates today with the default settings and an empty summary', () => {
    const store = newStore();

    const today = store.getState().ensureToday(november(19, 9));

    expect(today).toBe('2026-11-19');
    expect(store.getState().dailyLogs['2026-11-19']).toEqual({
      logical_date: '2026-11-19',
      total_count: 0,
      daily_target: 8,
      daily_baseline: 15,
      cost_per_cig_inr: 20,
      smoke_entries: [],
      cravings_crushed: 0,
      money_saved_inr: 0,
      active_target_gap_mins: 120,
      todays_brain_dump_headlines: [],
      chat_buffer: [],
      is_finalized: false,
    });
    expect(store.getState().rollingMemory?.last_computed_date).toBe('2026-11-18');
  });

  it('keeps counting 1:30 AM toward the day before', () => {
    const store = newStore();

    expect(store.getState().ensureToday(november(20, 1, 30))).toBe('2026-11-19');
  });

  it('closes yesterday and summarises it when a new day starts', () => {
    const store = newStore();
    store.getState().logSmoke({ now: november(19, 10) });
    store.getState().logSmoke({ now: november(19, 12) });
    store.getState().crushCraving(november(19, 13));

    store.getState().ensureToday(november(20, 9));

    const yesterday = store.getState().dailyLogs['2026-11-19'];
    const memory = store.getState().rollingMemory;
    expect(yesterday?.is_finalized).toBe(true);
    expect(yesterday?.money_saved_inr).toBe(260);
    expect(memory?.last_computed_date).toBe('2026-11-19');
    expect(memory?.stats.avg_7_day).toBe(2);
    expect(memory?.stats.total_money_saved_all_time).toBe(260);
    expect(memory?.chart_cache_30_days.map((point) => point.count)).toEqual([2]);
  });

  it('carries the wait target over to the new day', () => {
    const store = newStore();
    store.getState().applyCoachResult({ suggestedTargetGapMins: 150, newMemoryNote: null }, november(19, 10));

    store.getState().ensureToday(november(20, 9));

    expect(store.getState().dailyLogs['2026-11-20']?.active_target_gap_mins).toBe(150);
  });

  it('changes nothing when today already exists', () => {
    const store = newStore();
    store.getState().ensureToday(november(19, 9));
    const before = store.getState().dailyLogs;

    store.getState().ensureToday(november(19, 18));

    expect(store.getState().dailyLogs === before).toBe(true);
  });
});

describe('logSmoke', () => {
  it('uses the selected trigger', () => {
    const store = newStore();
    store.getState().selectTrigger('Work Stress');

    const entry = store.getState().logSmoke({ now: november(19, 15) });

    expect(entry.trigger).toBe('Work Stress');
    expect(store.getState().dailyLogs['2026-11-19']?.total_count).toBe(1);
  });

  it('uses the given trigger instead of the selected one', () => {
    const store = newStore();

    const entry = store.getState().logSmoke({ trigger: 'Post-Meal', now: november(19, 15) });

    expect(entry.trigger).toBe('Post-Meal');
  });

  it('moves a backdated cigarette back in time', () => {
    const store = newStore();
    store.getState().logSmoke({ now: november(19, 14) });

    const entry = store.getState().logSmoke({ backdateMins: 15, now: november(19, 15) });

    expect(entry.backdated_mins).toBe(15);
    expect(entry.gap_from_previous_mins).toBe(45);
  });

  it('files a cigarette backdated past 4 AM under yesterday and updates the summary', () => {
    const store = newStore();
    store.getState().ensureToday(november(20, 4, 20));

    store.getState().logSmoke({ backdateMins: 30, now: november(20, 4, 20) });

    expect(store.getState().dailyLogs['2026-11-20']?.total_count).toBe(0);
    expect(store.getState().dailyLogs['2026-11-19']?.total_count).toBe(1);
    expect(store.getState().dailyLogs['2026-11-19']?.is_finalized).toBe(true);
    expect(store.getState().rollingMemory?.stats.avg_7_day).toBe(1);
  });
});

describe('undoLastSmoke', () => {
  it('removes the cigarette that was just logged', () => {
    const store = newStore();
    store.getState().logSmoke({ now: november(19, 15) });

    const removed = store.getState().undoLastSmoke(november(19, 15, 1));

    expect(removed?.trigger).toBe('Craving');
    expect(store.getState().dailyLogs['2026-11-19']?.total_count).toBe(0);
  });

  it('returns null when there is nothing to undo', () => {
    const store = newStore();

    expect(store.getState().undoLastSmoke(november(19, 15))).toBeNull();
  });

  it('does not reach back to an old cigarette from an earlier day', () => {
    const store = newStore();
    store.getState().logSmoke({ now: november(19, 12) });

    const removed = store.getState().undoLastSmoke(november(20, 12));

    expect(removed).toBeNull();
    expect(store.getState().dailyLogs['2026-11-19']?.total_count).toBe(1);
  });

  it('can still undo a cigarette from just before the day changed', () => {
    const store = newStore();
    store.getState().logSmoke({ now: november(20, 3, 50) });

    const removed = store.getState().undoLastSmoke(november(20, 4, 5));

    expect(removed === null).toBe(false);
    expect(store.getState().dailyLogs['2026-11-19']?.total_count).toBe(0);
    expect(store.getState().rollingMemory?.stats.avg_7_day).toBe(0);
  });
});

describe('crushCraving', () => {
  it('counts the craving and the money', () => {
    const store = newStore();

    store.getState().crushCraving(november(19, 15));
    store.getState().crushCraving(november(19, 16));

    expect(store.getState().dailyLogs['2026-11-19']?.cravings_crushed).toBe(2);
    expect(store.getState().dailyLogs['2026-11-19']?.money_saved_inr).toBe(40);
  });
});

describe('updateSettings', () => {
  it('saves the settings and applies them to today', () => {
    const store = newStore();
    store.getState().crushCraving(november(19, 9));

    store.getState().updateSettings({ daily_target: 6, cost_per_cig_inr: 25 }, november(19, 10));

    expect(store.getState().settings.daily_target).toBe(6);
    expect(store.getState().settings.daily_baseline).toBe(15);
    expect(store.getState().dailyLogs['2026-11-19']?.daily_target).toBe(6);
    expect(store.getState().dailyLogs['2026-11-19']?.money_saved_inr).toBe(25);
    expect(store.getState().rollingMemory?.stats.current_daily_target).toBe(6);
  });

  it('keeps values inside a sensible range', () => {
    const store = newStore();

    store.getState().updateSettings({ daily_target: -3, daily_baseline: 500 }, november(19, 10));

    expect(store.getState().settings.daily_target).toBe(0);
    expect(store.getState().settings.daily_baseline).toBe(99);
  });
});

describe('coach conversation', () => {
  it('keeps the newest six messages of the day', () => {
    const store = newStore();
    const texts = ['1', '2', '3', '4', '5', '6', '7'];

    for (const text of texts) {
      store.getState().addChatMessage('user', text, november(19, 10));
    }

    expect(store.getState().dailyLogs['2026-11-19']?.chat_buffer.map((m) => m.text)).toEqual([
      '2',
      '3',
      '4',
      '5',
      '6',
      '7',
    ]);
  });

  it('stores the new wait target and the memory note', () => {
    const store = newStore();

    store.getState().applyCoachResult(
      { suggestedTargetGapMins: 150, newMemoryNote: 'Smokes right after the 3 pm review.' },
      november(19, 10),
    );

    expect(store.getState().dailyLogs['2026-11-19']?.active_target_gap_mins).toBe(150);
    expect(store.getState().rollingMemory?.ai_memory_notes).toEqual(['Smokes right after the 3 pm review.']);
  });

  it('keeps the wait target when the coach suggests none', () => {
    const store = newStore();

    store.getState().applyCoachResult({ suggestedTargetGapMins: null, newMemoryNote: null }, november(19, 10));

    expect(store.getState().dailyLogs['2026-11-19']?.active_target_gap_mins).toBe(120);
    expect(store.getState().rollingMemory?.ai_memory_notes).toEqual([]);
  });

  it('keeps an out-of-range wait target inside the limits', () => {
    const store = newStore();

    store.getState().applyCoachResult({ suggestedTargetGapMins: 5000, newMemoryNote: null }, november(19, 10));

    expect(store.getState().dailyLogs['2026-11-19']?.active_target_gap_mins).toBe(480);
  });

  it('keeps the memory notes when the summary is rebuilt on the next day', () => {
    const store = newStore();
    store.getState().applyCoachResult({ suggestedTargetGapMins: null, newMemoryNote: 'Note A' }, november(19, 10));

    store.getState().ensureToday(november(20, 9));

    expect(store.getState().rollingMemory?.ai_memory_notes).toEqual(['Note A']);
  });
});

describe('brain dumps', () => {
  it('adds the headline to the day only once the AI has processed the dump', () => {
    const store = newStore();
    store.getState().ensureToday(november(19, 10));

    store.getState().addBrainDump(pendingDump('d1', '2026-11-19'));
    const headlinesWhilePending = store.getState().dailyLogs['2026-11-19']?.todays_brain_dump_headlines;
    store.getState().completeBrainDump('d1', {
      headline: 'Client deck deadline is crushing my focus',
      mood_detected: 'Stressed',
      category: 'Work',
      action_items: [{ id: 't1', task: 'Send revised client deck', done: false }],
    });

    expect(headlinesWhilePending).toEqual([]);
    expect(store.getState().brainDumps.d1?.ai_status).toBe('done');
    expect(store.getState().dailyLogs['2026-11-19']?.todays_brain_dump_headlines).toEqual([
      'Client deck deadline is crushing my focus',
    ]);
  });

  it('ticks a task off and on again', () => {
    const store = newStore();
    store.getState().addBrainDump({
      ...pendingDump('d1', '2026-11-19'),
      ai_status: 'done',
      ai_processed: {
        headline: 'Headline',
        mood_detected: 'Calm',
        category: 'Work',
        action_items: [{ id: 't1', task: 'Send revised client deck', done: false }],
      },
    });

    store.getState().toggleTaskDone('d1', 't1');
    const afterFirstTap = store.getState().brainDumps.d1?.ai_processed.action_items[0]?.done;
    store.getState().toggleTaskDone('d1', 't1');

    expect(afterFirstTap).toBe(true);
    expect(store.getState().brainDumps.d1?.ai_processed.action_items[0]?.done).toBe(false);
  });

  it('removes a deleted dump and its headline', () => {
    const store = newStore();
    store.getState().ensureToday(november(19, 10));
    store.getState().addBrainDump({ ...pendingDump('d1', '2026-11-19'), ai_status: 'done' });

    store.getState().deleteDump('d1');

    expect(store.getState().brainDumps).toEqual({});
    expect(store.getState().dailyLogs['2026-11-19']?.todays_brain_dump_headlines).toEqual([]);
  });
});

describe('saving', () => {
  it('restores everything after a restart and drops in-progress flags', () => {
    const kv = createMemoryKv();
    const first = createAppStore(kv).useStore;
    first.getState().logSmoke({ trigger: 'Social', now: november(19, 15) });
    first.getState().addBrainDump(pendingDump('d1', '2026-11-19'));
    first.getState().updateSettings({ daily_target: 6 }, november(19, 16));
    first.getState().setCoachLoading(true);

    const second = createAppStore(kv).useStore;

    expect(second.getState().dailyLogs).toEqual(first.getState().dailyLogs);
    expect(second.getState().brainDumps).toEqual(first.getState().brainDumps);
    expect(second.getState().settings).toEqual(first.getState().settings);
    expect(second.getState().rollingMemory).toEqual(first.getState().rollingMemory);
    expect(second.getState().isCoachLoading).toBe(false);
  });

  it('queues every changed document for the cloud backup', () => {
    const { useStore, storage } = createAppStore(createMemoryKv());

    useStore.getState().logSmoke({ now: november(19, 15) });

    expect(storage.getDirtyPaths()).toEqual(['ai_context/rolling_memory', 'daily_logs/2026-11-19', 'settings/app']);
  });
});

describe('mergeRemoteState', () => {
  it('adds days from the backup that are missing and keeps local days', () => {
    const backup = newStore();
    backup.getState().logSmoke({ now: november(17, 12) });
    backup.getState().logSmoke({ now: november(19, 12) });
    backup.getState().logSmoke({ now: november(19, 13) });
    const phone = newStore();
    phone.getState().logSmoke({ now: november(19, 15) });

    phone.getState().mergeRemoteState({ dailyLogs: backup.getState().dailyLogs }, november(19, 16));

    expect(phone.getState().dailyLogs['2026-11-17']?.total_count).toBe(1);
    expect(phone.getState().dailyLogs['2026-11-19']?.total_count).toBe(1);
    expect(phone.getState().rollingMemory?.stats.avg_7_day).toBe(1);
  });

  it('takes the backup settings only when the local ones were never changed', () => {
    const phone = newStore();
    const changed = newStore();
    changed.getState().updateSettings({ daily_target: 3 }, november(19, 9));
    const remoteSettings = { ...phone.getState().settings, daily_target: 5, updated_at: '2026-11-01T10:00:00.000+05:30' };

    phone.getState().mergeRemoteState({ settings: remoteSettings }, november(19, 16));
    changed.getState().mergeRemoteState({ settings: remoteSettings }, november(19, 16));

    expect(phone.getState().settings.daily_target).toBe(5);
    expect(changed.getState().settings.daily_target).toBe(3);
  });
});
