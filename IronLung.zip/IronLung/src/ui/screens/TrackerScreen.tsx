/**
 * TRACKER tab: today's count, the live gap gauge, the two main actions, the
 * trigger chips and the Blunt Coach.
 *
 * The screen only lays things out. Every value and action comes from
 * `useSmokeTracker`.
 */

import { LinearGradient } from 'expo-linear-gradient';
import React, { useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, TextInput, View } from 'react-native';
import type { ScrollView } from 'react-native';

import { useSmokeTracker } from '../../hooks/useSmokeTracker';
import type { SmokeTracker } from '../../hooks/useSmokeTracker';
import { TRIGGER_TYPES } from '../../types/schema';
import type { ChatMessage, TriggerType } from '../../types/schema';
import {
  formatDurationCompact,
  formatDurationLoose,
  formatDurationPadded,
  formatGaugeParts,
  formatInr,
} from '../../utils/format';
import { GapGauge } from '../components/GapGauge';
import { Body, Display, Icon, Mono, PulseDot } from '../primitives';
import type { IconName } from '../primitives';
import { splitCoachHighlights } from '../richText';
import { ScreenFrame } from '../ScreenFrame';
import { alpha, colors, fonts, glow, layout, s } from '../theme';

const PAGE_GLOW = { color: colors.ember, opacity: 0.09, centerX: 0.5 };

const TRIGGER_ICONS: Record<TriggerType, IconName> = {
  'Work Stress': 'briefcase',
  'Post-Meal': 'utensils',
  Boredom: 'hourglass-half',
  Social: 'user-group',
  'Late Night': 'moon',
  Craving: 'fire',
};

/** How many of the newest chat messages the coach card shows. */
const VISIBLE_MESSAGES = 3;
/** The keyboard needs a moment to open before the chat input can be scrolled into view. */
const KEYBOARD_OPEN_DELAY_MS = 300;

export function TrackerScreen({ onOpenSettings }: { onOpenSettings: () => void }) {
  const tracker = useSmokeTracker();
  const scrollRef = useRef<ScrollView | null>(null);
  const showChatInput = () => {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), KEYBOARD_OPEN_DELAY_MS);
  };

  return (
    <ScreenFrame glow={PAGE_GLOW} scrollRef={scrollRef}>
      <TopBar tracker={tracker} onOpenSettings={onOpenSettings} />
      <DangerBanner tracker={tracker} />
      <GaugeCard tracker={tracker} />
      <ActionButtons tracker={tracker} />
      <TriggerChips tracker={tracker} />
      <CoachCard tracker={tracker} onInputFocus={showChatInput} />
    </ScreenFrame>
  );
}

// ---------------------------------------------------------------------------
// Top bar
// ---------------------------------------------------------------------------

function TopBar({ tracker, onOpenSettings }: { tracker: SmokeTracker; onOpenSettings: () => void }) {
  return (
    <View style={styles.topBar}>
      <View style={styles.topGroup}>
        <View style={styles.countPill}>
          <Display size={22} weight={800}>
            {tracker.countToday}
          </Display>
          <Display size={15} weight={700} color={colors.slate} style={styles.countTarget}>
            / {tracker.dailyTarget}
          </Display>
          <Mono size={9} color={colors.emberBright} tracking={0.9} style={styles.countLabel}>
            TARGET
          </Mono>
        </View>
        <View style={styles.cyclePill}>
          <Icon name="rotate" color={colors.slate} />
          <Mono size={9} color={colors.slate} tracking={0.9} style={styles.cycleLabel}>
            4:00 AM CYCLE
          </Mono>
        </View>
      </View>
      <View style={styles.topGroup}>
        <View style={styles.savedPill}>
          <Icon name="indian-rupee-sign" color={colors.emerald} />
          <Display size={16} weight={800} color={colors.emerald} style={styles.savedAmount}>
            {formatInr(tracker.moneySavedToday)}
          </Display>
          <Mono size={9} color={colors.emerald} tracking={0.9} style={styles.savedLabel}>
            SAVED
          </Mono>
        </View>
        <Pressable
          onPress={onOpenSettings}
          hitSlop={s(8)}
          accessibilityRole="button"
          accessibilityLabel="Quick settings"
          style={({ pressed }) => [styles.gearButton, pressed && styles.pressed]}
        >
          <Icon name="gear" color={colors.slate} />
        </Pressable>
      </View>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Danger window banner
// ---------------------------------------------------------------------------

function DangerBanner({ tracker }: { tracker: SmokeTracker }) {
  const window = tracker.dangerWindow;
  return (
    <View style={[styles.banner, window?.isOpen && styles.bannerOpen]}>
      <LinearGradient
        colors={[alpha(colors.crimson, 0.4), alpha(colors.amber, 0.1)]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.bannerStripe} />
      <Icon name="triangle-exclamation" color={colors.crimson} />
      <Mono size={10} weight={500} tracking={0.9} numberOfLines={1} style={styles.bannerText}>
        PEAK DANGER WINDOW:{' '}
        <Mono size={10} weight={500} tracking={0.9} color={window ? colors.crimson : colors.slate}>
          {window ? window.label : 'LEARNING'}
        </Mono>
        <Mono size={10} weight={500} tracking={0.9} color={colors.amber}>
          {window ? ' • STAY SHARP' : ' • KEEP LOGGING'}
        </Mono>
      </Mono>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Gauge card
// ---------------------------------------------------------------------------

function GaugeCard({ tracker }: { tracker: SmokeTracker }) {
  const elapsed = tracker.elapsedMinsSinceLastSmoke;
  const { hours, minutes } = formatGaugeParts(elapsed);
  const progress = tracker.gapProgressPercent;
  let statusLabel = 'NO SMOKE LOGGED YET';
  if (elapsed !== null) {
    statusLabel =
      progress >= 100 ? '100% • TARGET BEATEN' : `${Math.floor(progress)}% • ${formatDurationLoose(tracker.minsToGo)} TO GO`;
  }

  return (
    <View style={styles.gaugeCard}>
      <LinearGradient colors={[colors.gunmetal, colors.obsidian]} style={StyleSheet.absoluteFill} />
      <View style={styles.gaugeHeader}>
        <Mono size={10} color={colors.slate} tracking={2}>
          LIVE GAP // T+
        </Mono>
        <View style={styles.liveGroup}>
          <PulseDot color={colors.emerald} size={6} />
          <Mono size={10} color={colors.emerald} tracking={2} style={styles.liveLabel}>
            LIVE
          </Mono>
        </View>
      </View>

      <View style={styles.gaugeWrap}>
        <GapGauge
          progressPercent={progress}
          markerPercent={tracker.lastGapPercent}
          hours={hours}
          minutes={minutes}
          targetLabel={`TARGET ${formatDurationPadded(tracker.activeTargetGapMins)}`}
          statusLabel={statusLabel}
          startLabel="0h"
          endLabel={formatDurationCompact(tracker.activeTargetGapMins)}
        />
      </View>

      <View style={styles.statRow}>
        <View style={styles.statBox}>
          <Mono size={9} color={colors.slate} tracking={1.5}>
            CRAVINGS CRUSHED
          </Mono>
          <View style={styles.statCravings}>
            <Icon name="bolt" color={colors.emerald} />
            <Display size={26} weight={800} color={colors.emerald} style={styles.statCravingsCount}>
              {tracker.cravingsCrushedToday}
            </Display>
          </View>
        </View>
        <View style={styles.statBox}>
          <Mono size={9} color={colors.slate} tracking={1.5}>
            LAST TRIGGER
          </Mono>
          <Display
            size={18}
            weight={700}
            color={tracker.lastTrigger ? colors.crimson : colors.slate}
            numberOfLines={1}
            style={styles.statTrigger}
          >
            {tracker.lastTrigger ? tracker.lastTrigger.toUpperCase() : 'NONE YET'}
          </Display>
        </View>
      </View>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Main actions
// ---------------------------------------------------------------------------

function ActionButtons({ tracker }: { tracker: SmokeTracker }) {
  const isBackdated = tracker.backdateMins > 0;
  return (
    <>
      <Pressable
        onPress={tracker.crushCraving}
        accessibilityRole="button"
        accessibilityLabel="Crush craving"
        style={({ pressed }) => [styles.crushButton, pressed && styles.pressedDown]}
      >
        <LinearGradient colors={['#3CFF9E', '#04E577']} style={StyleSheet.absoluteFill} />
        <View style={styles.crushBevel} />
        <Icon name="bolt" scale={1.25} color={colors.obsidian} />
        <Display size={24} weight={800} color={colors.obsidian} style={styles.crushLabel}>
          CRUSH CRAVING
        </Display>
        <View style={styles.crushBadge}>
          <Display size={16} weight={700} color={colors.emerald}>
            +₹{formatInr(tracker.costPerCigInr)}
          </Display>
        </View>
      </Pressable>

      <View style={styles.actionRow}>
        <Pressable
          onPress={() => tracker.logSmoke()}
          accessibilityRole="button"
          accessibilityLabel="Log one smoke"
          style={({ pressed }) => [styles.logButton, pressed && styles.pressedDown]}
        >
          <LinearGradient colors={['#291307', '#170B05']} style={StyleSheet.absoluteFill} />
          <Display size={22} weight={800} color={colors.emberBright}>
            +1
          </Display>
          <Display size={18} weight={700} style={styles.logLabel}>
            LOG SMOKE
          </Display>
        </Pressable>

        <Pressable
          onPress={tracker.undoLastSmoke}
          accessibilityRole="button"
          accessibilityLabel="Undo last smoke"
          style={({ pressed }) => [styles.smallButton, styles.undoButton, pressed && styles.pressed]}
        >
          <Icon name="rotate-left" color={colors.slate} />
          <Mono size={9} color={colors.slate} tracking={0.9} style={styles.smallButtonLabel}>
            UNDO
          </Mono>
        </Pressable>

        <Pressable
          onPress={tracker.cycleBackdate}
          accessibilityRole="button"
          accessibilityLabel="Backdate the next smoke"
          style={({ pressed }) => [
            styles.smallButton,
            styles.backdateButton,
            isBackdated && styles.backdateActive,
            pressed && styles.pressed,
          ]}
        >
          <Icon name="clock-rotate-left" color={isBackdated ? colors.emberBright : colors.slate} />
          <Mono
            size={9}
            color={isBackdated ? colors.emberBright : colors.slate}
            tracking={0.45}
            style={styles.smallButtonLabel}
          >
            -{isBackdated ? tracker.backdateMins : 15}m
          </Mono>
        </Pressable>
      </View>
    </>
  );
}

// ---------------------------------------------------------------------------
// Trigger chips
// ---------------------------------------------------------------------------

function TriggerChips({ tracker }: { tracker: SmokeTracker }) {
  return (
    <>
      <Mono size={9} color={colors.slate} tracking={1.6} style={styles.tagLabel}>
        TAG TRIGGER
      </Mono>
      <View style={styles.chips}>
        {TRIGGER_TYPES.map((trigger) => {
          const isSelected = trigger === tracker.selectedTrigger;
          const tint = isSelected ? colors.crimson : colors.slate;
          return (
            <Pressable
              key={trigger}
              onPress={() => tracker.selectTrigger(trigger)}
              // Long press also re-tags the cigarette that was logged last.
              onLongPress={() => {
                tracker.selectTrigger(trigger);
                tracker.retagLastSmoke(trigger);
              }}
              accessibilityRole="button"
              accessibilityState={{ selected: isSelected }}
              accessibilityLabel={trigger}
              style={({ pressed }) => [styles.chip, isSelected && styles.chipSelected, pressed && styles.pressed]}
            >
              <Icon name={TRIGGER_ICONS[trigger]} color={tint} />
              <Body size={12} weight={600} color={tint} lineHeight={16} style={styles.chipLabel}>
                {trigger}
              </Body>
            </Pressable>
          );
        })}
      </View>
    </>
  );
}

// ---------------------------------------------------------------------------
// Blunt Coach
// ---------------------------------------------------------------------------

function CoachBubbleText({ text }: { text: string }) {
  return (
    <Body size={13} lineHeight={18}>
      {splitCoachHighlights(text).map((part, index) => {
        if (part.tone === 'plain') {
          return part.text;
        }
        return (
          <Body
            key={index}
            size={13}
            lineHeight={18}
            weight={600}
            color={part.tone === 'quote' ? colors.crimson : colors.emberBright}
          >
            {part.text}
          </Body>
        );
      })}
    </Body>
  );
}

function ChatBubble({ message }: { message: ChatMessage }) {
  if (message.role === 'user') {
    return (
      <View style={styles.userBubble}>
        <Body size={13} lineHeight={18}>
          {message.text}
        </Body>
      </View>
    );
  }
  return (
    <View style={styles.coachBubble}>
      <CoachBubbleText text={message.text} />
    </View>
  );
}

function CoachCard({ tracker, onInputFocus }: { tracker: SmokeTracker; onInputFocus: () => void }) {
  const [draft, setDraft] = useState('');
  const messages = tracker.chatMessages.slice(-VISIBLE_MESSAGES);
  const lastMessage = tracker.chatMessages[tracker.chatMessages.length - 1];
  const canSend = draft.trim().length > 0;

  const send = () => {
    if (!canSend) {
      return;
    }
    const text = draft;
    setDraft('');
    tracker.sendChatMessage(text).catch(() => undefined);
  };

  return (
    <View style={styles.coachCard}>
      <View style={styles.coachHeader}>
        <LinearGradient
          colors={['#16274A', colors.gunmetal]}
          start={{ x: 0, y: 0.5 }}
          end={{ x: 1, y: 0.5 }}
          style={StyleSheet.absoluteFill}
        />
        <LinearGradient colors={[colors.cyan, colors.cobalt]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.coachAvatar}>
          <Icon name="robot" color={colors.obsidian} />
        </LinearGradient>
        <View style={styles.coachTitles}>
          <Display size={15} weight={800} lineHeight={18}>
            BLUNT COACH
          </Display>
          <Mono size={9} color={colors.cyan} tracking={0.9} style={styles.coachSubtitle}>
            COMMS // LINKED TO BRAIN DUMP
          </Mono>
        </View>
        <Mono size={9} color={colors.slate} tracking={0.45} style={styles.coachTime}>
          {lastMessage ? lastMessage.timestamp.slice(11, 16) : '--:--'}
        </Mono>
      </View>

      <View style={styles.coachBody}>
        {messages.length === 0 && !tracker.isAiLoading ? (
          <View style={styles.coachBubble}>
            <Body size={13} lineHeight={18} color={colors.slate}>
              No comms yet. Log a smoke, crush a craving or ask me something.
            </Body>
          </View>
        ) : null}
        {messages.map((message) => (
          <ChatBubble key={message.id} message={message} />
        ))}
        {tracker.isAiLoading ? (
          <View style={[styles.coachBubble, styles.coachThinking]}>
            <ActivityIndicator size="small" color={colors.cyan} />
          </View>
        ) : null}
        {tracker.coachNotice ? (
          <View style={styles.coachBubble}>
            <Body size={13} lineHeight={18} color={colors.amber}>
              {tracker.coachNotice}
            </Body>
          </View>
        ) : null}
      </View>

      <View style={styles.coachInputRow}>
        <TextInput
          value={draft}
          onChangeText={setDraft}
          onSubmitEditing={send}
          onFocus={onInputFocus}
          placeholder="Talk to coach…"
          placeholderTextColor={colors.slate}
          selectionColor={colors.cyan}
          cursorColor={colors.cyan}
          returnKeyType="send"
          submitBehavior="submit"
          allowFontScaling={false}
          maxLength={400}
          style={styles.coachInput}
        />
        <Pressable
          onPress={send}
          disabled={!canSend}
          accessibilityRole="button"
          accessibilityLabel="Send message"
          style={({ pressed }) => [styles.sendButton, pressed && styles.pressed]}
        >
          <LinearGradient colors={[colors.cyan, colors.cobalt]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
          <Icon name="paper-plane" color={colors.obsidian} style={styles.sendIcon} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  pressed: {
    opacity: 0.7,
  },
  pressedDown: {
    opacity: 0.9,
    transform: [{ translateY: s(1) }],
  },

  // Top bar
  topBar: {
    height: s(39),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  topGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: s(8),
  },
  countPill: {
    height: s(39),
    paddingLeft: s(10),
    paddingRight: s(12.3),
    flexDirection: 'row',
    alignItems: 'baseline',
    borderRadius: s(8),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.gunmetal,
    paddingTop: s(4),
  },
  countTarget: {
    marginLeft: s(4),
  },
  countLabel: {
    marginLeft: s(8),
  },
  cyclePill: {
    height: s(27),
    paddingLeft: s(8.3),
    paddingRight: s(10),
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: s(6),
    borderWidth: 1,
    borderColor: colors.steel,
  },
  cycleLabel: {
    marginLeft: s(4.25),
  },
  savedPill: {
    height: s(30),
    paddingLeft: s(12),
    paddingRight: s(12.6),
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: s(15),
    borderWidth: 1,
    borderColor: alpha(colors.emerald, 0.4),
    backgroundColor: alpha(colors.emerald, 0.1),
    boxShadow: glow(colors.emerald, 0.35, 12),
  },
  savedAmount: {
    marginLeft: s(5.8),
    marginBottom: s(1.8),
  },
  savedLabel: {
    marginLeft: s(7),
  },
  gearButton: {
    width: s(36),
    height: s(36),
    borderRadius: s(8),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.gunmetal,
    alignItems: 'center',
    justifyContent: 'center',
  },

  // Danger banner
  banner: {
    marginTop: s(16),
    height: s(46),
    paddingLeft: s(18),
    paddingRight: s(12),
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: s(12),
    borderWidth: 1,
    borderColor: alpha(colors.crimson, 0.5),
    backgroundColor: colors.obsidian,
    overflow: 'hidden',
  },
  bannerOpen: {
    borderColor: colors.crimson,
    boxShadow: glow(colors.crimson, 0.45, 14),
  },
  bannerStripe: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: s(4),
    backgroundColor: colors.crimson,
  },
  bannerText: {
    flex: 1,
    marginLeft: s(9.9),
    marginBottom: s(1.5),
  },

  // Gauge card
  gaugeCard: {
    marginTop: s(layout.cardGap),
    paddingTop: s(17),
    paddingBottom: s(20),
    paddingHorizontal: s(16),
    borderRadius: s(layout.cardRadius),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.gunmetal,
    overflow: 'hidden',
  },
  gaugeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  liveGroup: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  liveLabel: {
    marginLeft: s(6),
  },
  gaugeWrap: {
    marginTop: s(5),
  },
  statRow: {
    flexDirection: 'row',
    gap: s(9),
  },
  statBox: {
    flex: 1,
    height: s(63),
    paddingLeft: s(12.3),
    paddingTop: s(10),
    borderRadius: s(12),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: alpha(colors.obsidian, 0.6),
  },
  statCravings: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: s(0.1),
    marginLeft: s(0.6),
  },
  statCravingsCount: {
    marginLeft: s(6.9),
  },
  statTrigger: {
    marginTop: s(2.4),
  },

  // Main actions
  crushButton: {
    marginTop: s(layout.cardGap),
    height: s(64),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(16),
    backgroundColor: colors.emerald,
    overflow: 'hidden',
    boxShadow: glow(colors.emerald, 0.45, 24),
  },
  // A light line along the top edge and a darker lip along the bottom, like a pressed key.
  crushBevel: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: s(16),
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.6)',
    borderBottomWidth: s(3),
    borderBottomColor: 'rgba(0, 0, 0, 0.25)',
  },
  crushLabel: {
    marginLeft: s(8.6),
  },
  crushBadge: {
    marginLeft: s(13),
    height: s(28),
    paddingHorizontal: s(8),
    borderRadius: s(6),
    backgroundColor: alpha(colors.obsidian, 0.9),
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionRow: {
    marginTop: s(10),
    height: s(54),
    flexDirection: 'row',
    gap: s(8),
  },
  logButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(12),
    borderWidth: 1,
    borderColor: alpha(colors.ember, 0.6),
    backgroundColor: '#1F0F06',
    overflow: 'hidden',
    boxShadow: glow(colors.ember, 0.18, 14),
  },
  logLabel: {
    marginLeft: s(8),
  },
  smallButton: {
    paddingTop: s(0.8),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(12),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.gunmetal,
  },
  undoButton: {
    width: s(64),
  },
  backdateButton: {
    width: s(78),
  },
  backdateActive: {
    borderColor: alpha(colors.ember, 0.6),
    backgroundColor: alpha(colors.ember, 0.15),
  },
  smallButtonLabel: {
    marginTop: s(4.85),
  },

  // Trigger chips
  tagLabel: {
    marginTop: s(10.25),
  },
  chips: {
    marginTop: s(9.75),
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: s(6),
  },
  chip: {
    height: s(36),
    paddingHorizontal: s(12),
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: s(8),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.gunmetal,
  },
  chipSelected: {
    borderColor: alpha(colors.crimson, 0.6),
    backgroundColor: alpha(colors.crimson, 0.15),
  },
  chipLabel: {
    marginLeft: s(6),
  },

  // Blunt Coach
  coachCard: {
    marginTop: s(layout.cardGap),
    borderRadius: s(layout.cardRadius),
    borderWidth: 1,
    borderColor: alpha(colors.cyan, 0.3),
    backgroundColor: colors.gunmetal,
    overflow: 'hidden',
    boxShadow: glow(colors.cyan, 0.08, 24),
  },
  coachHeader: {
    height: s(50),
    paddingLeft: s(14.5),
    paddingRight: s(14),
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: colors.steel,
  },
  coachAvatar: {
    width: s(28),
    height: s(28),
    borderRadius: s(7),
    alignItems: 'center',
    justifyContent: 'center',
  },
  // The two lines sit a little above the middle of the header, as in the design.
  coachTitles: {
    flex: 1,
    marginLeft: s(8),
    marginBottom: s(2.3),
  },
  coachSubtitle: {
    marginTop: s(1),
  },
  coachTime: {
    marginBottom: s(1),
  },
  coachBody: {
    paddingHorizontal: s(14.5),
    paddingTop: s(12),
    paddingBottom: s(12),
    gap: s(8),
  },
  coachBubble: {
    alignSelf: 'flex-start',
    maxWidth: '88%',
    paddingHorizontal: s(12),
    paddingTop: s(7.5),
    paddingBottom: s(8.5),
    borderRadius: s(12),
    borderTopLeftRadius: s(2),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.obsidian,
  },
  coachThinking: {
    paddingVertical: s(9),
  },
  userBubble: {
    alignSelf: 'flex-end',
    minWidth: '75%',
    maxWidth: '88%',
    paddingHorizontal: s(12),
    paddingTop: s(7.5),
    paddingBottom: s(8.5),
    borderRadius: s(12),
    borderTopRightRadius: s(2),
    backgroundColor: colors.cobalt,
  },
  coachInputRow: {
    paddingLeft: s(12.5),
    paddingRight: s(12),
    paddingTop: s(10),
    paddingBottom: s(10),
    flexDirection: 'row',
    alignItems: 'center',
    gap: s(8.5),
    borderTopWidth: 1,
    borderTopColor: colors.steel,
  },
  coachInput: {
    flex: 1,
    height: s(40),
    paddingHorizontal: s(12),
    paddingVertical: 0,
    borderRadius: s(8),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.obsidian,
    color: colors.titanium,
    fontFamily: fonts.body400,
    fontSize: s(13),
    includeFontPadding: false,
  },
  sendIcon: {
    marginBottom: s(2),
  },
  sendButton: {
    width: s(40),
    height: s(40),
    borderRadius: s(8),
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
});
