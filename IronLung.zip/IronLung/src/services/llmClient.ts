/**
 * One small client for three AI providers.
 *
 * `requestJson` sends a system prompt, a user message and a JSON schema, and
 * returns the parsed JSON the model answered with. The provider is picked
 * from the shape of the API key, so switching between Gemini, OpenAI and
 * Claude only means pasting a different key in Quick Settings.
 *
 * Each provider enforces the schema in its own way:
 * - Gemini: `responseMimeType: application/json` with a `responseSchema`.
 * - OpenAI: `response_format` with a strict `json_schema`.
 * - Claude: a single tool whose input schema is the wanted JSON, forced with `tool_choice`.
 */

import { APP_CONFIG } from '../config/appConfig';
import type { LlmProvider } from '../config/appConfig';
import { AiContractError, extractJson, toGeminiSchema, toStandardSchema } from './aiContracts';
import type { JsonSchema } from './aiContracts';

export type LlmErrorKind =
  | 'no_key'
  | 'network'
  | 'timeout'
  | 'auth'
  | 'rate_limit'
  | 'server'
  | 'bad_request'
  | 'bad_response';

export class LlmError extends Error {
  constructor(
    readonly kind: LlmErrorKind,
    message: string,
    readonly status?: number,
  ) {
    super(message);
    this.name = 'LlmError';
  }
}

/** Picks the provider an API key belongs to from the way the key starts. */
export function detectProvider(apiKey: string): LlmProvider {
  const key = apiKey.trim();
  if (key.startsWith('sk-ant-')) {
    return 'anthropic';
  }
  if (key.startsWith('sk-')) {
    return 'openai';
  }
  if (key.startsWith('AIza')) {
    return 'gemini';
  }
  return APP_CONFIG.ai.fallbackProvider;
}

export interface LlmJsonRequest {
  system: string;
  user: string;
  schema: JsonSchema;
  /** A short name for the schema: letters, digits and underscores only. */
  schemaName: string;
  temperature?: number;
}

export interface HttpRequestSpec {
  url: string;
  headers: Record<string, string>;
  body: Record<string, unknown>;
}

const ANTHROPIC_MAX_TOKENS = 1024;

/** Builds the HTTP request for a provider. Pure, so it can be checked without a network. */
export function buildProviderRequest(
  provider: LlmProvider,
  model: string,
  apiKey: string,
  request: LlmJsonRequest,
): HttpRequestSpec {
  if (provider === 'gemini') {
    const generationConfig: Record<string, unknown> = {
      responseMimeType: 'application/json',
      responseSchema: toGeminiSchema(request.schema),
    };
    if (request.temperature !== undefined) {
      generationConfig.temperature = request.temperature;
    }
    return {
      url: `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: {
        systemInstruction: { parts: [{ text: request.system }] },
        contents: [{ role: 'user', parts: [{ text: request.user }] }],
        generationConfig,
      },
    };
  }

  if (provider === 'openai') {
    return {
      url: 'https://api.openai.com/v1/chat/completions',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: {
        model,
        messages: [
          { role: 'system', content: request.system },
          { role: 'user', content: request.user },
        ],
        response_format: {
          type: 'json_schema',
          json_schema: { name: request.schemaName, strict: true, schema: toStandardSchema(request.schema) },
        },
      },
    };
  }

  return {
    url: 'https://api.anthropic.com/v1/messages',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: {
      model,
      max_tokens: ANTHROPIC_MAX_TOKENS,
      system: request.system,
      messages: [{ role: 'user', content: request.user }],
      tools: [
        {
          name: request.schemaName,
          description: 'Return the answer in exactly this structure.',
          input_schema: toStandardSchema(request.schema),
        },
      ],
      tool_choice: { type: 'tool', name: request.schemaName },
    },
  };
}

function field(value: unknown, key: string): unknown {
  return typeof value === 'object' && value !== null ? (value as Record<string, unknown>)[key] : undefined;
}

function first(value: unknown): unknown {
  return Array.isArray(value) ? value[0] : undefined;
}

function parseModelText(text: string): unknown {
  try {
    return extractJson(text);
  } catch (error) {
    throw new LlmError('bad_response', error instanceof AiContractError ? error.message : 'The AI answer could not be read.');
  }
}

/** Pulls the JSON answer out of a provider's response body. */
export function readProviderResponse(provider: LlmProvider, payload: unknown): unknown {
  if (provider === 'gemini') {
    const parts = field(field(first(field(payload, 'candidates')), 'content'), 'parts');
    const text = Array.isArray(parts)
      ? parts
          .map((part) => field(part, 'text'))
          .filter((t): t is string => typeof t === 'string')
          .join('')
      : '';
    if (!text) {
      const blockReason = field(field(payload, 'promptFeedback'), 'blockReason');
      throw new LlmError(
        'bad_response',
        typeof blockReason === 'string' ? `The AI refused to answer (${blockReason}).` : 'The AI sent an empty answer.',
      );
    }
    return parseModelText(text);
  }

  if (provider === 'openai') {
    const message = field(first(field(payload, 'choices')), 'message');
    const content = field(message, 'content');
    if (typeof content !== 'string' || !content) {
      const refusal = field(message, 'refusal');
      throw new LlmError(
        'bad_response',
        typeof refusal === 'string' && refusal ? `The AI refused to answer (${refusal}).` : 'The AI sent an empty answer.',
      );
    }
    return parseModelText(content);
  }

  const blocks = field(payload, 'content');
  if (Array.isArray(blocks)) {
    const toolUse = blocks.find((block) => field(block, 'type') === 'tool_use');
    const input = field(toolUse, 'input');
    if (typeof input === 'object' && input !== null) {
      return input;
    }
    const text = blocks
      .map((block) => field(block, 'text'))
      .filter((t): t is string => typeof t === 'string')
      .join('');
    if (text) {
      return parseModelText(text);
    }
  }
  throw new LlmError('bad_response', 'The AI sent an empty answer.');
}

/** The part of `fetch` this client uses. Lets tests pass in a fake. */
export type FetchLike = (
  url: string,
  init: { method: string; headers: Record<string, string>; body: string; signal?: AbortSignal },
) => Promise<{ ok: boolean; status: number; text(): Promise<string> }>;

export interface LlmClientOptions {
  /** The key from Quick Settings. `null` or empty fails with `no_key`. */
  apiKey: string | null;
  /** Overrides the provider guessed from the key. */
  provider?: LlmProvider;
  /** Overrides the model from `APP_CONFIG.ai.models`. */
  model?: string;
  fetchImpl?: FetchLike;
  timeoutMs?: number;
  /** How often to try in total. Problems that a retry cannot fix (bad key, bad request) are not retried. */
  maxAttempts?: number;
  sleep?: (ms: number) => Promise<void>;
}

const RETRYABLE: readonly LlmErrorKind[] = ['network', 'timeout', 'rate_limit', 'server', 'bad_response'];
const RETRY_DELAY_MS = 1200;

function describeHttpError(status: number, bodyText: string): LlmError {
  let detail = '';
  try {
    const message = field(field(JSON.parse(bodyText) as unknown, 'error'), 'message');
    detail = typeof message === 'string' ? message : '';
  } catch {
    detail = '';
  }
  const suffix = detail ? ` ${detail}` : '';
  if (status === 401 || status === 403) {
    return new LlmError('auth', `The AI API key was rejected.${suffix}`, status);
  }
  if (status === 429) {
    return new LlmError('rate_limit', `The AI is rate limited or out of quota.${suffix}`, status);
  }
  if (status >= 500) {
    return new LlmError('server', `The AI service had a problem (${status}).${suffix}`, status);
  }
  return new LlmError('bad_request', `The AI request was not accepted (${status}).${suffix}`, status);
}

async function attempt(spec: HttpRequestSpec, provider: LlmProvider, doFetch: FetchLike, timeoutMs: number): Promise<unknown> {
  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  let response: Awaited<ReturnType<FetchLike>>;
  let bodyText: string;
  try {
    response = await doFetch(spec.url, {
      method: 'POST',
      headers: spec.headers,
      body: JSON.stringify(spec.body),
      signal: controller.signal,
    });
    bodyText = await response.text();
  } catch {
    throw timedOut
      ? new LlmError('timeout', 'The AI took too long to answer.')
      : new LlmError('network', 'Could not reach the AI. Check the internet connection.');
  } finally {
    clearTimeout(timer);
  }

  if (!response.ok) {
    throw describeHttpError(response.status, bodyText);
  }
  let payload: unknown;
  try {
    payload = JSON.parse(bodyText) as unknown;
  } catch {
    throw new LlmError('bad_response', 'The AI service sent an unreadable answer.');
  }
  return readProviderResponse(provider, payload);
}

/**
 * Asks the AI and returns its JSON answer (not yet checked against the
 * pipeline's contract; see the `parse...` functions in `aiContracts.ts`).
 * Throws `LlmError` when no usable answer arrives.
 */
export async function requestJson(request: LlmJsonRequest, options: LlmClientOptions): Promise<unknown> {
  const apiKey = (options.apiKey ?? '').trim();
  if (!apiKey) {
    throw new LlmError('no_key', 'No AI API key is set.');
  }
  const provider = options.provider ?? detectProvider(apiKey);
  const model = options.model ?? APP_CONFIG.ai.models[provider];
  const spec = buildProviderRequest(provider, model, apiKey, request);
  const doFetch: FetchLike = options.fetchImpl ?? fetch;
  const timeoutMs = options.timeoutMs ?? APP_CONFIG.ai.requestTimeoutMs;
  const maxAttempts = Math.max(1, options.maxAttempts ?? 2);
  const sleep = options.sleep ?? ((ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms)));

  let lastError: LlmError = new LlmError('network', 'The AI request did not run.');
  for (let attemptNumber = 1; attemptNumber <= maxAttempts; attemptNumber += 1) {
    try {
      return await attempt(spec, provider, doFetch, timeoutMs);
    } catch (error) {
      lastError = error instanceof LlmError ? error : new LlmError('network', 'The AI request failed.');
      if (!RETRYABLE.includes(lastError.kind) || attemptNumber === maxAttempts) {
        break;
      }
      await sleep(RETRY_DELAY_MS);
    }
  }
  throw lastError;
}
