/**
 * The daily rollup: turns the day-by-day logs into the `RollingMemoryDoc`
 * summary (averages, danger window, triggers, chart data).
 *
 * Everything here is a pure function: no clock, no storage, no network. The
 * caller passes in the logs and today's logical date and gets a new document
 * back, so the same input always gives the same output and it is safe to run
 * again after an old day is edited.
 *
 * Rules used throughout:
 * - Only finished days count. Today and anything dated later is ignored.
 * - A day with no log is "no data" and is skipped. It is never counted as
 *   zero cigarettes. A day with a log and zero cigarettes does count.
 */

import { TRIGGER_TYPES } from '../types/schema';
import type {
  ChartPoint,
  DailyLogDoc,
  RollingMemoryDoc,
  TriggerType,
} from '../types/schema';
import { addDaysToDateString, getLogicalDateRange, getWallClockHour } from '../utils/dateUtils';

export const SHORT_WINDOW_DAYS = 7;
export const LONG_WINDOW_DAYS = 30;
export const CHART_CACHE_DAYS = 30;
export const DANGER_WINDOW_HOURS = 3;

const HOURS_PER_DAY = 24;
const MS_PER_MINUTE = 60 * 1000;

export interface RollupInput {
  /**
   * Every daily log the app has, in any order. Money saved is added up over
   * all of them, so pass the full history.
   */
  logs: readonly DailyLogDoc[];
  /** The logical date of "now". The summary covers the days before it. */
  todayLogicalDate: string;
  /** The daily target that is in force today. */
  currentDailyTarget: number;
  /** The summary being replaced, if any. Its AI notes are carried over. */
  previous: RollingMemoryDoc | null;
}

function sum(values: readonly number[]): number {
  return values.reduce((total, value) => total + value, 0);
}

/** Indexes logs by logical date. If a date appears twice, the later one wins. */
function indexLogsByDate(logs: readonly DailyLogDoc[]): Map<string, DailyLogDoc> {
  const logsByDate = new Map<string, DailyLogDoc>();
  for (const log of logs) {
    logsByDate.set(log.logical_date, log);
  }
  return logsByDate;
}

function collectWindow(
  logsByDate: ReadonlyMap<string, DailyLogDoc>,
  endDate: string,
  numDays: number,
): DailyLogDoc[] {
  const logsInWindow: DailyLogDoc[] = [];
  for (const date of getLogicalDateRange(endDate, numDays)) {
    const log = logsByDate.get(date);
    if (log) {
      logsInWindow.push(log);
    }
  }
  return logsInWindow;
}

function formatHour(hour: number): string {
  return `${String(hour).padStart(2, '0')}:00`;
}

/**
 * True when `memory` does not yet cover yesterday, meaning the rollup has to
 * run before today's first screen is shown.
 */
export function shouldRunRollup(
  memory: RollingMemoryDoc | null,
  todayLogicalDate: string,
): boolean {
  return memory?.last_computed_date !== addDaysToDateString(todayLogicalDate, -1);
}

/**
 * Returns the logs that exist for the `numDays` logical days ending on
 * `endDate` (inclusive), oldest first.
 */
export function selectLogsInWindow(
  logs: readonly DailyLogDoc[],
  endDate: string,
  numDays: number,
): DailyLogDoc[] {
  return collectWindow(indexLogsByDate(logs), endDate, numDays);
}

/**
 * Average cigarettes per day across the given logs, or `null` when there are
 * none. Pass `selectLogsInWindow(logs, yesterday, 7)` for the 7-day average.
 */
export function calculateAverageDailyCount(logs: readonly DailyLogDoc[]): number | null {
  if (logs.length === 0) {
    return null;
  }
  return sum(logs.map((log) => log.total_count)) / logs.length;
}

/**
 * Counts cigarettes per hour of the day. Index 0 is 00:00-00:59, index 23 is
 * 23:00-23:59. Entries whose timestamp cannot be read are skipped.
 */
export function buildHourlyHistogram(logs: readonly DailyLogDoc[]): number[] {
  const hourlyCounts = new Array<number>(HOURS_PER_DAY).fill(0);
  for (const log of logs) {
    for (const entry of log.smoke_entries) {
      const hour = getWallClockHour(entry.timestamp);
      if (hour !== null) {
        hourlyCounts[hour] += 1;
      }
    }
  }
  return hourlyCounts;
}

/**
 * Finds the `windowHours` hours in a row with the most cigarettes and returns
 * them as `"15:00 - 18:00"`. The window may run past midnight
 * (`"23:00 - 02:00"`). Returns `null` when nothing was smoked.
 *
 * When several windows tie, the one whose first hours are the busiest wins, so
 * the window starts when the smoking starts. If they still tie, the earliest
 * one wins.
 */
export function findPeakDangerWindow(
  hourlyCounts: readonly number[],
  windowHours: number = DANGER_WINDOW_HOURS,
): string | null {
  let bestStartHour = 0;
  let bestSlots: number[] = [];
  let bestTotal = 0;

  for (let startHour = 0; startHour < HOURS_PER_DAY; startHour += 1) {
    const slots: number[] = [];
    for (let offset = 0; offset < windowHours; offset += 1) {
      slots.push(hourlyCounts[(startHour + offset) % HOURS_PER_DAY] ?? 0);
    }
    const total = sum(slots);
    const isBusier = total > bestTotal;
    const isTieThatStartsBusier = total === bestTotal && startsBusier(slots, bestSlots);
    if (isBusier || isTieThatStartsBusier) {
      bestStartHour = startHour;
      bestSlots = slots;
      bestTotal = total;
    }
  }

  if (bestTotal === 0) {
    return null;
  }
  const endHour = (bestStartHour + windowHours) % HOURS_PER_DAY;
  return `${formatHour(bestStartHour)} - ${formatHour(endHour)}`;
}

/** True when `candidate` has more cigarettes than `current` in the first hour where they differ. */
function startsBusier(candidate: readonly number[], current: readonly number[]): boolean {
  for (let index = 0; index < candidate.length; index += 1) {
    const candidateCount = candidate[index] ?? 0;
    const currentCount = current[index] ?? 0;
    if (candidateCount !== currentCount) {
      return candidateCount > currentCount;
    }
  }
  return false;
}

/** The busiest 3 hours of the day across the given logs. See `findPeakDangerWindow`. */
export function calculatePeakDangerWindow(logs: readonly DailyLogDoc[]): string | null {
  return findPeakDangerWindow(buildHourlyHistogram(logs));
}

/** Counts how often each trigger was picked. Every trigger is present, even at 0. */
export function countTriggers(logs: readonly DailyLogDoc[]): Record<TriggerType, number> {
  const counts = {} as Record<TriggerType, number>;
  for (const trigger of TRIGGER_TYPES) {
    counts[trigger] = 0;
  }
  for (const log of logs) {
    for (const entry of log.smoke_entries) {
      if (TRIGGER_TYPES.includes(entry.trigger)) {
        counts[entry.trigger] += 1;
      }
    }
  }
  return counts;
}

/**
 * Longest wait, in whole minutes, between two cigarettes of the same logical
 * day. Waits that run from one day into the next are left out because they are
 * mostly sleep. Returns `null` when no day has two cigarettes.
 */
export function calculateLongestGapMins(logs: readonly DailyLogDoc[]): number | null {
  let longestGapMins: number | null = null;
  for (const log of logs) {
    const times = log.smoke_entries
      .map((entry) => Date.parse(entry.timestamp))
      .filter((time) => Number.isFinite(time))
      .sort((a, b) => a - b);
    for (let index = 1; index < times.length; index += 1) {
      const gapMins = Math.floor((times[index] - times[index - 1]) / MS_PER_MINUTE);
      if (longestGapMins === null || gapMins > longestGapMins) {
        longestGapMins = gapMins;
      }
    }
  }
  return longestGapMins;
}

/**
 * Builds chart data for the `numDays` logical days ending on `endDate`
 * (inclusive), oldest first. Days with no log are left out, so every point
 * holds real numbers and the array can be handed straight to a chart.
 *
 * `rolling_7d_avg` is the average count of the recorded days in the 7 days
 * ending on that point's date.
 */
export function buildChartCache(
  logs: readonly DailyLogDoc[],
  endDate: string,
  numDays: number = CHART_CACHE_DAYS,
): ChartPoint[] {
  const logsByDate = indexLogsByDate(logs);
  const points: ChartPoint[] = [];
  for (const log of collectWindow(logsByDate, endDate, numDays)) {
    const trailingLogs = collectWindow(logsByDate, log.logical_date, SHORT_WINDOW_DAYS);
    points.push({
      date: log.logical_date,
      count: log.total_count,
      target: log.daily_target,
      rolling_7d_avg: sum(trailingLogs.map((trailing) => trailing.total_count)) / trailingLogs.length,
      cravings_crushed: log.cravings_crushed,
    });
  }
  return points;
}

/**
 * Builds the full `RollingMemoryDoc` for the days before `todayLogicalDate`.
 * Run it when `shouldRunRollup` says so, and again whenever a finished day is
 * edited (for example by a backdated cigarette).
 */
export function computeRollingMemory(input: RollupInput): RollingMemoryDoc {
  const yesterday = addDaysToDateString(input.todayLogicalDate, -1);
  // YYYY-MM-DD strings sort the same way as the dates they stand for.
  const finishedLogs = [...indexLogsByDate(input.logs).values()].filter(
    (log) => log.logical_date <= yesterday,
  );
  const last7Days = selectLogsInWindow(finishedLogs, yesterday, SHORT_WINDOW_DAYS);
  const last30Days = selectLogsInWindow(finishedLogs, yesterday, LONG_WINDOW_DAYS);

  return {
    last_computed_date: yesterday,
    stats: {
      current_daily_target: input.currentDailyTarget,
      avg_7_day: calculateAverageDailyCount(last7Days),
      avg_30_day: calculateAverageDailyCount(last30Days),
      longest_gap_7_day_mins: calculateLongestGapMins(last7Days),
      peak_danger_window: calculatePeakDangerWindow(last7Days),
      top_triggers_7_day: countTriggers(last7Days),
      total_money_saved_all_time: sum(finishedLogs.map((log) => log.money_saved_inr)),
    },
    ai_memory_notes: input.previous ? [...input.previous.ai_memory_notes] : [],
    chart_cache_30_days: buildChartCache(finishedLogs, yesterday, CHART_CACHE_DAYS),
  };
}
