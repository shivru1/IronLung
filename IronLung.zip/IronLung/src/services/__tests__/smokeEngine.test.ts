import type { ChatMessage, DailyLogDoc, SettingsDoc } from '../../types/schema';
import {
  addBrainDumpHeadline,
  addCravingCrushed,
  addSmoke,
  appendChatMessage,
  appendMemoryNote,
  applySettingsToDay,
  calculateMoneySaved,
  clampTargetGapMins,
  createDailyLog,
  defaultTargetGapMins,
  finalizeDay,
  findLastSmoke,
  getElapsedMins,
  getGapProgressPercent,
  recomputeGaps,
  removeBrainDumpHeadline,
  removeLastSmoke,
  retagLastSmoke,
} from '../smokeEngine';
import type { DailyLogs, DayDefaults } from '../smokeEngine';

// Dates are built with the local-time constructor, so the tests give the same
// result in every time zone.

const DEFAULTS: DayDefaults = {
  dailyTarget: 8,
  dailyBaseline: 15,
  costPerCigInr: 20,
  activeTargetGapMins: 120,
};

/** A moment on a day of November 2026, on the phone's clock. */
function november(day: number, hour: number, minute = 0): Date {
  return new Date(2026, 10, day, hour, minute);
}

function smokeAt(logs: DailyLogs, id: string, when: Date): DailyLogs {
  return addSmoke(logs, {
    id,
    trigger: 'Craving',
    smokedAt: when,
    backdatedMins: 0,
    defaultsFor: () => DEFAULTS,
  }).logs;
}

function dayWith(overrides: Partial<DailyLogDoc>): DailyLogDoc {
  return { ...createDailyLog('2026-11-19', DEFAULTS), ...overrides };
}

function message(id: string): ChatMessage {
  return { id, role: 'user', text: id, timestamp: '2026-11-19T10:00:00.000+05:30' };
}

describe('defaultTargetGapMins', () => {
  it('spreads a target of 8 over 16 waking hours', () => {
    expect(defaultTargetGapMins(8)).toBe(120);
  });

  it('rounds to the nearest 5 minutes', () => {
    expect(defaultTargetGapMins(15)).toBe(65);
  });

  it('never goes below the shortest allowed wait', () => {
    expect(defaultTargetGapMins(100)).toBe(15);
  });

  it('uses the longest allowed wait for a target of zero', () => {
    expect(defaultTargetGapMins(0)).toBe(480);
  });
});

describe('clampTargetGapMins', () => {
  it('keeps a value that is in range', () => {
    expect(clampTargetGapMins(150)).toBe(150);
  });

  it('raises a value that is too short', () => {
    expect(clampTargetGapMins(5)).toBe(15);
  });

  it('lowers a value that is too long', () => {
    expect(clampTargetGapMins(1000)).toBe(480);
  });

  it('rounds to a whole minute', () => {
    expect(clampTargetGapMins(150.4)).toBe(150);
  });

  it('falls back to the shortest wait for a value that is not a number', () => {
    expect(clampTargetGapMins(Number.NaN)).toBe(15);
  });
});

describe('calculateMoneySaved', () => {
  it('counts only crushed cravings while the day is running', () => {
    const saved = calculateMoneySaved({
      cravingsCrushed: 3,
      smokeCount: 4,
      dailyBaseline: 15,
      costPerCigInr: 20,
      isFinal: false,
    });

    expect(saved).toBe(60);
  });

  it('uses the cigarettes under baseline at day end when that is more', () => {
    const saved = calculateMoneySaved({
      cravingsCrushed: 3,
      smokeCount: 6,
      dailyBaseline: 15,
      costPerCigInr: 20,
      isFinal: true,
    });

    expect(saved).toBe(180);
  });

  it('keeps the crushed cravings at day end when that is more', () => {
    const saved = calculateMoneySaved({
      cravingsCrushed: 2,
      smokeCount: 16,
      dailyBaseline: 15,
      costPerCigInr: 20,
      isFinal: true,
    });

    expect(saved).toBe(40);
  });

  it('saves nothing on a day at baseline with no crushed cravings', () => {
    const saved = calculateMoneySaved({
      cravingsCrushed: 0,
      smokeCount: 15,
      dailyBaseline: 15,
      costPerCigInr: 20,
      isFinal: true,
    });

    expect(saved).toBe(0);
  });
});

describe('createDailyLog', () => {
  it('starts an empty day with the given defaults', () => {
    expect(createDailyLog('2026-11-19', DEFAULTS)).toEqual({
      logical_date: '2026-11-19',
      total_count: 0,
      daily_target: 8,
      daily_baseline: 15,
      cost_per_cig_inr: 20,
      smoke_entries: [],
      cravings_crushed: 0,
      money_saved_inr: 0,
      active_target_gap_mins: 120,
      todays_brain_dump_headlines: [],
      chat_buffer: [],
      is_finalized: false,
    });
  });
});

describe('addSmoke', () => {
  it('creates the day and logs the first cigarette with no gap', () => {
    const result = addSmoke(
      {},
      {
        id: 'a',
        trigger: 'Work Stress',
        smokedAt: november(19, 15, 30),
        backdatedMins: 0,
        defaultsFor: () => DEFAULTS,
      },
    );

    expect(result.logicalDate).toBe('2026-11-19');
    expect(result.logs['2026-11-19']?.total_count).toBe(1);
    expect(result.entry.trigger).toBe('Work Stress');
    expect(result.entry.gap_from_previous_mins).toBeNull();
    expect(result.entry.backdated_mins).toBe(0);
  });

  it('measures the gap from the previous cigarette of the same day', () => {
    const logs = smokeAt({}, 'a', november(19, 10, 0));

    const result = addSmoke(logs, {
      id: 'b',
      trigger: 'Craving',
      smokedAt: november(19, 11, 30),
      backdatedMins: 0,
      defaultsFor: () => DEFAULTS,
    });

    expect(result.entry.gap_from_previous_mins).toBe(90);
    expect(result.logs['2026-11-19']?.total_count).toBe(2);
  });

  it('measures the first cigarette of a day from the last one of the day before', () => {
    const logs = smokeAt({}, 'a', november(19, 22, 0));

    const result = addSmoke(logs, {
      id: 'b',
      trigger: 'Craving',
      smokedAt: november(20, 8, 30),
      backdatedMins: 0,
      defaultsFor: () => DEFAULTS,
    });

    expect(result.logicalDate).toBe('2026-11-20');
    expect(result.entry.gap_from_previous_mins).toBe(630);
  });

  it('files a 1:30 AM cigarette under the previous logical day', () => {
    const result = addSmoke(
      {},
      {
        id: 'a',
        trigger: 'Late Night',
        smokedAt: november(20, 1, 30),
        backdatedMins: 0,
        defaultsFor: () => DEFAULTS,
      },
    );

    expect(result.logicalDate).toBe('2026-11-19');
    expect(Object.keys(result.logs)).toEqual(['2026-11-19']);
  });

  it('files a backdated cigarette under yesterday when it crosses 4 AM', () => {
    const logs = smokeAt({}, 'today', november(20, 4, 20));

    const result = addSmoke(logs, {
      id: 'backdated',
      trigger: 'Craving',
      smokedAt: november(20, 3, 50),
      backdatedMins: 30,
      defaultsFor: () => DEFAULTS,
    });

    expect(result.logicalDate).toBe('2026-11-19');
    expect(result.entry.backdated_mins).toBe(30);
    expect(result.logs['2026-11-19']?.total_count).toBe(1);
    expect(result.logs['2026-11-20']?.smoke_entries[0]?.gap_from_previous_mins).toBe(30);
  });

  it('recomputes the following gap when a backdated cigarette lands between two others', () => {
    const logs = smokeAt(smokeAt({}, 'first', november(19, 10, 0)), 'third', november(19, 12, 0));

    const result = addSmoke(logs, {
      id: 'second',
      trigger: 'Craving',
      smokedAt: november(19, 11, 0),
      backdatedMins: 60,
      defaultsFor: () => DEFAULTS,
    });

    const entries = result.logs['2026-11-19']?.smoke_entries ?? [];
    expect(entries.map((entry) => entry.id)).toEqual(['first', 'second', 'third']);
    expect(entries.map((entry) => entry.gap_from_previous_mins)).toEqual([null, 60, 60]);
  });

  it('uses the day defaults only when the day has no log yet', () => {
    const logs = smokeAt({}, 'a', november(19, 10, 0));

    const result = addSmoke(logs, {
      id: 'b',
      trigger: 'Craving',
      smokedAt: november(19, 11, 0),
      backdatedMins: 0,
      defaultsFor: () => ({ ...DEFAULTS, dailyTarget: 3 }),
    });

    expect(result.logs['2026-11-19']?.daily_target).toBe(8);
  });

  it('does not change the logs it was given', () => {
    const logs = smokeAt({}, 'a', november(19, 10, 0));

    addSmoke(logs, {
      id: 'b',
      trigger: 'Craving',
      smokedAt: november(19, 11, 0),
      backdatedMins: 0,
      defaultsFor: () => DEFAULTS,
    });

    expect(logs['2026-11-19']?.total_count).toBe(1);
  });
});

describe('recomputeGaps', () => {
  it("updates the next day's first gap after a late cigarette is added to a day", () => {
    const logs = smokeAt(smokeAt({}, 'evening', november(19, 20, 0)), 'morning', november(20, 9, 0));

    const updated = smokeAt(logs, 'late', november(19, 23, 0));

    expect(updated['2026-11-20']?.smoke_entries[0]?.gap_from_previous_mins).toBe(600);
  });

  it('skips empty days when looking for the previous cigarette', () => {
    const base = smokeAt({}, 'old', november(17, 12, 0));
    const withEmptyDay: DailyLogs = { ...base, '2026-11-18': createDailyLog('2026-11-18', DEFAULTS) };
    const logs = smokeAt(withEmptyDay, 'new', november(19, 12, 0));

    const updated = recomputeGaps(logs, '2026-11-19');

    expect(updated['2026-11-19']?.smoke_entries[0]?.gap_from_previous_mins).toBe(2880);
  });
});

describe('findLastSmoke', () => {
  it('returns null when nothing was ever logged', () => {
    expect(findLastSmoke({})).toBeNull();
  });

  it('finds the newest cigarette across days', () => {
    const logs = smokeAt(smokeAt({}, 'old', november(19, 22, 0)), 'new', november(20, 9, 0));

    const last = findLastSmoke(logs);

    expect(last?.entry.id).toBe('new');
    expect(last?.logicalDate).toBe('2026-11-20');
  });

  it('ignores cigarettes after the given moment', () => {
    const logs = smokeAt(smokeAt({}, 'old', november(19, 22, 0)), 'new', november(20, 9, 0));

    const last = findLastSmoke(logs, november(20, 8, 0).getTime());

    expect(last?.entry.id).toBe('old');
  });
});

describe('removeLastSmoke', () => {
  it('returns null when there is nothing to undo', () => {
    expect(removeLastSmoke({})).toBeNull();
  });

  it('removes the newest cigarette and keeps the earlier ones', () => {
    const logs = smokeAt(smokeAt({}, 'a', november(19, 10, 0)), 'b', november(19, 12, 0));

    const result = removeLastSmoke(logs);

    expect(result?.removed.id).toBe('b');
    expect(result?.logicalDate).toBe('2026-11-19');
    expect(result?.logs['2026-11-19']?.total_count).toBe(1);
    expect(result?.logs['2026-11-19']?.smoke_entries.map((entry) => entry.id)).toEqual(['a']);
  });

  it('reaches back to yesterday when today has no cigarette', () => {
    const base = smokeAt({}, 'yesterday', november(19, 22, 0));
    const logs: DailyLogs = { ...base, '2026-11-20': createDailyLog('2026-11-20', DEFAULTS) };

    const result = removeLastSmoke(logs);

    expect(result?.removed.id).toBe('yesterday');
    expect(result?.logs['2026-11-19']?.total_count).toBe(0);
  });
});

describe('retagLastSmoke', () => {
  it('changes the trigger of the newest cigarette only', () => {
    const logs = smokeAt(smokeAt({}, 'a', november(19, 10, 0)), 'b', november(19, 12, 0));

    const result = retagLastSmoke(logs, 'Post-Meal');

    expect(result?.entry.id).toBe('b');
    expect(result?.logs['2026-11-19']?.smoke_entries.map((entry) => entry.trigger)).toEqual([
      'Craving',
      'Post-Meal',
    ]);
  });

  it('returns null when nothing was ever logged', () => {
    expect(retagLastSmoke({}, 'Social')).toBeNull();
  });
});

describe('finalizeDay', () => {
  it('switches money saved to the end-of-day rule', () => {
    const running = dayWith({ total_count: 6, cravings_crushed: 3, money_saved_inr: 60 });

    const closed = finalizeDay(running);

    expect(closed.is_finalized).toBe(true);
    expect(closed.money_saved_inr).toBe(180);
  });

  it('keeps the final rule when a cigarette is added to the closed day later', () => {
    const closed = finalizeDay(dayWith({ logical_date: '2026-11-19' }));
    const logs: DailyLogs = { '2026-11-19': closed };

    const updated = smokeAt(logs, 'late', november(19, 23, 0));

    expect(updated['2026-11-19']?.money_saved_inr).toBe(280);
  });
});

describe('applySettingsToDay', () => {
  const settings: SettingsDoc = {
    daily_baseline: 20,
    daily_target: 5,
    cost_per_cig_inr: 25,
    selected_trigger: 'Craving',
    updated_at: '2026-11-19T10:00:00.000+05:30',
  };

  it('copies the new settings into a running day and reprices its savings', () => {
    const running = dayWith({ cravings_crushed: 2, money_saved_inr: 40 });

    const updated = applySettingsToDay(running, settings);

    expect(updated.daily_target).toBe(5);
    expect(updated.daily_baseline).toBe(20);
    expect(updated.cost_per_cig_inr).toBe(25);
    expect(updated.money_saved_inr).toBe(50);
  });

  it('leaves a finished day alone', () => {
    const closed = finalizeDay(dayWith({ cravings_crushed: 2 }));

    expect(applySettingsToDay(closed, settings)).toEqual(closed);
  });
});

describe('addCravingCrushed', () => {
  it('counts the craving and adds the price of one cigarette', () => {
    const day = dayWith({ cravings_crushed: 2, money_saved_inr: 40 });

    const updated = addCravingCrushed(day);

    expect(updated.cravings_crushed).toBe(3);
    expect(updated.money_saved_inr).toBe(60);
  });
});

describe('getElapsedMins', () => {
  it('returns null when there is no cigarette', () => {
    expect(getElapsedMins(null, november(19, 12, 0).getTime())).toBeNull();
  });

  it('counts whole minutes since the cigarette', () => {
    const logs = smokeAt({}, 'a', november(19, 12, 34));
    const entry = findLastSmoke(logs)?.entry ?? null;

    expect(getElapsedMins(entry, november(19, 14, 52).getTime())).toBe(138);
  });
});

describe('getGapProgressPercent', () => {
  it('is zero when there is no cigarette to count from', () => {
    expect(getGapProgressPercent(null, 150)).toBe(0);
  });

  it('is the share of the target that has passed', () => {
    expect(getGapProgressPercent(138, 150)).toBeCloseTo(92, 5);
  });

  it('stops at 100 once the target is reached', () => {
    expect(getGapProgressPercent(400, 150)).toBe(100);
  });
});

describe('appendChatMessage', () => {
  it('keeps only the newest six messages', () => {
    const full = dayWith({
      chat_buffer: [message('1'), message('2'), message('3'), message('4'), message('5'), message('6')],
    });

    const updated = appendChatMessage(full, message('7'));

    expect(updated.chat_buffer.map((m) => m.id)).toEqual(['2', '3', '4', '5', '6', '7']);
  });
});

describe('brain dump headlines', () => {
  it('adds a trimmed headline to the day', () => {
    const updated = addBrainDumpHeadline(dayWith({}), '  Client deck deadline  ');

    expect(updated.todays_brain_dump_headlines).toEqual(['Client deck deadline']);
  });

  it('ignores an empty headline', () => {
    const updated = addBrainDumpHeadline(dayWith({}), '   ');

    expect(updated.todays_brain_dump_headlines).toEqual([]);
  });

  it('removes one copy of a headline', () => {
    const day = dayWith({ todays_brain_dump_headlines: ['A', 'B', 'A'] });

    const updated = removeBrainDumpHeadline(day, 'A');

    expect(updated.todays_brain_dump_headlines).toEqual(['B', 'A']);
  });
});

describe('appendMemoryNote', () => {
  it('adds a new note at the end', () => {
    expect(appendMemoryNote(['Smokes after stand-up.'], 'Skips lunch on deadline days.')).toEqual([
      'Smokes after stand-up.',
      'Skips lunch on deadline days.',
    ]);
  });

  it('does not add a note that is already known', () => {
    expect(appendMemoryNote(['Smokes after stand-up.'], ' smokes after stand-up. ')).toEqual([
      'Smokes after stand-up.',
    ]);
  });

  it('ignores a missing note', () => {
    expect(appendMemoryNote(['A'], null)).toEqual(['A']);
  });

  it('drops the oldest note once there are more than ten', () => {
    const ten = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];

    expect(appendMemoryNote(ten, '11')).toEqual(['2', '3', '4', '5', '6', '7', '8', '9', '10', '11']);
  });
});
