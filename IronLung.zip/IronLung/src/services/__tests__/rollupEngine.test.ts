import type {
  DailyLogDoc,
  RollingMemoryDoc,
  SmokeEntry,
  TriggerType,
} from '../../types/schema';
import {
  buildChartCache,
  buildHourlyHistogram,
  calculateAverageDailyCount,
  calculateLongestGapMins,
  calculatePeakDangerWindow,
  computeRollingMemory,
  countTriggers,
  findPeakDangerWindow,
  selectLogsInWindow,
  shouldRunRollup,
} from '../rollupEngine';

// Every timestamp carries its own UTC offset, so these tests give the same
// result in every time zone.

function smoke(timestamp: string, trigger: TriggerType = 'Craving'): SmokeEntry {
  return {
    id: timestamp,
    timestamp,
    trigger,
    gap_from_previous_mins: null,
    backdated_mins: 0,
  };
}

function dayLog(logicalDate: string, overrides: Partial<DailyLogDoc> = {}): DailyLogDoc {
  return {
    logical_date: logicalDate,
    total_count: 0,
    daily_target: 10,
    daily_baseline: 15,
    cost_per_cig_inr: 20,
    smoke_entries: [],
    cravings_crushed: 0,
    money_saved_inr: 0,
    active_target_gap_mins: 60,
    todays_brain_dump_headlines: [],
    chat_buffer: [],
    is_finalized: true,
    ...overrides,
  };
}

function memoryComputedThrough(date: string): RollingMemoryDoc {
  return {
    last_computed_date: date,
    stats: {
      current_daily_target: 10,
      avg_7_day: null,
      avg_30_day: null,
      longest_gap_7_day_mins: null,
      peak_danger_window: null,
      top_triggers_7_day: {
        'Work Stress': 0,
        'Post-Meal': 0,
        Boredom: 0,
        Social: 0,
        'Late Night': 0,
        Craving: 0,
      },
      total_money_saved_all_time: 0,
    },
    ai_memory_notes: [],
    chart_cache_30_days: [],
  };
}

/** A 24-slot histogram that is zero everywhere except the given hours. */
function hourlyCounts(countsByHour: Record<number, number>): number[] {
  const counts = new Array<number>(24).fill(0);
  for (const [hour, count] of Object.entries(countsByHour)) {
    counts[Number(hour)] = count;
  }
  return counts;
}

describe('shouldRunRollup', () => {
  it('runs when there is no summary yet', () => {
    expect(shouldRunRollup(null, '2026-11-19')).toBe(true);
  });

  it('does not run when the summary already covers yesterday', () => {
    const memory = memoryComputedThrough('2026-11-18');

    expect(shouldRunRollup(memory, '2026-11-19')).toBe(false);
  });

  it('runs when the summary stops before yesterday', () => {
    const memory = memoryComputedThrough('2026-11-17');

    expect(shouldRunRollup(memory, '2026-11-19')).toBe(true);
  });
});

describe('selectLogsInWindow', () => {
  it('keeps only the days inside the window, oldest first', () => {
    const logs = [
      dayLog('2026-11-18'),
      dayLog('2026-11-11'),
      dayLog('2026-11-12'),
      dayLog('2026-11-19'),
    ];

    const selected = selectLogsInWindow(logs, '2026-11-18', 7);

    expect(selected.map((log) => log.logical_date)).toEqual(['2026-11-12', '2026-11-18']);
  });
});

describe('calculateAverageDailyCount', () => {
  it('returns null when there are no days', () => {
    expect(calculateAverageDailyCount([])).toBeNull();
  });

  it('averages the daily counts', () => {
    const logs = [
      dayLog('2026-11-17', { total_count: 4 }),
      dayLog('2026-11-18', { total_count: 9 }),
    ];

    expect(calculateAverageDailyCount(logs)).toBe(6.5);
  });

  it('counts a recorded day with zero cigarettes', () => {
    const logs = [
      dayLog('2026-11-17', { total_count: 0 }),
      dayLog('2026-11-18', { total_count: 10 }),
    ];

    expect(calculateAverageDailyCount(logs)).toBe(5);
  });
});

describe('buildHourlyHistogram', () => {
  it('counts cigarettes by the hour on the clock', () => {
    const logs = [
      dayLog('2026-11-17', {
        smoke_entries: [
          smoke('2026-11-17T09:05:00.000+05:30'),
          smoke('2026-11-17T15:10:00.000+05:30'),
        ],
      }),
      dayLog('2026-11-18', {
        smoke_entries: [smoke('2026-11-18T15:59:00.000+05:30')],
      }),
    ];

    expect(buildHourlyHistogram(logs)).toEqual(hourlyCounts({ 9: 1, 15: 2 }));
  });

  it('files a cigarette after midnight under its own hour', () => {
    const logs = [
      dayLog('2026-11-18', {
        smoke_entries: [smoke('2026-11-19T01:30:00.000+05:30')],
      }),
    ];

    expect(buildHourlyHistogram(logs)).toEqual(hourlyCounts({ 1: 1 }));
  });

  it('skips an entry whose timestamp cannot be read', () => {
    const logs = [
      dayLog('2026-11-18', {
        smoke_entries: [smoke('not a date'), smoke('2026-11-18T15:10:00.000+05:30')],
      }),
    ];

    expect(buildHourlyHistogram(logs)).toEqual(hourlyCounts({ 15: 1 }));
  });
});

describe('findPeakDangerWindow', () => {
  it('returns null when nothing was smoked', () => {
    expect(findPeakDangerWindow(hourlyCounts({}))).toBeNull();
  });

  it('finds the three busiest hours in a row', () => {
    const counts = hourlyCounts({ 9: 2, 15: 3, 16: 4, 17: 2, 21: 1 });

    expect(findPeakDangerWindow(counts)).toBe('15:00 - 18:00');
  });

  it('prefers the bigger total over a single busy hour', () => {
    const counts = hourlyCounts({ 8: 5, 14: 2, 15: 2, 16: 2 });

    expect(findPeakDangerWindow(counts)).toBe('14:00 - 17:00');
  });

  it('wraps around midnight', () => {
    const counts = hourlyCounts({ 23: 3, 0: 2, 1: 2, 12: 1 });

    expect(findPeakDangerWindow(counts)).toBe('23:00 - 02:00');
  });

  it('writes a window that ends at midnight as 00:00', () => {
    const counts = hourlyCounts({ 21: 2, 22: 2, 23: 2 });

    expect(findPeakDangerWindow(counts)).toBe('21:00 - 00:00');
  });

  it('starts the window at the busy hour when only one hour has cigarettes', () => {
    const counts = hourlyCounts({ 15: 5 });

    expect(findPeakDangerWindow(counts)).toBe('15:00 - 18:00');
  });

  it('starts a tied window where the smoking starts', () => {
    const counts = hourlyCounts({ 15: 3, 16: 3 });

    expect(findPeakDangerWindow(counts)).toBe('15:00 - 18:00');
  });

  it('picks the earlier of two equal windows', () => {
    const counts = hourlyCounts({ 9: 2, 20: 2 });

    expect(findPeakDangerWindow(counts)).toBe('09:00 - 12:00');
  });
});

describe('calculatePeakDangerWindow', () => {
  it('finds the busiest three hours across several days', () => {
    const logs = [
      dayLog('2026-11-17', {
        smoke_entries: [
          smoke('2026-11-17T09:00:00.000+05:30'),
          smoke('2026-11-17T15:30:00.000+05:30'),
          smoke('2026-11-17T17:45:00.000+05:30'),
        ],
      }),
      dayLog('2026-11-18', {
        smoke_entries: [
          smoke('2026-11-18T15:10:00.000+05:30'),
          smoke('2026-11-18T16:40:00.000+05:30'),
        ],
      }),
    ];

    expect(calculatePeakDangerWindow(logs)).toBe('15:00 - 18:00');
  });
});

describe('countTriggers', () => {
  it('counts each trigger and keeps the unused ones at zero', () => {
    const logs = [
      dayLog('2026-11-17', {
        smoke_entries: [
          smoke('2026-11-17T09:00:00.000+05:30', 'Post-Meal'),
          smoke('2026-11-17T15:30:00.000+05:30', 'Work Stress'),
        ],
      }),
      dayLog('2026-11-18', {
        smoke_entries: [smoke('2026-11-18T15:10:00.000+05:30', 'Work Stress')],
      }),
    ];

    expect(countTriggers(logs)).toEqual({
      'Work Stress': 2,
      'Post-Meal': 1,
      Boredom: 0,
      Social: 0,
      'Late Night': 0,
      Craving: 0,
    });
  });
});

describe('calculateLongestGapMins', () => {
  it('returns null when no day has two cigarettes', () => {
    const logs = [
      dayLog('2026-11-17', { smoke_entries: [smoke('2026-11-17T09:00:00.000+05:30')] }),
      dayLog('2026-11-18', { smoke_entries: [smoke('2026-11-18T09:00:00.000+05:30')] }),
    ];

    expect(calculateLongestGapMins(logs)).toBeNull();
  });

  it('finds the longest wait inside a day', () => {
    const logs = [
      dayLog('2026-11-18', {
        smoke_entries: [
          smoke('2026-11-18T09:00:00.000+05:30'),
          smoke('2026-11-18T10:30:00.000+05:30'),
          smoke('2026-11-18T14:00:00.000+05:30'),
        ],
      }),
    ];

    expect(calculateLongestGapMins(logs)).toBe(210);
  });

  it('ignores the overnight wait between two days', () => {
    const logs = [
      dayLog('2026-11-17', {
        smoke_entries: [
          smoke('2026-11-17T20:00:00.000+05:30'),
          smoke('2026-11-17T21:00:00.000+05:30'),
        ],
      }),
      dayLog('2026-11-18', {
        smoke_entries: [
          smoke('2026-11-18T09:00:00.000+05:30'),
          smoke('2026-11-18T09:45:00.000+05:30'),
        ],
      }),
    ];

    expect(calculateLongestGapMins(logs)).toBe(60);
  });

  it('measures across midnight inside one logical day', () => {
    const logs = [
      dayLog('2026-11-18', {
        smoke_entries: [
          smoke('2026-11-18T23:30:00.000+05:30'),
          smoke('2026-11-19T01:30:00.000+05:30'),
        ],
      }),
    ];

    expect(calculateLongestGapMins(logs)).toBe(120);
  });

  it('handles entries that are stored out of order', () => {
    const logs = [
      dayLog('2026-11-18', {
        smoke_entries: [
          smoke('2026-11-18T14:00:00.000+05:30'),
          smoke('2026-11-18T09:00:00.000+05:30'),
          smoke('2026-11-18T10:30:00.000+05:30'),
        ],
      }),
    ];

    expect(calculateLongestGapMins(logs)).toBe(210);
  });

  it('rounds a wait down to whole minutes', () => {
    const logs = [
      dayLog('2026-11-18', {
        smoke_entries: [
          smoke('2026-11-18T09:00:00.000+05:30'),
          smoke('2026-11-18T09:59:59.000+05:30'),
        ],
      }),
    ];

    expect(calculateLongestGapMins(logs)).toBe(59);
  });
});

describe('buildChartCache', () => {
  it('returns one point per recorded day, oldest first, and leaves out missing days', () => {
    const logs = [
      dayLog('2026-11-18', { total_count: 2, daily_target: 8, cravings_crushed: 1 }),
      dayLog('2026-11-16', { total_count: 4, daily_target: 9, cravings_crushed: 3 }),
    ];

    expect(buildChartCache(logs, '2026-11-18', 30)).toEqual([
      { date: '2026-11-16', count: 4, target: 9, rolling_7d_avg: 4, cravings_crushed: 3 },
      { date: '2026-11-18', count: 2, target: 8, rolling_7d_avg: 3, cravings_crushed: 1 },
    ]);
  });

  it('averages only the 7 days ending on each point', () => {
    const logs = [
      dayLog('2026-11-10', { total_count: 20 }),
      dayLog('2026-11-11', { total_count: 6 }),
      dayLog('2026-11-17', { total_count: 2 }),
    ];

    const points = buildChartCache(logs, '2026-11-17', 30);

    expect(points.map((point) => point.rolling_7d_avg)).toEqual([20, 13, 4]);
  });

  it('leaves out days before the window and after the end date', () => {
    const logs = [
      dayLog('2026-11-10', { total_count: 5 }),
      dayLog('2026-11-16', { total_count: 4 }),
      dayLog('2026-11-18', { total_count: 2 }),
      dayLog('2026-11-19', { total_count: 9 }),
    ];

    const points = buildChartCache(logs, '2026-11-18', 3);

    expect(points.map((point) => point.date)).toEqual(['2026-11-16', '2026-11-18']);
  });

  it('returns an empty list when there are no logs', () => {
    expect(buildChartCache([], '2026-11-18', 30)).toEqual([]);
  });
});

describe('computeRollingMemory', () => {
  it('summarises the finished days and ignores today', () => {
    const logs = [
      // Today: must not show up anywhere.
      dayLog('2026-11-19', {
        total_count: 99,
        money_saved_inr: 999,
        smoke_entries: [smoke('2026-11-19T06:00:00.000+05:30', 'Craving')],
      }),
      // Yesterday.
      dayLog('2026-11-18', {
        total_count: 2,
        daily_target: 8,
        cravings_crushed: 1,
        money_saved_inr: 20,
        smoke_entries: [
          smoke('2026-11-18T15:10:00.000+05:30', 'Work Stress'),
          smoke('2026-11-18T16:40:00.000+05:30', 'Work Stress'),
        ],
      }),
      // Inside the last 7 days.
      dayLog('2026-11-16', {
        total_count: 4,
        daily_target: 8,
        smoke_entries: [
          smoke('2026-11-16T09:00:00.000+05:30', 'Post-Meal'),
          smoke('2026-11-16T15:30:00.000+05:30', 'Boredom'),
          smoke('2026-11-16T16:05:00.000+05:30', 'Work Stress'),
          smoke('2026-11-16T17:45:00.000+05:30', 'Social'),
        ],
      }),
      // Older than 7 days, inside the last 30. Six cigarettes in one hour,
      // which would move the danger window if it were wrongly included.
      dayLog('2026-11-10', {
        total_count: 6,
        daily_target: 9,
        money_saved_inr: 40,
        smoke_entries: [
          smoke('2026-11-10T08:00:00.000+05:30', 'Late Night'),
          smoke('2026-11-10T08:05:00.000+05:30', 'Late Night'),
          smoke('2026-11-10T08:10:00.000+05:30', 'Late Night'),
          smoke('2026-11-10T08:15:00.000+05:30', 'Late Night'),
          smoke('2026-11-10T08:20:00.000+05:30', 'Late Night'),
          smoke('2026-11-10T19:00:00.000+05:30', 'Late Night'),
        ],
      }),
      // Older than 30 days: only its money still counts.
      dayLog('2026-10-01', { total_count: 20, money_saved_inr: 100 }),
    ];
    const previous: RollingMemoryDoc = {
      ...memoryComputedThrough('2026-11-17'),
      ai_memory_notes: ['Smokes most right after stand-up meetings.'],
    };

    const memory = computeRollingMemory({
      logs,
      todayLogicalDate: '2026-11-19',
      currentDailyTarget: 7,
      previous,
    });

    expect(memory).toEqual({
      last_computed_date: '2026-11-18',
      stats: {
        current_daily_target: 7,
        avg_7_day: 3,
        avg_30_day: 4,
        longest_gap_7_day_mins: 390,
        peak_danger_window: '15:00 - 18:00',
        top_triggers_7_day: {
          'Work Stress': 3,
          'Post-Meal': 1,
          Boredom: 1,
          Social: 1,
          'Late Night': 0,
          Craving: 0,
        },
        total_money_saved_all_time: 160,
      },
      ai_memory_notes: ['Smokes most right after stand-up meetings.'],
      chart_cache_30_days: [
        { date: '2026-11-10', count: 6, target: 9, rolling_7d_avg: 6, cravings_crushed: 0 },
        { date: '2026-11-16', count: 4, target: 8, rolling_7d_avg: 5, cravings_crushed: 0 },
        { date: '2026-11-18', count: 2, target: 8, rolling_7d_avg: 3, cravings_crushed: 1 },
      ],
    });
  });

  it('returns an empty summary for a brand-new user', () => {
    const memory = computeRollingMemory({
      logs: [],
      todayLogicalDate: '2026-11-19',
      currentDailyTarget: 10,
      previous: null,
    });

    expect(memory).toEqual(memoryComputedThrough('2026-11-18'));
  });

  it('gives the same answer when it is run a second time', () => {
    const logs = [
      dayLog('2026-11-18', {
        total_count: 1,
        money_saved_inr: 20,
        smoke_entries: [smoke('2026-11-18T15:10:00.000+05:30', 'Social')],
      }),
    ];
    const first = computeRollingMemory({
      logs,
      todayLogicalDate: '2026-11-19',
      currentDailyTarget: 10,
      previous: null,
    });

    const second = computeRollingMemory({
      logs,
      todayLogicalDate: '2026-11-19',
      currentDailyTarget: 10,
      previous: first,
    });

    expect(second).toEqual(first);
  });

  it('counts a date that appears twice only once', () => {
    const logs = [
      dayLog('2026-11-18', { total_count: 3, money_saved_inr: 20 }),
      dayLog('2026-11-18', { total_count: 5, money_saved_inr: 60 }),
    ];

    const memory = computeRollingMemory({
      logs,
      todayLogicalDate: '2026-11-19',
      currentDailyTarget: 10,
      previous: null,
    });

    expect(memory.stats.avg_7_day).toBe(5);
    expect(memory.stats.total_money_saved_all_time).toBe(60);
  });
});
