import type { ChartPoint, DailyLogDoc, SmokeEntry, TriggerType } from '../../types/schema';
import {
  buildChartSlots,
  buildDangerProfile,
  computeStatsKpis,
  getBarTone,
  rankTriggers,
  rankTriggersInRange,
} from '../statsEngine';

// Every timestamp carries its own UTC offset, so these tests give the same
// result in every time zone. 24 November 2026 is a Tuesday.

function smoke(timestamp: string, trigger: TriggerType = 'Craving'): SmokeEntry {
  return { id: timestamp, timestamp, trigger, gap_from_previous_mins: null, backdated_mins: 0 };
}

function dayLog(logicalDate: string, overrides: Partial<DailyLogDoc> = {}): DailyLogDoc {
  return {
    logical_date: logicalDate,
    total_count: 0,
    daily_target: 6,
    daily_baseline: 15,
    cost_per_cig_inr: 20,
    smoke_entries: [],
    cravings_crushed: 0,
    money_saved_inr: 0,
    active_target_gap_mins: 120,
    todays_brain_dump_headlines: [],
    chat_buffer: [],
    is_finalized: true,
    ...overrides,
  };
}

function point(date: string, count: number, rollingAvg: number, cravingsCrushed = 0): ChartPoint {
  return { date, count, target: 6, rolling_7d_avg: rollingAvg, cravings_crushed: cravingsCrushed };
}

describe('buildChartSlots', () => {
  it('lays out the days ending today and keeps empty days in place', () => {
    const slots = buildChartSlots({
      chartCache: [point('2026-11-20', 5, 5, 1), point('2026-11-22', 7, 6)],
      todayLog: dayLog('2026-11-24', { total_count: 3, cravings_crushed: 2, is_finalized: false }),
      todayDate: '2026-11-24',
      numDays: 7,
    });

    expect(slots).toEqual([
      { date: '2026-11-18', weekday: 'WED', dayOfMonth: 18, count: null, target: null, rolling7dAvg: null, cravingsCrushed: null, isToday: false },
      { date: '2026-11-19', weekday: 'THU', dayOfMonth: 19, count: null, target: null, rolling7dAvg: null, cravingsCrushed: null, isToday: false },
      { date: '2026-11-20', weekday: 'FRI', dayOfMonth: 20, count: 5, target: 6, rolling7dAvg: 5, cravingsCrushed: 1, isToday: false },
      { date: '2026-11-21', weekday: 'SAT', dayOfMonth: 21, count: null, target: null, rolling7dAvg: null, cravingsCrushed: null, isToday: false },
      { date: '2026-11-22', weekday: 'SUN', dayOfMonth: 22, count: 7, target: 6, rolling7dAvg: 6, cravingsCrushed: 0, isToday: false },
      { date: '2026-11-23', weekday: 'MON', dayOfMonth: 23, count: null, target: null, rolling7dAvg: null, cravingsCrushed: null, isToday: false },
      { date: '2026-11-24', weekday: 'TUE', dayOfMonth: 24, count: 3, target: 6, rolling7dAvg: 5, cravingsCrushed: 2, isToday: true },
    ]);
  });

  it('leaves out of today\'s average the days more than a week back', () => {
    const slots = buildChartSlots({
      chartCache: [point('2026-11-17', 20, 20), point('2026-11-23', 5, 5)],
      todayLog: dayLog('2026-11-24', { total_count: 1 }),
      todayDate: '2026-11-24',
      numDays: 7,
    });

    expect(slots[6]?.rolling7dAvg).toBe(3);
  });

  it('shows an empty slot for today before the day has a log', () => {
    const slots = buildChartSlots({ chartCache: [], todayLog: null, todayDate: '2026-11-24', numDays: 1 });

    expect(slots).toEqual([
      { date: '2026-11-24', weekday: 'TUE', dayOfMonth: 24, count: null, target: null, rolling7dAvg: null, cravingsCrushed: null, isToday: true },
    ]);
  });

  it('returns 30 slots for the 30-day view', () => {
    const slots = buildChartSlots({ chartCache: [], todayLog: null, todayDate: '2026-11-24', numDays: 30 });

    expect(slots).toHaveLength(30);
    expect(slots[0]?.date).toBe('2026-10-26');
  });
});

describe('getBarTone', () => {
  it('is "under" at the target', () => {
    expect(getBarTone(6, 6)).toBe('under');
  });

  it('is "over" one above the target', () => {
    expect(getBarTone(7, 6)).toBe('over');
  });

  it('is "wayOver" two above the target', () => {
    expect(getBarTone(8, 6)).toBe('wayOver');
  });
});

describe('computeStatsKpis', () => {
  const logs = {
    '2026-11-15': dayLog('2026-11-15', { total_count: 8, money_saved_inr: 100 }),
    '2026-11-21': dayLog('2026-11-21', { total_count: 6, money_saved_inr: 0 }),
    '2026-11-23': dayLog('2026-11-23', {
      total_count: 4,
      money_saved_inr: 40,
      smoke_entries: [smoke('2026-11-23T09:00:00.000+05:30'), smoke('2026-11-23T13:15:00.000+05:30')],
    }),
    '2026-11-24': dayLog('2026-11-24', {
      total_count: 2,
      money_saved_inr: 20,
      is_finalized: false,
      smoke_entries: [smoke('2026-11-24T10:00:00.000+05:30'), smoke('2026-11-24T11:00:00.000+05:30')],
    }),
  };

  it('averages the finished days and compares them with the days before', () => {
    const kpis = computeStatsKpis({ logs, todayDate: '2026-11-24', rangeDays: 7 });

    expect(kpis.avgPerDay).toBe(5);
    expect(kpis.avgDelta).toBe(-3);
  });

  it('finds the longest wait of the range and when it ended', () => {
    const kpis = computeStatsKpis({ logs, todayDate: '2026-11-24', rangeDays: 7 });

    expect(kpis.longestGapMins).toBe(255);
    expect(kpis.longestGapEndedAt).toBe('2026-11-23T13:15:00.000+05:30');
  });

  it('adds up the money of every recorded day, today included', () => {
    const kpis = computeStatsKpis({ logs, todayDate: '2026-11-24', rangeDays: 7 });

    expect(kpis.totalSavedInr).toBe(160);
  });

  it('has no average and no gap for a new user', () => {
    expect(computeStatsKpis({ logs: {}, todayDate: '2026-11-24', rangeDays: 7 })).toEqual({
      avgPerDay: null,
      avgDelta: null,
      longestGapMins: null,
      longestGapEndedAt: null,
      totalSavedInr: 0,
    });
  });

  it('has no change when the earlier period has no data', () => {
    const recent = { '2026-11-23': dayLog('2026-11-23', { total_count: 4 }) };

    const kpis = computeStatsKpis({ logs: recent, todayDate: '2026-11-24', rangeDays: 7 });

    expect(kpis.avgPerDay).toBe(4);
    expect(kpis.avgDelta).toBeNull();
  });
});

describe('rankTriggers', () => {
  it('sorts by count, keeps the usual order for ties and drops unused triggers', () => {
    const ranking = rankTriggers({
      'Work Stress': 5,
      'Post-Meal': 3,
      Boredom: 0,
      Social: 1,
      'Late Night': 3,
      Craving: 0,
    });

    expect(ranking).toEqual([
      { trigger: 'Work Stress', count: 5, percent: 42 },
      { trigger: 'Post-Meal', count: 3, percent: 25 },
      { trigger: 'Late Night', count: 3, percent: 25 },
      { trigger: 'Social', count: 1, percent: 8 },
    ]);
  });

  it('lists every trigger at zero when nothing was smoked', () => {
    const ranking = rankTriggers({
      'Work Stress': 0,
      'Post-Meal': 0,
      Boredom: 0,
      Social: 0,
      'Late Night': 0,
      Craving: 0,
    });

    expect(ranking.map((item) => item.trigger)).toEqual([
      'Work Stress',
      'Post-Meal',
      'Boredom',
      'Social',
      'Late Night',
      'Craving',
    ]);
    expect(ranking.map((item) => item.percent)).toEqual([0, 0, 0, 0, 0, 0]);
  });
});

describe('rankTriggersInRange', () => {
  it('counts today and leaves out days before the range', () => {
    const logs = {
      '2026-11-10': dayLog('2026-11-10', {
        smoke_entries: [smoke('2026-11-10T09:00:00.000+05:30', 'Boredom')],
      }),
      '2026-11-24': dayLog('2026-11-24', {
        smoke_entries: [smoke('2026-11-24T09:00:00.000+05:30', 'Social')],
      }),
    };

    expect(rankTriggersInRange(logs, '2026-11-24', 7)).toEqual([{ trigger: 'Social', count: 1, percent: 100 }]);
  });
});

describe('buildDangerProfile', () => {
  it('finds the busiest three hours and their share', () => {
    const logs = {
      '2026-11-23': dayLog('2026-11-23', {
        smoke_entries: [
          smoke('2026-11-23T09:00:00.000+05:30'),
          smoke('2026-11-23T15:10:00.000+05:30'),
          smoke('2026-11-23T15:40:00.000+05:30'),
          smoke('2026-11-23T16:20:00.000+05:30'),
        ],
      }),
      '2026-11-24': dayLog('2026-11-24', {
        smoke_entries: [smoke('2026-11-24T17:05:00.000+05:30'), smoke('2026-11-24T21:30:00.000+05:30')],
      }),
    };

    const profile = buildDangerProfile(logs, '2026-11-24', 7);

    expect(profile.window).toEqual({ startHour: 15, endHour: 18 });
    expect(profile.windowLabel).toBe('15:00–18:00');
    expect(profile.windowShortLabel).toBe('15–18');
    expect(profile.sharePercent).toBe(67);
    expect(profile.totalSmokes).toBe(6);
    expect(profile.bars).toHaveLength(24);
    expect(profile.bars[15]).toEqual({ hour: 15, count: 2, ratio: 1, inWindow: true });
    expect(profile.bars[16]).toEqual({ hour: 16, count: 1, ratio: 0.5, inWindow: true });
    expect(profile.bars[9]).toEqual({ hour: 9, count: 1, ratio: 0.5, inWindow: false });
  });

  it('has no window when nothing was smoked', () => {
    const profile = buildDangerProfile({}, '2026-11-24', 7);

    expect(profile.window).toBeNull();
    expect(profile.windowLabel).toBeNull();
    expect(profile.sharePercent).toBeNull();
    expect(profile.totalSmokes).toBe(0);
    expect(profile.bars[15]).toEqual({ hour: 15, count: 0, ratio: 0, inWindow: false });
  });
});
