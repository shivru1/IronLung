/**
 * The AI service the app uses: the three pipelines wired to the real store,
 * the saved API key and the network.
 *
 * - `triggerSmokeCoachAI(event)`   Pipeline A: Smoke Coach
 * - `processBrainDumpAI(text)`     Pipeline B: Voice Brain Dump Processor
 * - `generateRealTalkAI()`         Pipeline C: Real Talk Weekly Synthesizer
 *
 * The logic lives in `aiPipelines.ts`, the prompts in `aiPrompts.ts`, the
 * JSON contracts in `aiContracts.ts` and the provider calls in `llmClient.ts`.
 */

import { loadApiKey } from '../storage/secureKey';
import { useAppStore } from '../store/useAppStore';
import { createAiPipelines } from './aiPipelines';
import { requestJson } from './llmClient';

const pipelines = createAiPipelines({
  store: useAppStore,
  getApiKey: loadApiKey,
  requestJson,
  now: () => new Date(),
});

export const { triggerSmokeCoachAI, processBrainDumpAI, retryPendingBrainDumps, generateRealTalkAI } = pipelines;

export type { AiFailure, BriefingOutcome, CoachOutcome } from './aiPipelines';
export type { CoachEvent } from './aiPrompts';
