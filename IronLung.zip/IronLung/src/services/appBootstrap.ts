/**
 * Starts everything that runs alongside the screens: today's log, the saved
 * API key, notifications, pending brain dumps and the optional cloud backup.
 * `App.tsx` calls `startAppServices` once and calls the returned function to stop.
 */

import { AppState } from 'react-native';

import { APP_CONFIG } from '../config/appConfig';
import { loadApiKey } from '../storage/secureKey';
import { selectTodayLog } from '../store/createAppStore';
import { appStorage, useAppStore } from '../store/useAppStore';
import { retryPendingBrainDumps } from './aiService';
import { createFirestoreSync } from './firestoreSync';
import { addNotificationActionListener, initNotifications, scheduleDangerWindowAlert } from './nativeAndroidService';
import { defaultTargetGapMins } from './smokeEngine';
import { refreshTrackerNotification } from './trackerActions';

/** Wait this long after the last change before uploading, so a burst of taps becomes one sync. */
const SYNC_DELAY_MS = 5000;

function ignore(): void {
  // Background helpers fail quietly; the app keeps working from local data.
}

function refreshDangerAlert(): void {
  const state = useAppStore.getState();
  const today = selectTodayLog(state);
  const targetGapMins = today ? today.active_target_gap_mins : defaultTargetGapMins(state.settings.daily_target);
  scheduleDangerWindowAlert(state.rollingMemory?.stats.peak_danger_window, targetGapMins).catch(ignore);
}

export function startAppServices(): () => void {
  const sync = createFirestoreSync({ config: APP_CONFIG.firebase, storage: appStorage, store: useAppStore });
  let areNotificationsAllowed = false;
  let syncTimer: ReturnType<typeof setTimeout> | null = null;

  const syncSoon = () => {
    if (!sync.isEnabled()) {
      return;
    }
    if (syncTimer) {
      clearTimeout(syncTimer);
    }
    syncTimer = setTimeout(() => {
      sync.syncNow().catch(ignore);
    }, SYNC_DELAY_MS);
  };

  const onAppInFront = () => {
    useAppStore.getState().ensureToday();
    if (areNotificationsAllowed) {
      // Android 14+ lets the user swipe the tracker notification away, so put it back.
      refreshTrackerNotification(true);
      refreshDangerAlert();
    }
    retryPendingBrainDumps().catch(ignore);
    if (sync.isEnabled()) {
      sync.syncNow().catch(ignore);
    }
  };

  useAppStore.getState().ensureToday();
  loadApiKey().catch(ignore);

  const stopActionListener = addNotificationActionListener();
  initNotifications()
    .then((granted) => {
      areNotificationsAllowed = granted;
      if (granted) {
        refreshTrackerNotification(true);
        refreshDangerAlert();
      }
    })
    .catch(ignore);

  const unsubscribe = useAppStore.subscribe((state, previous) => {
    const dataChanged =
      state.dailyLogs !== previous.dailyLogs ||
      state.rollingMemory !== previous.rollingMemory ||
      state.brainDumps !== previous.brainDumps ||
      state.briefings !== previous.briefings ||
      state.settings !== previous.settings;
    if (!dataChanged) {
      return;
    }
    if (areNotificationsAllowed) {
      refreshTrackerNotification();
      refreshDangerAlert();
    }
    syncSoon();
  });

  const appStateSubscription = AppState.addEventListener('change', (status) => {
    if (status === 'active') {
      onAppInFront();
    }
  });

  retryPendingBrainDumps().catch(ignore);
  if (sync.isEnabled()) {
    sync.syncNow().catch(ignore);
  }

  return () => {
    unsubscribe();
    appStateSubscription.remove();
    stopActionListener();
    if (syncTimer) {
      clearTimeout(syncTimer);
    }
  };
}
