/**
 * Small building blocks shared by all screens: the three text styles, icons,
 * the page header, cards and the checkbox. They only draw; they hold no app logic.
 */

import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Pressable, StyleSheet, Text, View } from 'react-native';
import type { NativeSyntheticEvent, StyleProp, TextLayoutEventData, TextStyle, ViewStyle } from 'react-native';
import Svg, { Path } from 'react-native-svg';

import { ICONS } from './icons';
import type { IconName } from './icons';
import { alpha, colors, fonts, glow, layout, s } from './theme';

// ---------------------------------------------------------------------------
// Text
// ---------------------------------------------------------------------------

interface TypeProps {
  children?: React.ReactNode;
  /** Font size in design pixels. */
  size: number;
  color?: string;
  /** Line height in design pixels. Each text style has its own default. */
  lineHeight?: number;
  /** Letter spacing in design pixels. */
  tracking?: number;
  align?: 'left' | 'center' | 'right';
  numberOfLines?: number;
  /** Reports where each line of the text ended up, for example to place a cursor after the last word. */
  onTextLayout?: (event: NativeSyntheticEvent<TextLayoutEventData>) => void;
  style?: StyleProp<TextStyle>;
}

function Type(props: TypeProps & { family: string; defaultLineHeight: number }) {
  const { children, size, color, lineHeight, tracking, align, numberOfLines, onTextLayout, style, family, defaultLineHeight } = props;
  return (
    <Text
      // The layout copies a fixed design, so the system font size setting is not applied.
      allowFontScaling={false}
      numberOfLines={numberOfLines}
      onTextLayout={onTextLayout}
      style={[
        {
          fontFamily: family,
          fontSize: s(size),
          lineHeight: s(lineHeight ?? Math.round(size * defaultLineHeight)),
          color: color ?? colors.titanium,
          letterSpacing: tracking === undefined ? undefined : s(tracking),
          textAlign: align,
          includeFontPadding: false,
        },
        style,
      ]}
    >
      {children}
    </Text>
  );
}

const MONO_FAMILY = { 400: fonts.mono400, 500: fonts.mono500, 700: fonts.mono700 } as const;
const DISPLAY_FAMILY = { 500: fonts.display500, 700: fonts.display700, 800: fonts.display800 } as const;
const BODY_FAMILY = { 400: fonts.body400, 500: fonts.body500, 600: fonts.body600 } as const;

/** JetBrains Mono: labels, captions and badges. */
export function Mono({ weight = 400, ...rest }: TypeProps & { weight?: 400 | 500 | 700 }) {
  return <Type {...rest} family={MONO_FAMILY[weight]} defaultLineHeight={1.32} />;
}

/** Barlow Condensed: titles, big numbers and buttons. */
export function Display({ weight = 700, ...rest }: TypeProps & { weight?: 500 | 700 | 800 }) {
  return <Type {...rest} family={DISPLAY_FAMILY[weight]} defaultLineHeight={1.2} />;
}

/** Inter: sentences and list items. */
export function Body({ weight = 400, ...rest }: TypeProps & { weight?: 400 | 500 | 600 }) {
  return <Type {...rest} family={BODY_FAMILY[weight]} defaultLineHeight={1.4} />;
}

// ---------------------------------------------------------------------------
// Icons
// ---------------------------------------------------------------------------

export type { IconName } from './icons';

/**
 * An icon from `icons.ts`, drawn at the size it has in the design. `scale`
 * makes it bigger or smaller (1.25 is a quarter bigger).
 */
export function Icon({ name, color, scale = 1, style }: { name: IconName; color: string; scale?: number; style?: StyleProp<ViewStyle> }) {
  const shape = ICONS[name];
  return (
    <Svg width={s(shape.width * scale)} height={s(shape.height * scale)} viewBox={shape.viewBox} style={style}>
      <Path d={shape.d} fill={color} />
    </Svg>
  );
}

// ---------------------------------------------------------------------------
// Page header
// ---------------------------------------------------------------------------

/** The top of a screen: a small coloured line over the big title, with room for a control on the right. */
export function PageHeader({
  kicker,
  kickerColor,
  title,
  right,
}: {
  kicker: string;
  kickerColor: string;
  title: string;
  right?: React.ReactNode;
}) {
  return (
    <View style={styles.pageHeader}>
      <View>
        <Mono size={10} color={kickerColor} tracking={2} numberOfLines={1} style={styles.pageKicker}>
          {kicker}
        </Mono>
        <Display size={34} weight={800} lineHeight={41} numberOfLines={1}>
          {title}
        </Display>
      </View>
      {right}
    </View>
  );
}

// ---------------------------------------------------------------------------
// Surfaces
// ---------------------------------------------------------------------------

/** The standard card: dark surface, thin border, rounded corners. */
export function Card({ children, style }: { children?: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

/** A 1-pixel line across a card. */
export function Divider() {
  return <View style={styles.divider} />;
}

/** A small rounded label such as "1/4 DONE" or "STRESSED": tinted fill, coloured border and text. */
export function Badge({
  label,
  color,
  tint = color,
  fillOpacity = 0.15,
  borderOpacity = 0.5,
  height = 20,
  paddingHorizontal = 9,
  radius = 5,
  style,
}: {
  label: string;
  /** Text colour. */
  color: string;
  /** Colour of the fill and border. The text colour when left out. */
  tint?: string;
  fillOpacity?: number;
  borderOpacity?: number;
  height?: number;
  paddingHorizontal?: number;
  radius?: number;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <View
      style={[
        styles.badge,
        {
          height: s(height),
          paddingHorizontal: s(paddingHorizontal),
          borderRadius: s(radius),
          backgroundColor: alpha(tint, fillOpacity),
          borderColor: alpha(tint, borderOpacity),
        },
        style,
      ]}
    >
      <Mono size={9} weight={700} color={color} tracking={0.45}>
        {label}
      </Mono>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Pulsing dot
// ---------------------------------------------------------------------------

/** A small dot that slowly fades in and out, used next to "LIVE" and "REC". `size` is in design pixels. */
export function PulseDot({ color, size }: { color: string; size: number }) {
  const opacity = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 0.25, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ]),
    );
    pulse.start();
    return () => pulse.stop();
  }, [opacity]);
  return <Animated.View style={{ width: s(size), height: s(size), borderRadius: s(size / 2), backgroundColor: color, opacity }} />;
}

// ---------------------------------------------------------------------------
// Checkbox
// ---------------------------------------------------------------------------

export function Checkbox({ checked, onPress, label }: { checked: boolean; onPress: () => void; label: string }) {
  return (
    <Pressable
      onPress={onPress}
      hitSlop={s(12)}
      accessibilityRole="checkbox"
      accessibilityState={{ checked }}
      accessibilityLabel={label}
      style={[styles.checkbox, checked ? styles.checkboxChecked : styles.checkboxEmpty]}
    >
      {checked ? <Icon name="check" color={colors.obsidian} style={styles.checkboxTick} /> : null}
    </Pressable>
  );
}

// ---------------------------------------------------------------------------
// Task row
// ---------------------------------------------------------------------------

/**
 * One line of a task list: a checkbox, the task (struck through once done)
 * and an optional small label at the right. Tapping anywhere on the line
 * ticks the task. `inset` is the left and right padding in design pixels.
 */
export function TaskRow({
  task,
  done,
  onToggle,
  tag,
  tagColor = colors.slate,
  inset,
}: {
  task: string;
  done: boolean;
  onToggle: () => void;
  tag?: string | null;
  tagColor?: string;
  inset: number;
}) {
  return (
    <Pressable onPress={onToggle} accessibilityLabel={task} style={[styles.taskRow, { paddingHorizontal: s(inset) }]}>
      <Checkbox checked={done} onPress={onToggle} label={task} />
      <Body
        size={14}
        weight={500}
        lineHeight={20}
        color={done ? colors.slate : colors.titanium}
        numberOfLines={2}
        style={[styles.taskText, done && styles.taskTextDone]}
      >
        {task}
      </Body>
      {tag ? (
        <Mono size={9} color={tagColor} style={styles.taskTag}>
          {tag}
        </Mono>
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pageHeader: {
    height: s(56),
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  pageKicker: {
    marginTop: s(4.5),
    marginBottom: s(-2.5),
  },
  card: {
    backgroundColor: colors.gunmetal,
    borderColor: colors.steel,
    borderWidth: 1,
    borderRadius: s(layout.cardRadius),
  },
  divider: {
    height: 1,
    backgroundColor: colors.steel,
  },
  badge: {
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkbox: {
    width: s(24),
    height: s(24),
    borderRadius: s(6),
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxEmpty: {
    borderWidth: s(2),
    borderColor: colors.steel,
  },
  checkboxChecked: {
    backgroundColor: colors.emerald,
    boxShadow: glow(colors.emerald, 0.5, 10),
  },
  // The tick sits a touch above the middle of the box, as in the design.
  checkboxTick: {
    marginBottom: s(1),
  },
  taskRow: {
    minHeight: s(48),
    paddingVertical: s(4),
    flexDirection: 'row',
    alignItems: 'center',
  },
  taskText: {
    flex: 1,
    marginLeft: s(12),
  },
  taskTextDone: {
    textDecorationLine: 'line-through',
  },
  // The small label sits a touch above the middle of the line, as in the design.
  taskTag: {
    marginLeft: s(10),
    marginBottom: s(2.75),
  },
});
