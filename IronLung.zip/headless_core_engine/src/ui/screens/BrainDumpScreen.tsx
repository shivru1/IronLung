/**
 * BRAIN DUMP tab: say (or type) what is on your mind, see today's tasks and
 * the dumps the AI has already sorted.
 *
 * The screen only lays things out. Every value and action comes from
 * `useBrainDump`.
 */

import { LinearGradient } from 'expo-linear-gradient';
import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Animated, Easing, Keyboard, Pressable, StyleSheet, TextInput, View } from 'react-native';
import type { NativeSyntheticEvent, TextLayoutEventData } from 'react-native';

import { useBrainDump } from '../../hooks/useBrainDump';
import type { BrainDump, BrainDumpTask } from '../../hooks/useBrainDump';
import type { BrainDumpDoc, MoodType } from '../../types/schema';
import { formatTimer } from '../../utils/format';
import { formatDumpTimeLabel, getTaskTag } from '../labels';
import type { TaskTagTone } from '../labels';
import { Badge, Body, Card, Display, Divider, Icon, Mono, PageHeader, PulseDot, TaskRow } from '../primitives';
import { ScreenFrame } from '../ScreenFrame';
import { alpha, colors, fonts, glow, layout, s } from '../theme';

const PAGE_GLOW = { color: colors.cobalt, opacity: 0.045, centerX: 0.5 };

/** Holding the microphone at least this long means "talk while I hold"; a shorter touch is a tap that toggles recording. */
const HOLD_TO_TALK_MS = 500;
/** How many dumps the list shows before "SHOW OLDER DUMPS" is tapped. */
const DUMPS_PAGE_SIZE = 30;
/** The soft blue disc behind the microphone. */
const HALO_BLUE = '#3B82F6';
/** Where the expanding ring rests while nothing is recorded: 0 is tight around the button, 1 is fully faded out. */
const RING_REST = 0.4;

interface BarSpec {
  /** Height in design pixels. */
  height: number;
  color: string;
}

/** The sound bars left and right of the microphone, from the outside in (left) and inside out (right). */
const LEFT_BARS: readonly BarSpec[] = [
  { height: 9.5, color: colors.cyan },
  { height: 22, color: colors.cyan },
  { height: 37.5, color: colors.cyan },
  { height: 56, color: colors.cyan },
  { height: 31.5, color: colors.cyan },
  { height: 47, color: colors.emberBright },
];
const RIGHT_BARS: readonly BarSpec[] = [
  { height: 33, color: colors.emberBright },
  { height: 36, color: colors.ember },
  { height: 52.5, color: colors.cyan },
  { height: 39, color: colors.cyan },
  { height: 22, color: colors.cyan },
  { height: 16, color: colors.cyan },
];

/** Text colour of a mood, and the colour its badge and card edge are tinted with. */
const MOOD_LOOK: Record<MoodType, { color: string; tint: string }> = {
  Stressed: { color: colors.crimson, tint: colors.crimson },
  Calm: { color: colors.cyan, tint: colors.cyan },
  Excited: { color: colors.emberBright, tint: colors.ember },
  Tired: { color: colors.amber, tint: colors.amber },
};

const TAG_COLORS: Record<TaskTagTone, string> = {
  deadline: colors.crimson,
  work: colors.emberBright,
  personal: colors.slate,
  idea: colors.cyan,
};

type CaptureMode = 'voice' | 'type';

export function BrainDumpScreen() {
  const brain = useBrainDump();
  const [isHoldingMic, setIsHoldingMic] = useState(false);

  return (
    // The page must not scroll away under a finger that is holding the microphone.
    <ScreenFrame glow={PAGE_GLOW} scrollEnabled={!isHoldingMic}>
      <PageHeader kicker="MIND OFFLOAD" kickerColor={colors.cyan} title="BRAIN DUMP" />
      <CaptureCard brain={brain} onHoldChange={setIsHoldingMic} />
      <Missions brain={brain} />
      <ProcessedDumps brain={brain} />
    </ScreenFrame>
  );
}

// ---------------------------------------------------------------------------
// Capture card
// ---------------------------------------------------------------------------

function CaptureCard({ brain, onHoldChange }: { brain: BrainDump; onHoldChange: (isHolding: boolean) => void }) {
  const [wantsToType, setWantsToType] = useState(false);
  const [draft, setDraft] = useState('');
  const mode: CaptureMode = wantsToType || !brain.isVoiceAvailable ? 'type' : 'voice';

  const switchToTyping = () => {
    // Whatever was heard so far moves into the text box, so it can be fixed by hand.
    if (brain.isRecording) {
      setDraft(brain.liveTranscript);
      brain.cancelVoiceRecording();
    }
    setWantsToType(true);
  };

  const saveDraft = () => {
    const text = draft.trim();
    if (!text) {
      return;
    }
    setDraft('');
    Keyboard.dismiss();
    brain.submitTextDump(text).catch(() => undefined);
  };

  return (
    <View style={styles.captureCard}>
      <LinearGradient colors={['#0F1B2D', colors.gunmetal]} style={StyleSheet.absoluteFill} />

      <View style={styles.statusRow}>
        <CaptureStatus brain={brain} mode={mode} />
        {brain.isVoiceAvailable ? (
          <Pressable
            onPress={mode === 'voice' ? switchToTyping : () => setWantsToType(false)}
            hitSlop={s(8)}
            accessibilityRole="button"
            accessibilityLabel={mode === 'voice' ? 'Type instead' : 'Use voice'}
            style={({ pressed }) => [styles.modeButton, pressed && styles.pressed]}
          >
            {mode === 'voice' ? <Icon name="keyboard" color={colors.slate} /> : <Icon name="microphone" scale={0.3} color={colors.slate} />}
            <Mono size={9} color={colors.slate} tracking={1.35} style={styles.modeLabel}>
              {mode === 'voice' ? 'TYPE INSTEAD' : 'USE VOICE'}
            </Mono>
          </Pressable>
        ) : null}
      </View>

      {mode === 'voice' ? (
        <VoiceCapture brain={brain} onHoldChange={onHoldChange} />
      ) : (
        <>
          <View style={[styles.textBox, styles.typeBox]}>
            <Mono size={9} color={colors.cyan} tracking={1.5}>
              TYPE YOUR DUMP
            </Mono>
            <TextInput
              value={draft}
              onChangeText={setDraft}
              multiline
              placeholder="Tasks, worries, ideas. Write it the way you would say it."
              placeholderTextColor={colors.slate}
              selectionColor={colors.cyan}
              cursorColor={colors.cyan}
              textAlignVertical="top"
              allowFontScaling={false}
              maxLength={4000}
              style={styles.typeInput}
            />
          </View>
          <Pressable
            onPress={saveDraft}
            disabled={draft.trim().length === 0}
            accessibilityRole="button"
            accessibilityLabel="Save brain dump"
            style={({ pressed }) => [styles.saveButton, draft.trim().length === 0 && styles.saveDisabled, pressed && styles.pressed]}
          >
            <LinearGradient colors={[colors.cyan, colors.cobalt]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
            <Display size={18} weight={800} color={colors.obsidian}>
              SAVE DUMP
            </Display>
          </Pressable>
          {brain.isVoiceAvailable ? null : (
            <Body size={12.5} lineHeight={17.5} color={colors.slate} style={styles.voiceNote}>
              This phone has no speech recognition service, so voice is off.
            </Body>
          )}
        </>
      )}
    </View>
  );
}

function CaptureStatus({ brain, mode }: { brain: BrainDump; mode: CaptureMode }) {
  if (brain.isRecording) {
    return (
      <View style={styles.status}>
        <PulseDot color={colors.crimson} size={8} />
        <Mono size={10} weight={700} color={colors.crimson} tracking={1.7} style={styles.statusLabel}>
          REC {formatTimer(brain.recordingSeconds)}
        </Mono>
      </View>
    );
  }
  if (brain.isProcessingAi) {
    return (
      <View style={styles.status}>
        <ActivityIndicator size="small" color={colors.cyan} />
        <Mono size={10} weight={700} color={colors.cyan} tracking={1.7} style={styles.statusLabel}>
          AI SORTING
        </Mono>
      </View>
    );
  }
  return (
    <View style={styles.status}>
      <View style={styles.idleDot} />
      <Mono size={10} weight={700} color={colors.slate} tracking={1.7} style={styles.statusLabel}>
        {mode === 'voice' ? 'STANDBY' : 'KEYBOARD'}
      </Mono>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Voice capture: microphone, sound bars and the live transcript
// ---------------------------------------------------------------------------

function VoiceCapture({ brain, onHoldChange }: { brain: BrainDump; onHoldChange: (isHolding: boolean) => void }) {
  const pressStartedAt = useRef(0);
  const didPressStartRecording = useRef(false);
  // True after a short tap started the recording: it then runs until the next tap.
  const [isTapRecording, setIsTapRecording] = useState(false);

  const onPressIn = () => {
    onHoldChange(true);
    pressStartedAt.current = Date.now();
    didPressStartRecording.current = !brain.isRecording;
    if (!brain.isRecording) {
      setIsTapRecording(false);
      brain.startVoiceRecording().catch(() => undefined);
    }
  };

  const onPressOut = () => {
    onHoldChange(false);
    const heldLongEnough = Date.now() - pressStartedAt.current >= HOLD_TO_TALK_MS;
    if (didPressStartRecording.current && !heldLongEnough) {
      // A tap: keep listening until the microphone is tapped again.
      setIsTapRecording(true);
      return;
    }
    setIsTapRecording(false);
    brain.stopAndSubmitVoiceRecording().catch(() => undefined);
  };

  return (
    <>
      <View style={styles.micRow}>
        <SoundBars bars={LEFT_BARS} isActive={brain.isRecording} />
        <View style={styles.micWrap}>
          <View style={styles.micDisc} pointerEvents="none" />
          <MicRing isActive={brain.isRecording} />
          <Pressable
            onPressIn={onPressIn}
            onPressOut={onPressOut}
            android_disableSound
            accessibilityRole="button"
            accessibilityLabel={brain.isRecording ? 'Stop recording and save' : 'Record a brain dump'}
            style={({ pressed }) => [styles.micButton, pressed && styles.micPressed]}
          >
            <LinearGradient colors={[colors.cyan, colors.cobalt]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
            <View style={styles.micBevel} />
            <Icon name="microphone" color={colors.obsidian} />
          </Pressable>
        </View>
        <SoundBars bars={RIGHT_BARS} isActive={brain.isRecording} />
      </View>
      <Mono size={9} color={colors.slate} tracking={1.8} align="center" style={styles.holdLabel}>
        {brain.isRecording && isTapRecording ? 'TAP TO SEND' : 'HOLD TO TALK'}
      </Mono>

      <View style={styles.textBox}>
        <Mono size={9} color={colors.cyan} tracking={1.5}>
          LIVE TRANSCRIPT
        </Mono>
        {brain.isRecording ? (
          <LiveTranscript finalText={brain.liveTranscriptFinal} interimText={brain.liveTranscriptInterim} />
        ) : (
          <Body size={13} lineHeight={18.5} color={brain.voiceError ? colors.amber : colors.slate} style={styles.transcript}>
            {brain.voiceError ?? 'Hold the mic and say what is on your mind. Tasks, worries, ideas: the AI sorts them.'}
          </Body>
        )}
      </View>
    </>
  );
}

/** Six bars that stand still until a recording runs, then bounce at different speeds. */
function SoundBars({ bars, isActive }: { bars: readonly BarSpec[]; isActive: boolean }) {
  const levels = useRef(bars.map(() => new Animated.Value(1))).current;

  useEffect(() => {
    if (!isActive) {
      return undefined;
    }
    const loops = levels.map((level, index) => {
      const duration = 230 + index * 55;
      return Animated.loop(
        Animated.sequence([
          Animated.timing(level, { toValue: 0.3 + (index % 3) * 0.15, duration, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
          Animated.timing(level, { toValue: 1, duration, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        ]),
      );
    });
    loops.forEach((loop) => loop.start());
    return () => {
      loops.forEach((loop) => loop.stop());
      levels.forEach((level) => level.setValue(1));
    };
  }, [isActive, levels]);

  return (
    <View style={[styles.bars, !isActive && styles.barsIdle]}>
      {bars.map((bar, index) => (
        <Animated.View
          key={index}
          style={[styles.bar, { height: s(bar.height), backgroundColor: bar.color, transform: [{ scaleY: levels[index] ?? 1 }] }]}
        />
      ))}
    </View>
  );
}

/** The thin ring around the microphone. While recording it keeps growing and fading, like a ripple. */
function MicRing({ isActive }: { isActive: boolean }) {
  const progress = useRef(new Animated.Value(RING_REST)).current;

  useEffect(() => {
    if (!isActive) {
      return undefined;
    }
    progress.setValue(0);
    const ripple = Animated.loop(
      Animated.timing(progress, { toValue: 1, duration: 1200, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
    );
    ripple.start();
    return () => {
      ripple.stop();
      progress.setValue(RING_REST);
    };
  }, [isActive, progress]);

  return (
    <Animated.View
      pointerEvents="none"
      style={[
        styles.micRing,
        {
          opacity: progress.interpolate({ inputRange: [0, 1], outputRange: [1, 0] }),
          transform: [{ scale: progress.interpolate({ inputRange: [0, 1], outputRange: [1, 2] }) }],
        },
      ]}
    />
  );
}

/** What is being heard right now: settled words in white, the current guess in grey, then a blinking cursor. */
function LiveTranscript({ finalText, interimText }: { finalText: string; interimText: string }) {
  const [textEnd, setTextEnd] = useState({ x: 0, y: 0, lineHeight: s(18.5) });
  const hasWords = finalText.length > 0 || interimText.length > 0;

  const onTextLayout = (event: NativeSyntheticEvent<TextLayoutEventData>) => {
    const lines = event.nativeEvent.lines;
    const lastLine = lines[lines.length - 1];
    if (lastLine) {
      setTextEnd({ x: lastLine.x + lastLine.width, y: lastLine.y, lineHeight: lastLine.height });
    } else {
      setTextEnd({ x: 0, y: 0, lineHeight: s(18.5) });
    }
  };

  return (
    <View style={styles.transcript}>
      <Body size={13} lineHeight={18.5} onTextLayout={onTextLayout}>
        {hasWords ? '"' : ''}
        {finalText}
        <Body size={13} lineHeight={18.5} color={colors.slate}>
          {hasWords ? `${finalText && interimText ? ' ' : ''}${interimText}` : 'Listening'}
        </Body>
      </Body>
      <Cursor left={textEnd.x + s(1.5)} top={textEnd.y + (textEnd.lineHeight - s(14)) / 2} />
    </View>
  );
}

function Cursor({ left, top }: { left: number; top: number }) {
  const opacity = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    const blink = Animated.loop(
      Animated.sequence([
        Animated.delay(450),
        Animated.timing(opacity, { toValue: 0, duration: 80, useNativeDriver: true }),
        Animated.delay(450),
        Animated.timing(opacity, { toValue: 1, duration: 80, useNativeDriver: true }),
      ]),
    );
    blink.start();
    return () => blink.stop();
  }, [opacity]);
  return <Animated.View pointerEvents="none" style={[styles.cursor, { left, top, opacity }]} />;
}

// ---------------------------------------------------------------------------
// Today's missions
// ---------------------------------------------------------------------------

function Missions({ brain }: { brain: BrainDump }) {
  const tasks = brain.todaysTasks;
  const doneCount = tasks.length - brain.todaysUnfinishedTasks.length;

  return (
    <>
      <View style={[styles.sectionHeader, styles.missionsHeader]}>
        <Display size={20} weight={700}>
          TODAY'S MISSIONS
        </Display>
        <Badge label={`${doneCount}/${tasks.length} DONE`} color={colors.emerald} fillOpacity={0.1} borderOpacity={0.4} />
      </View>
      <Card style={styles.missionsCard}>
        {tasks.length === 0 ? (
          <View style={styles.emptyRow}>
            <Body size={13} lineHeight={18.5} color={colors.slate}>
              No missions yet. Dump your thoughts and the tasks land here.
            </Body>
          </View>
        ) : (
          tasks.map((task, index) => (
            <React.Fragment key={`${task.dumpId}:${task.taskId}`}>
              {index > 0 ? <Divider /> : null}
              <MissionRow task={task} onToggle={() => brain.toggleTaskDone(task.dumpId, task.taskId)} />
            </React.Fragment>
          ))
        )}
      </Card>
    </>
  );
}

function MissionRow({ task, onToggle }: { task: BrainDumpTask; onToggle: () => void }) {
  const tag = getTaskTag(task);
  return (
    <TaskRow
      task={task.task}
      done={task.done}
      onToggle={onToggle}
      tag={tag?.label}
      tagColor={tag ? TAG_COLORS[tag.tone] : undefined}
      inset={14}
    />
  );
}

// ---------------------------------------------------------------------------
// Processed dumps
// ---------------------------------------------------------------------------

function ProcessedDumps({ brain }: { brain: BrainDump }) {
  const [visibleCount, setVisibleCount] = useState(DUMPS_PAGE_SIZE);
  const visibleDumps = brain.dumps.slice(0, visibleCount);

  return (
    <>
      <View style={[styles.sectionHeader, styles.dumpsHeader]}>
        <Display size={20} weight={700}>
          PROCESSED DUMPS
        </Display>
        {brain.isProcessingAi ? <ActivityIndicator size="small" color={colors.cyan} /> : null}
      </View>
      {brain.dumps.length === 0 ? (
        <Card style={styles.emptyCard}>
          <Body size={13} lineHeight={18.5} color={colors.slate}>
            Nothing dumped yet. Each dump shows up here with its mood, a headline and its tasks.
          </Body>
        </Card>
      ) : null}
      {visibleDumps.map((dump) => (
        <DumpCard
          key={dump.id}
          dump={dump}
          todayDate={brain.todayDate}
          onToggleTask={brain.toggleTaskDone}
          onDelete={brain.deleteDump}
        />
      ))}
      {brain.dumps.length > visibleCount ? (
        <Pressable
          onPress={() => setVisibleCount((count) => count + DUMPS_PAGE_SIZE)}
          accessibilityRole="button"
          style={({ pressed }) => [styles.olderButton, pressed && styles.pressed]}
        >
          <Mono size={9} color={colors.slate} tracking={1.35}>
            SHOW OLDER DUMPS
          </Mono>
        </Pressable>
      ) : null}
    </>
  );
}

function DumpCard({
  dump,
  todayDate,
  onToggleTask,
  onDelete,
}: {
  dump: BrainDumpDoc;
  todayDate: string;
  onToggleTask: (dumpId: string, taskId: string) => void;
  onDelete: (dumpId: string) => void;
}) {
  const isPending = dump.ai_status === 'pending';
  const result = dump.ai_processed;
  const look = isPending ? { color: colors.slate, tint: colors.slate } : MOOD_LOOK[result.mood_detected];

  const confirmDelete = () => {
    Alert.alert('Delete this brain dump?', 'Its tasks go with it.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => onDelete(dump.id) },
    ]);
  };

  return (
    <Pressable
      onLongPress={confirmDelete}
      delayLongPress={450}
      accessibilityHint="Hold to delete"
      style={[styles.dumpCard, { borderLeftColor: look.color }]}
    >
      <View style={styles.dumpPills}>
        <Badge
          label={isPending ? 'WAITING FOR AI' : result.mood_detected.toUpperCase()}
          color={look.color}
          tint={look.tint}
          height={19.5}
          paddingHorizontal={8}
        />
        {isPending ? null : (
          <View style={styles.categoryPill}>
            <Mono size={9} color={colors.slate} tracking={0.45}>
              {result.category.toUpperCase()}
            </Mono>
          </View>
        )}
        <Mono size={9} color={colors.slate} tracking={0.3} align="right" numberOfLines={1} style={styles.dumpTime}>
          {formatDumpTimeLabel(dump.created_at, dump.logical_date, todayDate)}
        </Mono>
      </View>
      <Display size={21} weight={700} lineHeight={25} style={styles.dumpHeadline}>
        {result.headline}
      </Display>
      {result.action_items.map((item) => (
        <Pressable
          key={item.id}
          onPress={() => onToggleTask(dump.id, item.id)}
          onLongPress={confirmDelete}
          delayLongPress={450}
          hitSlop={s(4)}
          accessibilityRole="checkbox"
          accessibilityState={{ checked: item.done }}
          accessibilityLabel={item.task}
          style={styles.dumpItem}
        >
          <Icon name="square-check" color={item.done ? colors.emerald : colors.cyan} style={styles.dumpItemIcon} />
          <Body size={12.5} lineHeight={17.5} color={colors.slate} style={styles.dumpItemText}>
            {item.task}
          </Body>
        </Pressable>
      ))}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pressed: {
    opacity: 0.7,
  },

  // Capture card
  captureCard: {
    marginTop: s(17),
    padding: s(16),
    borderRadius: s(layout.cardRadius),
    borderWidth: 1,
    borderColor: alpha(colors.cyan, 0.4),
    backgroundColor: colors.gunmetal,
    overflow: 'hidden',
    boxShadow: glow(HALO_BLUE, 0.15, 24),
  },
  statusRow: {
    height: s(28),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  status: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusLabel: {
    marginLeft: s(6),
  },
  idleDot: {
    width: s(8),
    height: s(8),
    borderRadius: s(4),
    backgroundColor: colors.dot,
  },
  modeButton: {
    height: s(28),
    paddingLeft: s(10),
    paddingRight: s(10.9),
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: s(8),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.obsidian,
  },
  modeLabel: {
    marginLeft: s(6.4),
  },

  // Microphone
  micRow: {
    marginTop: s(16),
    height: s(76),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bars: {
    marginHorizontal: s(15),
    flexDirection: 'row',
    alignItems: 'center',
    gap: s(3),
  },
  barsIdle: {
    opacity: 0.45,
  },
  bar: {
    width: s(3),
    borderRadius: s(1.5),
  },
  micWrap: {
    width: s(76),
    height: s(76),
  },
  micDisc: {
    position: 'absolute',
    left: s(-21),
    top: s(-21),
    width: s(118),
    height: s(118),
    borderRadius: s(59),
    backgroundColor: alpha(HALO_BLUE, 0.05),
  },
  micRing: {
    position: 'absolute',
    left: 0,
    top: 0,
    width: s(76),
    height: s(76),
    borderRadius: s(38),
    borderWidth: s(2),
    borderColor: alpha(colors.cyan, 0.1),
  },
  micButton: {
    width: s(76),
    height: s(76),
    borderRadius: s(38),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.cobalt,
    overflow: 'hidden',
    boxShadow: glow(colors.cyan, 0.4, 24),
  },
  micPressed: {
    transform: [{ scale: 0.95 }],
  },
  // A thin light edge along the top of the button.
  micBevel: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: s(38),
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.4)',
  },
  holdLabel: {
    marginTop: s(7.5),
  },

  // Transcript and typing box
  textBox: {
    marginTop: s(14.5),
    minHeight: s(94),
    paddingTop: s(9.7),
    paddingBottom: s(10.8),
    paddingHorizontal: s(12),
    borderRadius: s(12),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: alpha(colors.obsidian, 0.7),
  },
  transcript: {
    marginTop: s(4),
  },
  cursor: {
    position: 'absolute',
    width: s(2),
    height: s(14),
    backgroundColor: colors.cyan,
  },
  typeBox: {
    marginTop: s(16),
  },
  typeInput: {
    marginTop: s(4),
    minHeight: s(92.5),
    maxHeight: s(185),
    padding: 0,
    fontFamily: fonts.body400,
    fontSize: s(13),
    lineHeight: s(18.5),
    color: colors.titanium,
    includeFontPadding: false,
  },
  saveButton: {
    marginTop: s(12),
    height: s(44),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(12),
    backgroundColor: colors.cobalt,
    overflow: 'hidden',
  },
  saveDisabled: {
    opacity: 0.4,
  },
  voiceNote: {
    marginTop: s(10),
  },

  // Section headers
  sectionHeader: {
    marginTop: s(23),
    height: s(24),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  missionsHeader: {
    marginBottom: s(11),
  },
  // The cards below bring their own 12 px gap.
  dumpsHeader: {
    marginBottom: s(3),
  },

  // Today's missions
  missionsCard: {
    overflow: 'hidden',
  },
  emptyRow: {
    paddingVertical: s(15),
    paddingHorizontal: s(14),
  },

  // Processed dumps
  emptyCard: {
    marginTop: s(12),
    paddingVertical: s(15),
    paddingHorizontal: s(14),
  },
  dumpCard: {
    marginTop: s(12),
    paddingTop: s(13.7),
    paddingBottom: s(17.45),
    paddingHorizontal: s(14),
    borderRadius: s(layout.cardRadius),
    borderWidth: 1,
    borderLeftWidth: s(4),
    borderColor: colors.steel,
    backgroundColor: colors.gunmetal,
  },
  dumpPills: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryPill: {
    marginLeft: s(6),
    height: s(19),
    paddingHorizontal: s(7.5),
    justifyContent: 'center',
    borderRadius: s(6),
    borderWidth: 1,
    borderColor: colors.steel,
  },
  dumpTime: {
    flex: 1,
    marginLeft: s(8),
  },
  dumpHeadline: {
    marginTop: s(7.4),
    marginBottom: s(1.9),
  },
  dumpItem: {
    marginTop: s(8.5),
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  dumpItemIcon: {
    marginTop: s(4.7),
  },
  dumpItemText: {
    flex: 1,
    marginLeft: s(8),
  },
  olderButton: {
    marginTop: s(12),
    height: s(40),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(12),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.gunmetal,
  },
});
