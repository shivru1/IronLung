/**
 * STATS tab: headline numbers, the daily chart, the hours of the day and the
 * trigger ranking, for the last 7 or 30 days.
 *
 * The screen only lays things out. Every value comes from `useStats`.
 */

import { LinearGradient } from 'expo-linear-gradient';
import React, { useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { useStats } from '../../hooks/useStats';
import type { Stats, StatsRange } from '../../hooks/useStats';
import { triggerChipSelectHaptic } from '../../services/nativeAndroidService';
import type { DangerBar, DangerProfile, TriggerRank } from '../../services/statsEngine';
import { getWeekdayLabel } from '../../utils/dateUtils';
import { formatInr, formatSignedDecimal, splitDuration } from '../../utils/format';
import { DailySmokesChart } from '../components/DailySmokesChart';
import { Badge, Body, Card, Display, Icon, Mono, PageHeader } from '../primitives';
import { ScreenFrame } from '../ScreenFrame';
import { alpha, colors, glow, layout, s } from '../theme';

const PAGE_GLOW = { color: colors.cyan, opacity: 0.095, centerX: 0.56 };

/** Bar and number colours of the trigger ranking, from most to least used. */
const RANK_COLORS = [colors.crimson, colors.emberBright, colors.cobalt, colors.cyan, colors.slate, colors.slate] as const;

const DANGER_BAR_MIN = 5;
const DANGER_BAR_BASE = 10;
const DANGER_BAR_RANGE = 38;
/** Hours of the day that get a label under the danger chart. */
const AXIS_TICKS = [0, 6, 12, 18, 21, 24] as const;

export function StatsScreen() {
  const [range, setRange] = useState<StatsRange>(7);
  const stats = useStats(range);

  return (
    <ScreenFrame glow={PAGE_GLOW}>
      <PageHeader
        kicker="BATTLE ANALYTICS"
        kickerColor={colors.cyan}
        title="STATS"
        right={<RangeToggle range={range} onChange={setRange} />}
      />
      <KpiRow stats={stats} range={range} />
      <ChartCard stats={stats} />
      <DangerCard danger={stats.danger} />
      <TriggerCard ranking={stats.triggerRanking} />
    </ScreenFrame>
  );
}

// ---------------------------------------------------------------------------
// 7 / 30 day toggle
// ---------------------------------------------------------------------------

function RangeToggle({ range, onChange }: { range: StatsRange; onChange: (range: StatsRange) => void }) {
  const options: StatsRange[] = [7, 30];
  return (
    <View style={styles.toggle}>
      {options.map((option) => {
        const isSelected = option === range;
        return (
          <Pressable
            key={option}
            onPress={() => {
              if (!isSelected) {
                triggerChipSelectHaptic();
                onChange(option);
              }
            }}
            accessibilityRole="button"
            accessibilityState={{ selected: isSelected }}
            accessibilityLabel={`Last ${option} days`}
            style={styles.toggleOption}
          >
            {isSelected ? (
              <LinearGradient colors={[colors.emberBright, colors.ember]} style={[StyleSheet.absoluteFill, styles.toggleFill]} />
            ) : null}
            <Display size={15} weight={700} color={isSelected ? colors.obsidian : colors.slate}>
              {option} DAYS
            </Display>
          </Pressable>
        );
      })}
    </View>
  );
}

// ---------------------------------------------------------------------------
// Headline numbers
// ---------------------------------------------------------------------------

function KpiRow({ stats, range }: { stats: Stats; range: StatsRange }) {
  const { kpis } = stats;
  const delta = kpis.avgDelta;
  const deltaColor = delta !== null && delta > 0 ? colors.crimson : colors.emerald;
  const gap = kpis.longestGapMins === null ? null : splitDuration(kpis.longestGapMins);
  const gapEndedAt = kpis.longestGapEndedAt;

  return (
    <View style={styles.kpiRow}>
      <View style={[styles.kpiCard, { borderTopColor: colors.ember }]}>
        <Mono size={8} color={colors.slate} tracking={1.6}>
          {range}D AVG
        </Mono>
        <Display size={34} weight={800} color={colors.emberBright} lineHeight={41} numberOfLines={1} style={styles.kpiAvgValue}>
          {kpis.avgPerDay === null ? '--' : kpis.avgPerDay.toFixed(1)}
        </Display>
        {delta === null ? (
          <Mono size={9} color={colors.slate} style={styles.kpiAvgSub}>
            NO EARLIER DATA
          </Mono>
        ) : (
          <View style={[styles.kpiDelta, styles.kpiAvgSub]}>
            <Icon name={delta > 0 ? 'arrow-trend-up' : 'arrow-trend-down'} color={deltaColor} />
            <Mono size={9} color={deltaColor} style={styles.kpiDeltaText}>
              {formatSignedDecimal(delta)}
            </Mono>
          </View>
        )}
      </View>

      <View style={[styles.kpiCard, { borderTopColor: colors.cyan }]}>
        <Mono size={8} color={colors.slate} tracking={1.6}>
          LONGEST GAP
        </Mono>
        <View style={styles.kpiGapValue}>
          <Display size={30} weight={800} color={colors.cyan} lineHeight={36} numberOfLines={1}>
            {gap === null ? '--' : gap.hours > 0 ? `${gap.hours}h${String(gap.minutes).padStart(2, '0')}` : gap.minutes}
          </Display>
          {gap === null ? null : (
            <Display size={16} weight={800} color={colors.cyan}>
              m
            </Display>
          )}
        </View>
        <Mono size={9} color={colors.slate} style={styles.kpiGapSub}>
          {gapEndedAt ? `${getWeekdayLabel(gapEndedAt.slice(0, 10))} ${gapEndedAt.slice(11, 16)}` : 'NO GAP YET'}
        </Mono>
      </View>

      <View style={[styles.kpiCard, styles.kpiSavedCard, { borderTopColor: colors.emerald }]}>
        <Mono size={8} color={colors.slate} tracking={1.6}>
          TOTAL SAVED
        </Mono>
        <Display size={28} weight={800} color={colors.emerald} lineHeight={34} numberOfLines={1} style={styles.kpiSavedValue}>
          ₹{formatInr(kpis.totalSavedInr)}
        </Display>
        <Mono size={9} color={colors.slate} style={styles.kpiSavedSub}>
          SINCE DAY 1
        </Mono>
      </View>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Daily smokes chart
// ---------------------------------------------------------------------------

function ChartCard({ stats }: { stats: Stats }) {
  return (
    <Card style={styles.card}>
      <View style={styles.cardTitleRow}>
        <Display size={18} weight={700}>
          DAILY SMOKES
        </Display>
        <Mono size={9} color={colors.slate} tracking={0.9}>
          TARGET {stats.dailyTarget}
        </Mono>
      </View>
      <View style={styles.legend}>
        <View style={[styles.legendSquare, { backgroundColor: colors.emerald }]} />
        <Mono size={9} color={colors.slate} style={styles.legendLabel}>
          UNDER
        </Mono>
        <View style={[styles.legendSquare, { backgroundColor: colors.crimson }]} />
        <Mono size={9} color={colors.slate} style={styles.legendLabel}>
          OVER
        </Mono>
        <View style={styles.legendLine} />
        <Mono size={9} color={colors.slate} style={styles.legendLabel}>
          7D AVG
        </Mono>
        <View style={styles.legendDots}>
          <View style={styles.legendDot} />
          <View style={styles.legendDot} />
          <View style={styles.legendDot} />
        </View>
        <Mono size={9} color={colors.slate} style={styles.legendLabel}>
          TARGET
        </Mono>
      </View>
      <View style={styles.chart}>
        <DailySmokesChart slots={stats.chart} dailyTarget={stats.dailyTarget} />
      </View>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Peak danger window
// ---------------------------------------------------------------------------

function dangerBarLook(bar: DangerBar): { height: number; color: string; glows: boolean } {
  if (bar.count === 0) {
    return { height: DANGER_BAR_MIN, color: colors.steel, glows: false };
  }
  const height = DANGER_BAR_BASE + bar.ratio * DANGER_BAR_RANGE;
  if (bar.inWindow) {
    return { height, color: colors.crimson, glows: true };
  }
  if (bar.ratio >= 0.58) {
    return { height, color: colors.emberBright, glows: false };
  }
  return { height, color: alpha(colors.ember, Math.min(1, Math.max(0.4, bar.ratio * 1.5))), glows: false };
}

function DangerCard({ danger }: { danger: DangerProfile }) {
  const window = danger.window;
  // Where the window's label sits along the 24-hour axis, kept away from the ends.
  const windowCenter = window ? Math.min(22, Math.max(2, ((window.startHour + 1.5) % 24))) : null;

  return (
    <Card style={styles.card}>
      <View style={styles.cardTitleRow}>
        <Display size={18} weight={700}>
          PEAK DANGER WINDOW
        </Display>
        {danger.windowLabel ? (
          <Badge label={danger.windowLabel} color={colors.crimson} height={19} paddingHorizontal={8.5} />
        ) : (
          <Badge label="NO DATA" color={colors.slate} height={19} paddingHorizontal={8.5} />
        )}
      </View>

      <View style={styles.dangerBars}>
        {danger.bars.map((bar) => {
          const look = dangerBarLook(bar);
          return (
            <View
              key={bar.hour}
              style={[
                styles.dangerBar,
                { height: s(look.height), backgroundColor: look.color },
                look.glows && styles.dangerBarGlow,
              ]}
            />
          );
        })}
      </View>

      <View style={styles.dangerAxis}>
        {AXIS_TICKS.map((hour) => {
          if (windowCenter !== null && Math.abs(hour - windowCenter) < 3.5) {
            return null;
          }
          return (
            <Mono
              key={hour}
              size={9}
              color={colors.slate}
              align={hour === 0 ? 'left' : hour === 24 ? 'right' : 'center'}
              style={[styles.axisTick, tickPosition(hour)]}
            >
              {String(hour).padStart(2, '0')}
            </Mono>
          );
        })}
        {windowCenter !== null && danger.windowShortLabel ? (
          <Mono size={9} color={colors.crimson} align="center" style={[styles.axisWindow, { left: `${(windowCenter / 24) * 100}%` }]}>
            {danger.windowShortLabel}
          </Mono>
        ) : null}
      </View>

      {danger.sharePercent === null ? (
        <Body size={12.5} lineHeight={17.5} color={colors.slate} style={styles.dangerText}>
          Log a few smokes and the three hours you smoke most show up here.
        </Body>
      ) : (
        <Body size={12.5} lineHeight={17.5} color={colors.slate} style={styles.dangerText}>
          <Body size={12.5} lineHeight={17.5} weight={600}>
            {danger.sharePercent}% of your smokes
          </Body>{' '}
          land in these 3 hours. Plan the fight before it starts.
        </Body>
      )}
    </Card>
  );
}

/** Places an axis label at its hour: the first and last hug the edges, the others are centred. */
function tickPosition(hour: number): { left?: `${number}%` | number; right?: number; marginLeft?: number } {
  if (hour === 0) {
    return { left: 0 };
  }
  if (hour === 24) {
    return { right: 0 };
  }
  return { left: `${(hour / 24) * 100}%`, marginLeft: -s(AXIS_TICK_WIDTH / 2) };
}

const AXIS_TICK_WIDTH = 20;
const AXIS_WINDOW_WIDTH = 44;

// ---------------------------------------------------------------------------
// Trigger ranking
// ---------------------------------------------------------------------------

function TriggerCard({ ranking }: { ranking: readonly TriggerRank[] }) {
  return (
    <Card style={[styles.card, styles.triggerCard]}>
      <Display size={18} weight={700}>
        TRIGGER RANKING
      </Display>
      {ranking.map((item, index) => {
        const color = RANK_COLORS[Math.min(index, RANK_COLORS.length - 1)] ?? colors.slate;
        const isTop = index === 0 && item.count > 0;
        return (
          <View key={item.trigger} style={index === 0 ? styles.triggerRowFirst : styles.triggerRow}>
            <View style={styles.triggerLabels}>
              <Body size={13} weight={600} lineHeight={19}>
                {item.trigger}
              </Body>
              <Display size={18} weight={700} color={color}>
                {item.percent}%
              </Display>
            </View>
            <View style={styles.triggerTrack}>
              {item.percent > 0 ? (
                <View style={[styles.triggerFill, { width: `${item.percent}%`, backgroundColor: color }, isTop && styles.triggerFillGlow]}>
                  {index === 1 ? (
                    <LinearGradient
                      colors={[colors.ember, colors.emberBright]}
                      start={{ x: 0, y: 0.5 }}
                      end={{ x: 1, y: 0.5 }}
                      style={[StyleSheet.absoluteFill, styles.triggerFillRadius]}
                    />
                  ) : null}
                </View>
              ) : null}
            </View>
          </View>
        );
      })}
    </Card>
  );
}

const styles = StyleSheet.create({
  // Header
  toggle: {
    marginTop: s(9),
    height: s(44),
    padding: s(4),
    flexDirection: 'row',
    borderRadius: s(12),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.gunmetal,
  },
  toggleOption: {
    paddingHorizontal: s(14.5),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(8),
  },
  toggleFill: {
    borderRadius: s(8),
  },

  // Headline numbers
  kpiRow: {
    marginTop: s(13),
    flexDirection: 'row',
    gap: s(8),
  },
  kpiCard: {
    flex: 1,
    height: s(95),
    paddingTop: s(12),
    paddingHorizontal: s(12),
    borderRadius: s(12),
    borderWidth: 1,
    borderTopWidth: s(2),
    borderColor: colors.steel,
    backgroundColor: colors.gunmetal,
  },
  kpiSavedCard: {
    boxShadow: glow(colors.emerald, 0.14, 18),
  },
  // Each number has its own size, so each one gets its own spacing above and below.
  kpiAvgValue: {
    marginTop: s(2),
  },
  kpiAvgSub: {
    marginTop: s(1),
  },
  kpiGapValue: {
    marginTop: s(3),
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  kpiGapSub: {
    marginTop: s(0.3),
  },
  kpiSavedValue: {
    marginTop: s(2),
  },
  kpiSavedSub: {
    marginTop: s(1.3),
  },
  kpiDelta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  kpiDeltaText: {
    marginLeft: s(5.7),
  },

  // Cards
  card: {
    marginTop: s(layout.cardGap),
    paddingTop: s(18),
    paddingBottom: s(16),
    paddingHorizontal: s(16),
  },
  cardTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  // Daily smokes
  legend: {
    marginTop: s(10.75),
    flexDirection: 'row',
    alignItems: 'center',
  },
  legendSquare: {
    width: s(8),
    height: s(8),
    borderRadius: s(2),
  },
  legendLabel: {
    marginLeft: s(5.25),
    marginRight: s(11.75),
  },
  legendLine: {
    width: s(7.5),
    height: s(1),
    backgroundColor: colors.cyan,
  },
  legendDots: {
    flexDirection: 'row',
    gap: s(0.65),
  },
  legendDot: {
    width: s(2),
    height: s(2),
    borderRadius: s(1),
    backgroundColor: colors.titanium,
  },
  chart: {
    marginTop: s(6.25),
  },

  // Danger window
  dangerBars: {
    marginTop: s(10),
    height: s(57),
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: s(2),
  },
  dangerBar: {
    flex: 1,
    borderRadius: s(2),
  },
  dangerBarGlow: {
    boxShadow: glow(colors.crimson, 0.6, 8),
  },
  dangerAxis: {
    marginTop: s(8),
    height: s(12),
  },
  axisTick: {
    position: 'absolute',
    top: 0,
    width: s(AXIS_TICK_WIDTH),
  },
  axisWindow: {
    position: 'absolute',
    top: 0,
    width: s(AXIS_WINDOW_WIDTH),
    marginLeft: -s(AXIS_WINDOW_WIDTH / 2),
  },
  dangerText: {
    marginTop: s(13),
  },

  // Trigger ranking
  triggerCard: {
    paddingBottom: s(16),
  },
  triggerRowFirst: {
    marginTop: s(13),
  },
  triggerRow: {
    marginTop: s(12.5),
  },
  triggerLabels: {
    height: s(22),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  triggerTrack: {
    marginTop: s(5),
    height: s(10),
    borderRadius: s(5),
    backgroundColor: colors.obsidian,
  },
  triggerFill: {
    height: s(10),
    minWidth: s(10),
    borderRadius: s(5),
  },
  triggerFillRadius: {
    borderRadius: s(5),
  },
  triggerFillGlow: {
    boxShadow: glow(colors.crimson, 0.5, 8),
  },
});
