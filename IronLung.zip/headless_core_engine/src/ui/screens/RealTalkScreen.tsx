/**
 * REAL TALK tab: the weekly briefing (smoke trend, brain/habit link, next
 * week's goal and carried-over tasks) and the quick settings.
 *
 * The screen only lays things out. Every value and action comes from
 * `useRealTalk` and `useSettings`.
 */

import { LinearGradient } from 'expo-linear-gradient';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Keyboard, Pressable, StyleSheet, TextInput, View } from 'react-native';
import type { ScrollView } from 'react-native';

import { useRealTalk } from '../../hooks/useRealTalk';
import type { RealTalk } from '../../hooks/useRealTalk';
import { useSettings } from '../../hooks/useSettings';
import type { Settings } from '../../hooks/useSettings';
import type { RealTalkBriefingDoc } from '../../types/schema';
import { formatDurationSpaced } from '../../utils/format';
import { formatAverage, formatGapCaption, formatTaskAge, getKeyStatus, getTrendBadge, keepDigits, parseWholeNumber } from '../labels';
import type { KeyStatusTone, TrendDirection } from '../labels';
import { Badge, Body, Card, Display, Divider, Icon, Mono, PageHeader, TaskRow } from '../primitives';
import type { IconName } from '../primitives';
import { splitEmphasis } from '../richText';
import { ScreenFrame } from '../ScreenFrame';
import { alpha, colors, fonts, glow, layout, s } from '../theme';

const PAGE_GLOW = { color: colors.ember, opacity: 0.09, centerX: 0.36 };

/** The green wash in the top-left corner of the goal card. */
const GOAL_TINT = '#083826';
// A diagonal gradient whose middle runs from the top-right to the bottom-left
// corner of a wide card, so the wash is gone by the time it reaches either one.
const GOAL_GRADIENT_START = { x: 0.37, y: -0.37 };
const GOAL_GRADIENT_END = { x: 0.63, y: 1.37 };

const TREND_LOOK: Record<TrendDirection, { color: string; icon: IconName | null }> = {
  down: { color: colors.emerald, icon: 'caret-down' },
  up: { color: colors.crimson, icon: 'caret-up' },
  flat: { color: colors.slate, icon: null },
  none: { color: colors.slate, icon: null },
};

const KEY_STATUS_COLORS: Record<KeyStatusTone, string> = {
  saved: colors.emerald,
  unsaved: colors.amber,
  empty: colors.slate,
};

/** The page needs a moment to become visible before it can be scrolled. */
const SCROLL_DELAY_MS = 80;

/**
 * `settingsRequest` is a counter: each time it grows (the gear on the Tracker
 * was tapped) the screen scrolls down to Quick Settings.
 */
export function RealTalkScreen({ settingsRequest }: { settingsRequest: number }) {
  const realTalk = useRealTalk();
  const settings = useSettings();
  const scrollRef = useRef<ScrollView | null>(null);
  const settingsTop = useRef<number | null>(null);
  const handledRequest = useRef(0);

  const scrollToSettings = useCallback(() => {
    const top = settingsTop.current;
    if (top === null || handledRequest.current === settingsRequest) {
      return;
    }
    handledRequest.current = settingsRequest;
    setTimeout(() => {
      scrollRef.current?.scrollTo({ y: Math.max(0, top - s(layout.cardGap)), animated: true });
    }, SCROLL_DELAY_MS);
  }, [settingsRequest]);

  useEffect(() => {
    scrollToSettings();
  }, [scrollToSettings]);

  const briefing = realTalk.latestBriefing;

  return (
    <ScreenFrame glow={PAGE_GLOW} scrollRef={scrollRef}>
      <PageHeader kicker={realTalk.periodHeader} kickerColor={colors.emberBright} title="WEEKLY REAL TALK" />
      <GenerateButton realTalk={realTalk} />
      <TrendCard briefing={briefing} />
      <BrainHabitCard briefing={briefing} />
      <GoalCard briefing={briefing} />
      <CarryoverCard realTalk={realTalk} />
      <View
        onLayout={(event) => {
          settingsTop.current = event.nativeEvent.layout.y;
          scrollToSettings();
        }}
      >
        <SettingsCard settings={settings} />
      </View>
    </ScreenFrame>
  );
}

// ---------------------------------------------------------------------------
// Shared pieces
// ---------------------------------------------------------------------------

/** A sentence in grey with the `**marked**` phrase in bold white. */
function RichText({ text, size, lineHeight }: { text: string; size: number; lineHeight: number }) {
  return (
    <Body size={size} lineHeight={lineHeight} color={colors.slate}>
      {splitEmphasis(text).map((part, index) =>
        part.strong ? (
          <Body key={index} size={size} lineHeight={lineHeight} weight={600}>
            {part.text}
          </Body>
        ) : (
          part.text
        ),
      )}
    </Body>
  );
}

/** The small icon-and-label line at the top of a briefing card. */
function CardLabel({ icon, label, color }: { icon: IconName; label: string; color: string }) {
  return (
    <>
      <Icon name={icon} color={color} />
      <Mono size={10} weight={700} color={color} tracking={1.75} style={styles.cardLabel}>
        {label}
      </Mono>
    </>
  );
}

// ---------------------------------------------------------------------------
// Generate button
// ---------------------------------------------------------------------------

function GenerateButton({ realTalk }: { realTalk: RealTalk }) {
  return (
    <>
      <Pressable
        onPress={() => {
          realTalk.generateFreshBriefing().catch(() => undefined);
        }}
        disabled={realTalk.isGenerating}
        accessibilityRole="button"
        accessibilityLabel="Generate briefing"
        accessibilityState={{ busy: realTalk.isGenerating }}
        style={({ pressed }) => [styles.generateButton, pressed && styles.pressedDown]}
      >
        <LinearGradient colors={['#FF8600', colors.ember]} style={StyleSheet.absoluteFill} />
        <View style={styles.generateBevel} />
        {realTalk.isGenerating ? (
          <ActivityIndicator size="small" color={colors.obsidian} />
        ) : (
          <Icon name="wand-magic-sparkles" color={colors.obsidian} style={styles.generateIcon} />
        )}
        <Display size={20} weight={800} color={colors.obsidian} style={styles.generateLabel}>
          {realTalk.isGenerating ? 'GENERATING' : 'GENERATE BRIEFING'}
        </Display>
      </Pressable>
      {realTalk.errorMessage ? (
        <Body size={12.5} lineHeight={17.5} color={colors.amber} style={styles.generateError}>
          {realTalk.errorMessage}
        </Body>
      ) : null}
    </>
  );
}

// ---------------------------------------------------------------------------
// Smoke trend
// ---------------------------------------------------------------------------

function TrendCard({ briefing }: { briefing: RealTalkBriefingDoc | null }) {
  const stats = briefing ? briefing.stats : null;
  const badge = getTrendBadge(stats ? stats.change_pct : null);
  const look = TREND_LOOK[badge.direction];

  return (
    <View style={styles.trendCard}>
      <View style={[styles.cardHeader, styles.trendHeader]}>
        <View style={styles.cardHeader}>
          <CardLabel icon="chart-line" label="SMOKE TREND" color={colors.emberBright} />
        </View>
        <View style={[styles.trendBadge, { backgroundColor: alpha(look.color, 0.15) }]}>
          {look.icon ? <Icon name={look.icon} color={look.color} style={styles.trendBadgeIcon} /> : null}
          <Mono size={9} weight={700} color={look.color} tracking={0.3}>
            {briefing ? badge.label : 'NO BRIEFING YET'}
          </Mono>
        </View>
      </View>

      <View style={styles.trendNumbers}>
        <View>
          <Display size={48} weight={800}>
            {stats ? stats.smokes_this_week : '--'}
          </Display>
          <Mono size={9} color={colors.slate} tracking={0.45} style={styles.captionUnderBig}>
            SMOKES / WEEK
          </Mono>
        </View>
        <View>
          <Display size={32} weight={800} color={colors.cyan}>
            {stats && stats.avg_gap_mins !== null ? formatDurationSpaced(stats.avg_gap_mins) : '--'}
          </Display>
          <Mono size={9} color={colors.slate} tracking={0.45} style={styles.captionUnderSmall}>
            {formatGapCaption(stats ? stats.avg_gap_delta_mins : null)}
          </Mono>
        </View>
      </View>

      <View style={styles.trendText}>
        <RichText
          text={briefing ? briefing.smoke_trend_summary : 'No briefing yet. Log a few days, then tap **GENERATE BRIEFING** for a straight read on your week.'}
          size={13}
          lineHeight={18}
        />
      </View>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Brain / habit link
// ---------------------------------------------------------------------------

function BrainHabitCard({ briefing }: { briefing: RealTalkBriefingDoc | null }) {
  const stats = briefing ? briefing.stats : null;
  return (
    <View style={styles.brainCard}>
      <View style={styles.brainStripe} />
      <View style={styles.cardHeader}>
        <CardLabel icon="link" label="BRAIN" color={colors.crimson} />
        <Icon name="arrows-left-right" color={colors.cyan} style={styles.linkArrow} />
        <Mono size={10} weight={700} color={colors.crimson} tracking={1.75}>
          HABIT LINK
        </Mono>
      </View>

      <View style={styles.subCards}>
        <MoodAverage label="STRESSED DAYS" value={stats ? stats.stressed_days_avg : null} color={colors.crimson} />
        <MoodAverage label="CALM DAYS" value={stats ? stats.calm_days_avg : null} color={colors.cyan} />
      </View>

      <View style={styles.brainText}>
        <RichText
          text={briefing ? briefing.brain_habit_correlation : 'Your brain dumps get lined up with your smokes here: stressed days against calm days.'}
          size={13}
          lineHeight={17.5}
        />
      </View>
    </View>
  );
}

function MoodAverage({ label, value, color }: { label: string; value: number | null; color: string }) {
  return (
    <View style={[styles.subCard, { backgroundColor: alpha(color, 0.1), borderColor: alpha(color, 0.4) }]}>
      <Mono size={9} color={colors.slate} tracking={0.45}>
        {label}
      </Mono>
      <Display size={30} weight={800} color={color} style={styles.subValue}>
        {formatAverage(value)}
      </Display>
      <Mono size={9} color={colors.slate} style={styles.subCaption}>
        AVG SMOKES
      </Mono>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Next week's micro-goal
// ---------------------------------------------------------------------------

function GoalCard({ briefing }: { briefing: RealTalkBriefingDoc | null }) {
  const goal = briefing ? briefing.next_week_micro_goal : 'No goal yet.';
  const reward = briefing ? briefing.micro_goal_reward : 'Your first briefing sets **one small goal** for the week ahead.';

  return (
    <View style={styles.goalCard}>
      <LinearGradient
        colors={[GOAL_TINT, colors.gunmetal, colors.gunmetal]}
        locations={[0, 0.5, 1]}
        start={GOAL_GRADIENT_START}
        end={GOAL_GRADIENT_END}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.cardHeader}>
        <CardLabel icon="bullseye" label="NEXT WEEK MICRO-GOAL" color={colors.emerald} />
      </View>
      <Display size={28} weight={800} lineHeight={30} style={styles.goalText}>
        {splitEmphasis(goal).map((part, index) =>
          part.strong ? (
            <Display key={index} size={28} weight={800} lineHeight={30} color={colors.emerald}>
              {part.text}
            </Display>
          ) : (
            part.text
          ),
        )}
      </Display>
      <View style={styles.rewardText}>
        <RichText text={briefing ? `Reward: ${reward}` : reward} size={12.5} lineHeight={17.5} />
      </View>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Carryover tasks
// ---------------------------------------------------------------------------

function CarryoverCard({ realTalk }: { realTalk: RealTalk }) {
  const tasks = realTalk.carryoverTasks;
  return (
    <Card style={styles.carryCard}>
      <View style={styles.carryHeader}>
        <Display size={19} weight={700} style={styles.carryTitle}>
          CARRYOVER TASKS
        </Display>
        <Badge label={`${realTalk.openCarryoverCount} OPEN`} color={colors.amber} fillOpacity={0.1} borderOpacity={0.4} />
      </View>
      <Divider />
      {tasks.length === 0 ? (
        <View style={styles.carryEmpty}>
          <Body size={13} lineHeight={18.5} color={colors.slate}>
            {realTalk.latestBriefing
              ? 'Nothing carried over. Clean slate.'
              : 'Tasks you did not finish during the week show up here after a briefing.'}
          </Body>
        </View>
      ) : (
        tasks.map((task, index) => (
          <React.Fragment key={task.id}>
            {index > 0 ? <Divider /> : null}
            <TaskRow
              task={task.task}
              done={task.done}
              onToggle={() => realTalk.toggleCarryoverTask(task.id)}
              tag={formatTaskAge(task.ageDays, task.done)}
              tagColor={task.done ? colors.emerald : colors.slate}
              inset={16}
            />
          </React.Fragment>
        ))
      )}
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Quick settings
// ---------------------------------------------------------------------------

function SettingsCard({ settings }: { settings: Settings }) {
  return (
    <Card style={styles.settingsCard}>
      <View style={styles.settingsTitleRow}>
        <Icon name="sliders" color={colors.slate} style={styles.settingsIcon} />
        <Display size={19} weight={700} style={styles.settingsTitle}>
          QUICK SETTINGS
        </Display>
      </View>

      <SettingRow title="Daily Baseline" hint="YOUR OLD HABIT" isFirst>
        <NumberBox
          value={settings.dailyBaseline}
          onChange={settings.setDailyBaseline}
          maxDigits={2}
          width={50}
          color={colors.titanium}
          label="Daily baseline"
        />
      </SettingRow>

      <SettingRow title="Daily Target" hint="TODAY'S LIMIT">
        <View style={styles.stepper}>
          <Pressable
            onPress={() => settings.stepDailyTarget(-1)}
            hitSlop={s(6)}
            accessibilityRole="button"
            accessibilityLabel="Lower the daily target"
            style={({ pressed }) => [styles.stepButton, pressed && styles.pressed]}
          >
            <Icon name="minus" color={colors.slate} />
          </Pressable>
          <Display size={26} weight={800} color={colors.emberBright} align="center" style={styles.stepValue}>
            {settings.dailyTarget}
          </Display>
          <Pressable
            onPress={() => settings.stepDailyTarget(1)}
            hitSlop={s(6)}
            accessibilityRole="button"
            accessibilityLabel="Raise the daily target"
            style={({ pressed }) => [styles.stepButton, styles.stepButtonPlus, pressed && styles.pressed]}
          >
            <Icon name="plus" color={colors.emberBright} />
          </Pressable>
        </View>
      </SettingRow>

      <SettingRow title="Cost per Cigarette" hint="USED FOR ₹ SAVED">
        <NumberBox
          value={settings.costPerCigInr}
          onChange={settings.setCostPerCig}
          prefix="₹"
          maxDigits={4}
          width={65}
          color={colors.emerald}
          label="Cost per cigarette in rupees"
        />
      </SettingRow>

      <ApiKeyField settings={settings} />
    </Card>
  );
}

function SettingRow({
  title,
  hint,
  isFirst = false,
  children,
}: {
  title: string;
  hint: string;
  isFirst?: boolean;
  children: React.ReactNode;
}) {
  return (
    <View style={[styles.settingRow, isFirst && styles.settingRowFirst]}>
      <View style={styles.settingLabels}>
        <Body size={13} weight={600} lineHeight={18}>
          {title}
        </Body>
        <Mono size={9} color={colors.slate} style={styles.settingHint}>
          {hint}
        </Mono>
      </View>
      {children}
    </View>
  );
}

/**
 * A small box holding one whole number. The number is saved while it is typed;
 * an emptied box goes back to the saved number when the keyboard leaves it.
 */
function NumberBox({
  value,
  onChange,
  prefix = '',
  maxDigits,
  width,
  color,
  label,
}: {
  value: number;
  onChange: (value: number) => void;
  prefix?: string;
  maxDigits: number;
  /** Width in design pixels. */
  width: number;
  color: string;
  label: string;
}) {
  const [typed, setTyped] = useState<string | null>(null);

  return (
    <View style={[styles.numberBox, { width: s(width) }]}>
      <TextInput
        value={typed ?? `${prefix}${value}`}
        onChangeText={(text) => {
          const digits = keepDigits(text, maxDigits);
          setTyped(`${prefix}${digits}`);
          const parsed = parseWholeNumber(digits);
          if (parsed !== null) {
            onChange(parsed);
          }
        }}
        onBlur={() => setTyped(null)}
        keyboardType="number-pad"
        returnKeyType="done"
        maxLength={prefix.length + maxDigits}
        selectTextOnFocus
        selectionColor={colors.cyan}
        cursorColor={colors.cyan}
        allowFontScaling={false}
        accessibilityLabel={label}
        style={[styles.numberInput, { color }]}
      />
    </View>
  );
}

function ApiKeyField({ settings }: { settings: Settings }) {
  const [typedKey, setTypedKey] = useState(settings.apiKey ?? '');
  const [isVisible, setIsVisible] = useState(false);
  const status = getKeyStatus({ savedKey: settings.apiKey, typedKey, provider: settings.apiProvider });

  // The key that was last handed over for saving, so the same key is never saved twice in a row.
  const lastSavedKey = useRef(settings.apiKey ?? '');

  // The saved key arrives a moment after the app starts, and changes when it is saved.
  useEffect(() => {
    lastSavedKey.current = settings.apiKey ?? '';
    setTypedKey(settings.apiKey ?? '');
  }, [settings.apiKey]);

  const saveTypedKey = () => {
    const key = typedKey.trim();
    if (key !== lastSavedKey.current) {
      lastSavedKey.current = key;
      settings.setApiKey(key).catch(() => undefined);
    }
  };

  // Closing the keyboard with the back button does not end editing, so save then too.
  const saveRef = useRef(saveTypedKey);
  useEffect(() => {
    saveRef.current = saveTypedKey;
  });
  useEffect(() => {
    const subscription = Keyboard.addListener('keyboardDidHide', () => saveRef.current());
    return () => subscription.remove();
  }, []);

  return (
    <>
      <View style={styles.keyLabelRow}>
        <Body size={13} weight={600} lineHeight={18}>
          AI API Key
        </Body>
        <Mono size={9} color={KEY_STATUS_COLORS[status.tone]}>
          {status.label}
        </Mono>
      </View>
      <View style={styles.keyField}>
        <Icon name="lock" color={colors.cyan} />
        <TextInput
          value={typedKey}
          onChangeText={setTypedKey}
          onEndEditing={saveTypedKey}
          secureTextEntry={!isVisible}
          autoCapitalize="none"
          autoCorrect={false}
          autoComplete="off"
          returnKeyType="done"
          placeholder="Paste your AI key here"
          placeholderTextColor={colors.slate}
          selectionColor={colors.cyan}
          cursorColor={colors.cyan}
          allowFontScaling={false}
          accessibilityLabel="AI API key"
          style={styles.keyInput}
        />
        <Pressable
          onPress={() => setIsVisible((visible) => !visible)}
          hitSlop={s(6)}
          accessibilityRole="button"
          accessibilityLabel={isVisible ? 'Hide the key' : 'Show the key'}
          style={({ pressed }) => [styles.eyeButton, pressed && styles.pressed]}
        >
          <Icon name="eye" color={isVisible ? colors.cyan : colors.slate} />
        </Pressable>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  pressed: {
    opacity: 0.7,
  },
  pressedDown: {
    opacity: 0.9,
    transform: [{ translateY: s(1) }],
  },

  // Shared
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardLabel: {
    marginLeft: s(6.2),
  },

  // Generate button
  generateButton: {
    marginTop: s(9),
    height: s(54),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(12),
    borderWidth: 1,
    borderColor: alpha(colors.emberBright, 0.6),
    backgroundColor: colors.ember,
    overflow: 'hidden',
    boxShadow: glow(colors.ember, 0.45, 30),
  },
  // A thin light edge along the top of the button.
  generateBevel: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: s(11),
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.4)',
  },
  // The wand sits one pixel below the middle of the button, as in the design.
  generateIcon: {
    marginTop: s(2),
  },
  generateLabel: {
    marginLeft: s(9.5),
  },
  generateError: {
    marginTop: s(8),
  },

  // Smoke trend
  trendCard: {
    marginTop: s(layout.cardGap),
    paddingTop: s(16),
    paddingHorizontal: s(16),
    paddingBottom: s(17),
    borderRadius: s(layout.cardRadius),
    borderWidth: s(2),
    borderColor: colors.ember,
    backgroundColor: colors.gunmetal,
  },
  trendHeader: {
    height: s(18),
    justifyContent: 'space-between',
  },
  trendBadge: {
    height: s(18),
    paddingHorizontal: s(8.5),
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: s(6),
  },
  trendBadgeIcon: {
    marginRight: s(6.1),
    marginTop: s(1),
  },
  trendNumbers: {
    marginTop: s(6.5),
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: s(16),
  },
  // The captions sit tight under the big numbers, closer than the numbers' own line height allows.
  captionUnderBig: {
    marginTop: s(-5),
  },
  captionUnderSmall: {
    marginTop: s(-3.5),
  },
  trendText: {
    marginTop: s(13.5),
  },

  // Brain / habit link
  brainCard: {
    marginTop: s(layout.cardGap),
    paddingTop: s(23.5),
    paddingHorizontal: s(16),
    paddingBottom: s(17),
    borderRadius: s(layout.cardRadius),
    borderWidth: s(2),
    borderColor: colors.crimson,
    backgroundColor: colors.gunmetal,
    overflow: 'hidden',
    // A hairline of cyan around the red border.
    boxShadow: `0px 0px 0px 1px ${alpha(colors.cyan, 0.35)}`,
  },
  brainStripe: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    right: 0,
    width: s(4),
    backgroundColor: colors.cyan,
  },
  linkArrow: {
    marginLeft: s(7.9),
    marginRight: s(10),
    marginTop: s(2),
  },
  subCards: {
    marginTop: s(15.5),
    flexDirection: 'row',
    gap: s(8),
  },
  subCard: {
    flex: 1,
    height: s(83),
    paddingTop: s(11.5),
    paddingLeft: s(12),
    borderRadius: s(10),
    borderWidth: 1,
  },
  subValue: {
    marginTop: s(-1.5),
  },
  subCaption: {
    marginTop: s(-3.5),
  },
  brainText: {
    marginTop: s(11.5),
  },

  // Micro-goal
  goalCard: {
    marginTop: s(layout.cardGap),
    paddingTop: s(23.5),
    paddingHorizontal: s(16),
    paddingBottom: s(17.5),
    borderRadius: s(layout.cardRadius),
    borderWidth: s(2),
    borderColor: colors.emerald,
    backgroundColor: colors.gunmetal,
    overflow: 'hidden',
    boxShadow: glow(colors.emerald, 0.3, 28),
  },
  goalText: {
    marginTop: s(10),
  },
  rewardText: {
    marginTop: s(8.5),
  },

  // Carryover tasks
  carryCard: {
    marginTop: s(layout.cardGap),
    overflow: 'hidden',
  },
  carryHeader: {
    height: s(52),
    paddingHorizontal: s(16),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  carryTitle: {
    marginTop: s(-1),
  },
  carryEmpty: {
    paddingVertical: s(15),
    paddingHorizontal: s(16),
  },

  // Quick settings
  settingsCard: {
    marginTop: s(layout.cardGap),
    paddingTop: s(17.5),
    paddingHorizontal: s(16),
    paddingBottom: s(16),
  },
  settingsTitleRow: {
    height: s(23),
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingsIcon: {
    marginTop: s(2),
  },
  settingsTitle: {
    marginLeft: s(8),
  },
  settingRow: {
    marginTop: s(12),
    height: s(40),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  settingRowFirst: {
    marginTop: s(16.5),
  },
  // Nudged up a little, so the title lines up with the top of the box beside it as in the design.
  settingLabels: {
    marginBottom: s(2.25),
  },
  settingHint: {
    marginTop: s(2.25),
  },
  numberBox: {
    height: s(40),
    borderRadius: s(8),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.obsidian,
  },
  numberInput: {
    flex: 1,
    padding: 0,
    textAlign: 'center',
    fontFamily: fonts.display700,
    fontSize: s(22),
    includeFontPadding: false,
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepButton: {
    width: s(40),
    height: s(40),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(8),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.obsidian,
  },
  stepButtonPlus: {
    borderColor: alpha(colors.ember, 0.6),
    backgroundColor: alpha(colors.ember, 0.15),
  },
  stepValue: {
    width: s(52),
  },
  keyLabelRow: {
    marginTop: s(12),
    height: s(18),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  keyField: {
    marginTop: s(7),
    height: s(44),
    paddingLeft: s(12),
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: s(8),
    borderWidth: 1,
    borderColor: colors.steel,
    backgroundColor: colors.obsidian,
  },
  keyInput: {
    flex: 1,
    marginLeft: s(7.5),
    padding: 0,
    fontFamily: fonts.mono400,
    fontSize: s(13),
    letterSpacing: s(1.5),
    color: colors.titanium,
    includeFontPadding: false,
  },
  eyeButton: {
    height: s(42),
    paddingLeft: s(10),
    paddingRight: s(12),
    justifyContent: 'center',
  },
});
