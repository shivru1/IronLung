/**
 * The big gauge on the Tracker: a 270-degree ring that fills as the time
 * since the last cigarette approaches the wait target.
 *
 * Geometry is in design pixels inside a 240 x 232 box; the box is scaled to
 * the phone as a whole.
 */

import React from 'react';
import { StyleSheet, View } from 'react-native';
import Svg, { Circle, Defs, Line, LinearGradient, Path, Stop } from 'react-native-svg';

import { Display, Mono } from '../primitives';
import { alpha, colors, s } from '../theme';

const BOX_WIDTH = 240;
const BOX_HEIGHT = 232;
const CENTER = 120;
const RADIUS = 98;
const STROKE = 16;
/** The ring starts bottom-left and sweeps clockwise over the top to bottom-right. */
const START_ANGLE = 135;
const SWEEP_ANGLE = 270;
const DOT_RING_RADIUS = 112.9;
const DOT_COUNT = 60;
const DOT_RING_OFFSET_DEG = 3.5;
const MARKER_INNER_RADIUS = 86;
const MARKER_OUTER_RADIUS = 114;
/**
 * Wider, fainter copies of the progress arc, stacked so that together they
 * fade out like a soft glow.
 */
const GLOW_LAYERS = [
  { extraWidth: 3, opacity: 0.1 },
  { extraWidth: 6, opacity: 0.09 },
  { extraWidth: 9, opacity: 0.08 },
  { extraWidth: 12, opacity: 0.06 },
  { extraWidth: 16, opacity: 0.045 },
  { extraWidth: 20, opacity: 0.035 },
  { extraWidth: 25, opacity: 0.025 },
] as const;

function pointAt(angleDeg: number, radius: number): { x: number; y: number } {
  const radians = (angleDeg * Math.PI) / 180;
  return { x: CENTER + radius * Math.cos(radians), y: CENTER + radius * Math.sin(radians) };
}

function arcPath(sweepDeg: number): string {
  const start = pointAt(START_ANGLE, RADIUS);
  const end = pointAt(START_ANGLE + sweepDeg, RADIUS);
  const largeArc = sweepDeg > 180 ? 1 : 0;
  return `M ${start.x.toFixed(3)} ${start.y.toFixed(3)} A ${RADIUS} ${RADIUS} 0 ${largeArc} 1 ${end.x.toFixed(3)} ${end.y.toFixed(3)}`;
}

export interface GapGaugeProps {
  /** 0-100: how full the ring is. */
  progressPercent: number;
  /** 0-100: where to draw the green mark (the wait before the last cigarette). `null` hides it. */
  markerPercent: number | null;
  /** Two-digit hours and minutes since the last cigarette, or `--`. */
  hours: string;
  minutes: string;
  /** `TARGET 02h 30m`. */
  targetLabel: string;
  /** `92% • 12m TO GO`. */
  statusLabel: string;
  /** Label under the start of the ring, `0h`. */
  startLabel: string;
  /** Label under the end of the ring, for example `2h30`. */
  endLabel: string;
}

export function GapGauge(props: GapGaugeProps) {
  const progress = Math.min(100, Math.max(0, props.progressPercent));
  const progressSweep = (SWEEP_ANGLE * progress) / 100;
  const progressPath = progressSweep >= 0.5 ? arcPath(progressSweep) : null;
  const dotGap = (2 * Math.PI * DOT_RING_RADIUS) / DOT_COUNT;

  let marker: { inner: { x: number; y: number }; outer: { x: number; y: number } } | null = null;
  if (props.markerPercent !== null && props.markerPercent > 0 && props.markerPercent < 100) {
    const angle = START_ANGLE + (SWEEP_ANGLE * props.markerPercent) / 100;
    marker = { inner: pointAt(angle, MARKER_INNER_RADIUS), outer: pointAt(angle, MARKER_OUTER_RADIUS) };
  }

  return (
    <View style={styles.box} accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 100, now: Math.round(progress) }}>
      <Svg width={s(BOX_WIDTH)} height={s(BOX_HEIGHT)} viewBox={`0 0 ${BOX_WIDTH} ${BOX_HEIGHT}`}>
        <Defs>
          <LinearGradient id="emberArc" gradientUnits="userSpaceOnUse" x1={0} y1={CENTER - 133} x2={0} y2={CENTER + 133}>
            <Stop offset="0" stopColor={colors.ember} />
            <Stop offset="1" stopColor={colors.emberBright} />
          </LinearGradient>
        </Defs>
        <Circle
          cx={CENTER}
          cy={CENTER}
          r={DOT_RING_RADIUS}
          fill="none"
          stroke={colors.dot}
          strokeWidth={2}
          strokeLinecap="round"
          strokeDasharray={[0.01, dotGap - 0.01]}
          transform={`rotate(${DOT_RING_OFFSET_DEG} ${CENTER} ${CENTER})`}
        />
        <Path d={arcPath(SWEEP_ANGLE)} fill="none" stroke={colors.track} strokeWidth={STROKE} strokeLinecap="round" />
        {progressPath
          ? GLOW_LAYERS.map((layer) => (
              <Path
                key={layer.extraWidth}
                d={progressPath}
                fill="none"
                stroke={colors.ember}
                strokeOpacity={layer.opacity}
                strokeWidth={STROKE + layer.extraWidth}
                strokeLinecap="round"
              />
            ))
          : null}
        {progressPath ? (
          <Path d={progressPath} fill="none" stroke="url(#emberArc)" strokeWidth={STROKE} strokeLinecap="round" />
        ) : null}
        {marker ? (
          <Line
            x1={marker.inner.x}
            y1={marker.inner.y}
            x2={marker.outer.x}
            y2={marker.outer.y}
            stroke={colors.emerald}
            strokeWidth={3}
            strokeLinecap="round"
          />
        ) : null}
      </Svg>

      <View style={styles.center} pointerEvents="none">
        <Mono size={9} color={colors.slate} tracking={1.8}>
          SINCE LAST
        </Mono>
        <View style={styles.digits}>
          <Display size={64} weight={800}>
            {props.hours}
          </Display>
          <Display size={22} weight={800} color={colors.emberBright}>
            h
          </Display>
          <Display size={64} weight={800} style={styles.minutes}>
            {props.minutes}
          </Display>
          <Display size={22} weight={800} color={colors.emberBright}>
            m
          </Display>
        </View>
        <Mono size={10} color={colors.slate} tracking={1} style={styles.target}>
          {props.targetLabel}
        </Mono>
        <View style={styles.status}>
          <Display size={15} weight={700} color={colors.emberBright}>
            {props.statusLabel}
          </Display>
        </View>
      </View>

      <Mono size={9} color={colors.slate} style={styles.startLabel}>
        {props.startLabel}
      </Mono>
      <Mono size={9} color={colors.emerald} style={styles.endLabel}>
        {props.endLabel}
      </Mono>
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    width: s(BOX_WIDTH),
    height: s(BOX_HEIGHT),
    alignSelf: 'center',
  },
  center: {
    position: 'absolute',
    top: s(55),
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  digits: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginTop: s(-1),
  },
  minutes: {
    marginLeft: s(4),
  },
  target: {
    marginTop: s(-1),
  },
  status: {
    marginTop: s(9),
    height: s(28),
    paddingHorizontal: s(9.5),
    borderRadius: s(8),
    borderWidth: 1,
    borderColor: alpha(colors.ember, 0.4),
    backgroundColor: alpha(colors.ember, 0.15),
    alignItems: 'center',
    justifyContent: 'center',
  },
  startLabel: {
    position: 'absolute',
    left: s(14),
    top: s(214),
  },
  endLabel: {
    position: 'absolute',
    right: s(6),
    top: s(214),
  },
});
