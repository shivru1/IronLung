/**
 * The "Daily Smokes" chart: one bar per day, the 7-day average as a line and
 * the daily target as a dashed line.
 *
 * Geometry is in design pixels for a 364-wide plot and scaled to the width
 * the chart actually gets.
 */

import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import Svg, { Circle, Line, Polyline, Rect } from 'react-native-svg';

import { getBarTone } from '../../services/statsEngine';
import type { BarTone, ChartSlot } from '../../services/statsEngine';
import { Display, Mono } from '../primitives';
import { colors, s } from '../theme';

const DESIGN_WIDTH = 364;
const HEIGHT = 220;
/** The plot area inside the chart box, in design pixels. */
const PLOT = { left: 24, right: 356, top: 20.5, bottom: 192.5 } as const;
const AXIS_LABEL_WIDTH = 23;
const X_LABEL_TOP = 195;
const BAR_WIDTH_RATIO = 0.65;
/** Grid lines are thinner than a design pixel; phones draw this as one or two of their own pixels. */
const GRID_LINE_WIDTH = 0.5;
/** More bars than this and the chart drops value labels and dots to stay readable. */
const DENSE_FROM = 12;
const DENSE_LABEL_EVERY = 5;

const BAR_COLORS: Record<BarTone, string> = {
  under: colors.emerald,
  over: colors.ember,
  wayOver: colors.crimson,
};

/** A round top value and step for the vertical axis, with five steps. */
export function getChartAxis(maxValue: number): { max: number; step: number } {
  if (maxValue <= 10) {
    return { max: 10, step: 2 };
  }
  if (maxValue <= 20) {
    return { max: 20, step: 4 };
  }
  if (maxValue <= 30) {
    return { max: 30, step: 6 };
  }
  const max = Math.ceil(maxValue / 10) * 10;
  return { max, step: max / 5 };
}

export function DailySmokesChart({ slots, dailyTarget }: { slots: readonly ChartSlot[]; dailyTarget: number }) {
  const [width, setWidth] = useState(s(DESIGN_WIDTH));
  const k = width / DESIGN_WIDTH;
  const isDense = slots.length > DENSE_FROM;

  const highest = Math.max(dailyTarget, ...slots.map((slot) => Math.max(slot.count ?? 0, slot.rolling7dAvg ?? 0)));
  const axis = getChartAxis(highest);
  const ticks: number[] = [];
  for (let value = 0; value <= axis.max; value += axis.step) {
    ticks.push(value);
  }

  const plotWidth = PLOT.right - PLOT.left;
  const slotWidth = slots.length > 0 ? plotWidth / slots.length : plotWidth;
  const barWidth = slotWidth * BAR_WIDTH_RATIO;
  const yOf = (value: number) => PLOT.bottom - (Math.min(value, axis.max) / axis.max) * (PLOT.bottom - PLOT.top);
  const centerOf = (index: number) => PLOT.left + slotWidth * (index + 0.5);

  const averagePoints = slots
    .map((slot, index) => (slot.rolling7dAvg === null ? null : { x: centerOf(index), y: yOf(slot.rolling7dAvg) }))
    .filter((point): point is { x: number; y: number } => point !== null);
  const targetY = yOf(dailyTarget);
  const lastIndex = slots.length - 1;

  return (
    <View style={styles.box} onLayout={(event) => setWidth(event.nativeEvent.layout.width)}>
      <Svg width={width} height={HEIGHT * k} viewBox={`0 0 ${DESIGN_WIDTH} ${HEIGHT}`}>
        {ticks.map((value) =>
          // The top value only gets its number, no line, as in the design.
          value === axis.max ? null : (
            <Line
              key={`grid-${value}`}
              x1={PLOT.left}
              x2={PLOT.right}
              y1={yOf(value)}
              y2={yOf(value)}
              stroke={colors.steel}
              strokeOpacity={0.75}
              strokeWidth={GRID_LINE_WIDTH}
            />
          ),
        )}
        {slots.map((slot, index) => {
          if (slot.count === null || slot.count <= 0) {
            return null;
          }
          const top = yOf(slot.count);
          return (
            <Rect
              key={`bar-${slot.date}`}
              x={centerOf(index) - barWidth / 2}
              y={top}
              width={barWidth}
              height={PLOT.bottom - top}
              fill={BAR_COLORS[getBarTone(slot.count, slot.target ?? dailyTarget)]}
            />
          );
        })}
        {slots.length > 1 ? (
          <Line
            x1={centerOf(0)}
            x2={centerOf(lastIndex)}
            y1={targetY}
            y2={targetY}
            stroke={colors.titanium}
            strokeWidth={1.5}
            strokeDasharray={[9, 8.75]}
          />
        ) : null}
        {averagePoints.length > 1 ? (
          <Polyline
            points={averagePoints.map((point) => `${point.x.toFixed(2)},${point.y.toFixed(2)}`).join(' ')}
            fill="none"
            stroke={colors.cyan}
            strokeWidth={isDense ? 2 : 3}
            strokeLinejoin="round"
            strokeLinecap="round"
          />
        ) : null}
        {isDense
          ? null
          : averagePoints.map((point) => <Circle key={`dot-${point.x}`} cx={point.x} cy={point.y} r={3} fill={colors.cyan} />)}
      </Svg>

      {ticks.map((value) => (
        <Mono
          key={`tick-${value}`}
          size={10}
          color={colors.slate}
          align="right"
          style={[styles.label, { top: (yOf(value) - 7) * k, left: 0, width: AXIS_LABEL_WIDTH * k }]}
        >
          {value}
        </Mono>
      ))}

      {slots.map((slot, index) => {
        const showDayLabel = !isDense || index === lastIndex || (lastIndex - index) % DENSE_LABEL_EVERY === 0;
        const labelWidth = isDense ? 28 : slotWidth;
        return (
          <React.Fragment key={`labels-${slot.date}`}>
            {!isDense && slot.count !== null ? (
              <Display
                size={14}
                weight={500}
                align="center"
                style={[
                  styles.label,
                  { top: (yOf(slot.count) - 21) * k, left: (centerOf(index) - slotWidth / 2) * k, width: slotWidth * k },
                ]}
              >
                {slot.count}
              </Display>
            ) : null}
            {showDayLabel ? (
              <Mono
                size={10}
                color={colors.slate}
                align="center"
                style={[
                  styles.label,
                  { top: X_LABEL_TOP * k, left: (centerOf(index) - labelWidth / 2) * k, width: labelWidth * k },
                ]}
              >
                {isDense ? slot.dayOfMonth : slot.weekday}
              </Mono>
            ) : null}
          </React.Fragment>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    height: s(HEIGHT),
  },
  label: {
    position: 'absolute',
  },
});
