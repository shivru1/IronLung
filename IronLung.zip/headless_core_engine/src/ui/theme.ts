/**
 * Design tokens taken from the UI screens: colours, fonts and the scale that
 * maps the 430-wide design onto the phone the app runs on.
 */

import { Dimensions } from 'react-native';

/** Width of the design the screens were measured from. */
const DESIGN_WIDTH = 430;

const windowWidth = Dimensions.get('window').width;

/** How much bigger or smaller this phone is than the design. Kept in a sane range for very small or large screens. */
export const SCALE = Math.min(1.3, Math.max(0.72, windowWidth / DESIGN_WIDTH));

/**
 * Converts a size from the design to this phone, so every screen keeps the
 * design's proportions on any width.
 */
export function s(size: number): number {
  return Math.round(size * SCALE * 100) / 100;
}

export const colors = {
  /** Page background. */
  obsidian: '#0A0D12',
  /** Card surface. */
  gunmetal: '#131822',
  /** Card borders and dividers. */
  steel: '#222B3A',
  /** Unfilled part of the gauge. */
  track: '#1A2130',
  /** Dotted ring around the gauge. */
  dot: '#2C3748',
  /** Ember, the deep end: fills, tints and borders. */
  ember: '#FF5500',
  /** Ember, the bright end: text and icons. */
  emberBright: '#FF8800',
  emerald: '#00E676',
  crimson: '#FF2A55',
  cyan: '#00C2FF',
  cobalt: '#2563EB',
  amber: '#FFB020',
  titanium: '#F8FAFC',
  slate: '#94A3B8',
} as const;

/** `#RRGGBB` with an opacity, as an `rgba()` string. */
export function alpha(hex: string, opacity: number): string {
  const red = parseInt(hex.slice(1, 3), 16);
  const green = parseInt(hex.slice(3, 5), 16);
  const blue = parseInt(hex.slice(5, 7), 16);
  return `rgba(${red}, ${green}, ${blue}, ${opacity})`;
}

/** Font family names. They match the names the fonts are loaded under in `App.tsx`. */
export const fonts = {
  display500: 'BarlowCondensed_500Medium',
  display700: 'BarlowCondensed_700Bold',
  display800: 'BarlowCondensed_800ExtraBold',
  mono400: 'JetBrainsMono_400Regular',
  mono500: 'JetBrainsMono_500Medium',
  mono700: 'JetBrainsMono_700Bold',
  body400: 'Inter_400Regular',
  body500: 'Inter_500Medium',
  body600: 'Inter_600SemiBold',
} as const;

/** A soft coloured glow around a view (design sizes in, scaled string out). */
export function glow(color: string, opacity: number, blur: number, spread = 0): string {
  return `0px 0px ${s(blur)}px ${s(spread)}px ${alpha(color, opacity)}`;
}

/** Shared measurements. */
export const layout = {
  screenPadding: 16,
  cardRadius: 16,
  cardGap: 16,
  tabBarHeight: 75,
  /** Space between the last card and the tab bar. */
  bottomGap: 37,
} as const;
