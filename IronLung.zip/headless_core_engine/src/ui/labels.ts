/**
 * Short labels the screens show next to tasks, brain dumps and briefings.
 * Pure functions only, so the screens stay free of logic.
 */

import type { LlmProvider } from '../config/appConfig';
import type { BrainDumpCategory } from '../types/schema';
import { diffInDays, getDayOfMonth, getWeekdayLabel } from '../utils/dateUtils';
import { formatSignedMins } from '../utils/format';

/**
 * When a brain dump was made, relative to today: `TODAY 11:40`,
 * `YESTERDAY 22:05`, and `MON 17 18:30` for anything older.
 *
 * Days are logical days, so a dump made at 01:30 at night still reads TODAY
 * until 04:00. The time is the one the phone's clock showed.
 */
export function formatDumpTimeLabel(createdAt: string, logicalDate: string, todayDate: string): string {
  const time = createdAt.slice(11, 16);
  const ageDays = diffInDays(logicalDate, todayDate);
  if (ageDays <= 0) {
    return `TODAY ${time}`;
  }
  if (ageDays === 1) {
    return `YESTERDAY ${time}`;
  }
  return `${getWeekdayLabel(logicalDate)} ${String(getDayOfMonth(logicalDate)).padStart(2, '0')} ${time}`;
}

export type TaskTagTone = 'deadline' | 'work' | 'personal' | 'idea';

export interface TaskTag {
  label: string;
  tone: TaskTagTone;
}

const TONE_BY_CATEGORY: Record<BrainDumpCategory, TaskTagTone> = {
  Work: 'work',
  Personal: 'personal',
  Idea: 'idea',
};

/**
 * The small label at the right of a task: its deadline when it has one,
 * otherwise the kind of brain dump it came from. Finished tasks have none.
 */
export function getTaskTag(task: { done: boolean; dueTime: string | null; category: BrainDumpCategory }): TaskTag | null {
  if (task.done) {
    return null;
  }
  if (task.dueTime) {
    return { label: `BY ${task.dueTime}`, tone: 'deadline' };
  }
  return { label: task.category.toUpperCase(), tone: TONE_BY_CATEGORY[task.category] };
}

export type TrendDirection = 'down' | 'up' | 'flat' | 'none';

export interface TrendBadge {
  label: string;
  /** `down` means fewer cigarettes than the week before. `none` means there is no week to compare with. */
  direction: TrendDirection;
}

/** The badge on the smoke trend card, for example `18% VS LAST WK` with direction `down`. */
export function getTrendBadge(changePct: number | null): TrendBadge {
  if (changePct === null) {
    return { label: 'NO EARLIER WEEK', direction: 'none' };
  }
  const rounded = Math.round(changePct);
  if (rounded === 0) {
    return { label: 'SAME AS LAST WK', direction: 'flat' };
  }
  return { label: `${Math.abs(rounded)}% VS LAST WK`, direction: rounded < 0 ? 'down' : 'up' };
}

/** How long a carried-over task has been waiting: `DONE`, `TODAY` or `3D OLD`. */
export function formatTaskAge(ageDays: number, done: boolean): string {
  if (done) {
    return 'DONE';
  }
  return ageDays <= 0 ? 'TODAY' : `${Math.floor(ageDays)}D OLD`;
}

/** An average with one decimal, or `--` when there is nothing to average. */
export function formatAverage(value: number | null): string {
  return value === null ? '--' : value.toFixed(1);
}

/** The caption under the average gap: `AVG GAP (+34m)`, or just `AVG GAP` without a week to compare with. */
export function formatGapCaption(deltaMins: number | null): string {
  return deltaMins === null ? 'AVG GAP' : `AVG GAP (${formatSignedMins(deltaMins)})`;
}

/** The digits in `text`, cut to at most `maxDigits`. Used while typing into a number box. */
export function keepDigits(text: string, maxDigits: number): string {
  return text.replace(/\D/g, '').slice(0, maxDigits);
}

/**
 * Reads the whole number typed into a settings box. Returns `null` when the
 * box holds no digit, so the caller can keep the old value.
 */
export function parseWholeNumber(text: string): number | null {
  const digits = text.replace(/\D/g, '');
  return digits === '' ? null : Number(digits);
}

export type KeyStatusTone = 'saved' | 'unsaved' | 'empty';

export interface KeyStatus {
  label: string;
  tone: KeyStatusTone;
}

const PROVIDER_NAMES: Record<LlmProvider, string> = {
  gemini: 'GEMINI',
  openai: 'OPENAI',
  anthropic: 'CLAUDE',
};

/**
 * What the settings card says next to the AI key box: whether the text in the
 * box is the saved key, and which AI the saved key belongs to.
 */
export function getKeyStatus(input: { savedKey: string | null; typedKey: string; provider: LlmProvider | null }): KeyStatus {
  const savedKey = input.savedKey ?? '';
  if (input.typedKey.trim() !== savedKey) {
    return { label: 'NOT SAVED YET', tone: 'unsaved' };
  }
  if (savedKey === '') {
    return { label: 'NOT SET', tone: 'empty' };
  }
  return { label: input.provider ? `SAVED \u00B7 ${PROVIDER_NAMES[input.provider]}` : 'SAVED', tone: 'saved' };
}
