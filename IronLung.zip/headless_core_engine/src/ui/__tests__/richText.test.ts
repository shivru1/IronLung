import { splitCoachHighlights, splitEmphasis } from '../richText';

describe('splitEmphasis', () => {
  it('marks the text between double asterisks as strong', () => {
    expect(splitEmphasis('Down from 44. **Friday blew it with 8.** Fix that day.')).toEqual([
      { text: 'Down from 44. ', strong: false },
      { text: 'Friday blew it with 8.', strong: true },
      { text: ' Fix that day.', strong: false },
    ]);
  });

  it('returns one plain part for text without markers', () => {
    expect(splitEmphasis('Stress is your tell.')).toEqual([{ text: 'Stress is your tell.', strong: false }]);
  });

  it('handles a strong part at the start and more than one of them', () => {
    expect(splitEmphasis('**₹300 saved** and **a longer gap**')).toEqual([
      { text: '₹300 saved', strong: true },
      { text: ' and ', strong: false },
      { text: 'a longer gap', strong: true },
    ]);
  });

  it('keeps a strong part that runs over a line break', () => {
    expect(splitEmphasis('4 of 7 days. **Friday\nblew it with 8.** Fix that day.')).toEqual([
      { text: '4 of 7 days. ', strong: false },
      { text: 'Friday\nblew it with 8.', strong: true },
      { text: ' Fix that day.', strong: false },
    ]);
  });

  it('drops a marker that has no partner', () => {
    expect(splitEmphasis('Stress is **your tell.')).toEqual([{ text: 'Stress is your tell.', strong: false }]);
  });

  it('returns nothing for empty text', () => {
    expect(splitEmphasis('')).toEqual([]);
  });
});

describe('splitCoachHighlights', () => {
  it('picks out a quoted phrase and leaves clock times and counts alone', () => {
    const parts = splitCoachHighlights('Your 11:40 dump: "client deck is killing me." That\'s 2 of your 4 smokes today.');

    expect(parts).toEqual([
      { text: 'Your 11:40 dump: ', tone: 'plain' },
      { text: '"client deck is killing me."', tone: 'quote' },
      { text: " That's 2 of your 4 smokes today.", tone: 'plain' },
    ]);
  });

  it('picks out a wait written with its unit', () => {
    const parts = splitCoachHighlights('Danger window opens in 8 min. 12 more minutes and you beat the gap.');

    expect(parts).toEqual([
      { text: 'Danger window opens in ', tone: 'plain' },
      { text: '8 min', tone: 'time' },
      { text: '. 12 more minutes and you beat the gap.', tone: 'plain' },
    ]);
  });

  it('recognises the compact ways of writing a wait', () => {
    const parts = splitCoachHighlights('Wait 2h 30m, not 45m. That is 4 hours of gap.');

    expect(parts.filter((part) => part.tone === 'time').map((part) => part.text)).toEqual(['2h 30m', '45m', '4 hours']);
  });

  it('recognises curly quotes', () => {
    const parts = splitCoachHighlights('You said \u201Cdeck is killing me\u201D at noon.');

    expect(parts[1]).toEqual({ text: '\u201Cdeck is killing me\u201D', tone: 'quote' });
  });

  it('returns one plain part when there is nothing to highlight', () => {
    expect(splitCoachHighlights('Walk. Water. Don\'t negotiate.')).toEqual([
      { text: "Walk. Water. Don't negotiate.", tone: 'plain' },
    ]);
  });

  it('returns nothing for empty text', () => {
    expect(splitCoachHighlights('')).toEqual([]);
  });
});
