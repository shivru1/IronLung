import {
  formatAverage,
  formatDumpTimeLabel,
  formatGapCaption,
  formatTaskAge,
  getKeyStatus,
  getTaskTag,
  getTrendBadge,
  keepDigits,
  parseWholeNumber,
} from '../labels';

describe('formatDumpTimeLabel', () => {
  it('says TODAY for a dump of the current logical day', () => {
    expect(formatDumpTimeLabel('2026-11-24T11:40:00.000+05:30', '2026-11-24', '2026-11-24')).toBe('TODAY 11:40');
  });

  it('still says TODAY for a dump after midnight that belongs to the same logical day', () => {
    expect(formatDumpTimeLabel('2026-11-25T01:30:00.000+05:30', '2026-11-24', '2026-11-24')).toBe('TODAY 01:30');
  });

  it('says YESTERDAY for a dump of the logical day before', () => {
    expect(formatDumpTimeLabel('2026-11-23T22:05:00.000+05:30', '2026-11-23', '2026-11-24')).toBe('YESTERDAY 22:05');
  });

  it('shows the weekday and day of the month for older dumps', () => {
    expect(formatDumpTimeLabel('2026-11-17T18:30:00.000+05:30', '2026-11-17', '2026-11-24')).toBe('TUE 17 18:30');
  });

  it('pads a single-digit day of the month', () => {
    expect(formatDumpTimeLabel('2026-11-05T09:00:00.000+05:30', '2026-11-05', '2026-11-24')).toBe('THU 05 09:00');
  });
});

describe('getTaskTag', () => {
  it('shows the deadline when the task has one', () => {
    expect(getTaskTag({ done: false, dueTime: '15:00', category: 'Work' })).toEqual({ label: 'BY 15:00', tone: 'deadline' });
  });

  it('shows the kind of brain dump when there is no deadline', () => {
    expect(getTaskTag({ done: false, dueTime: null, category: 'Personal' })).toEqual({ label: 'PERSONAL', tone: 'personal' });
    expect(getTaskTag({ done: false, dueTime: null, category: 'Idea' })).toEqual({ label: 'IDEA', tone: 'idea' });
    expect(getTaskTag({ done: false, dueTime: null, category: 'Work' })).toEqual({ label: 'WORK', tone: 'work' });
  });

  it('shows nothing for a finished task, even one with a deadline', () => {
    expect(getTaskTag({ done: true, dueTime: '15:00', category: 'Work' })).toBeNull();
  });
});

describe('getTrendBadge', () => {
  it('reports fewer cigarettes as down, without the minus sign', () => {
    expect(getTrendBadge(-18)).toEqual({ label: '18% VS LAST WK', direction: 'down' });
  });

  it('reports more cigarettes as up', () => {
    expect(getTrendBadge(12)).toEqual({ label: '12% VS LAST WK', direction: 'up' });
  });

  it('reports no change as flat', () => {
    expect(getTrendBadge(0)).toEqual({ label: 'SAME AS LAST WK', direction: 'flat' });
  });

  it('says so when there is no earlier week', () => {
    expect(getTrendBadge(null)).toEqual({ label: 'NO EARLIER WEEK', direction: 'none' });
  });
});

describe('formatTaskAge', () => {
  it('counts the days an open task has waited', () => {
    expect(formatTaskAge(3, false)).toBe('3D OLD');
  });

  it('says TODAY for a task from today', () => {
    expect(formatTaskAge(0, false)).toBe('TODAY');
  });

  it('says DONE for a finished task whatever its age', () => {
    expect(formatTaskAge(5, true)).toBe('DONE');
  });
});

describe('formatAverage', () => {
  it('rounds to one decimal', () => {
    expect(formatAverage(7.3333)).toBe('7.3');
    expect(formatAverage(4)).toBe('4.0');
  });

  it('shows dashes when there is no value', () => {
    expect(formatAverage(null)).toBe('--');
  });
});

describe('formatGapCaption', () => {
  it('adds the change against the week before', () => {
    expect(formatGapCaption(34)).toBe('AVG GAP (+34m)');
    expect(formatGapCaption(-12)).toBe('AVG GAP (-12m)');
  });

  it('leaves the change out when there is no week to compare with', () => {
    expect(formatGapCaption(null)).toBe('AVG GAP');
  });
});

describe('keepDigits', () => {
  it('drops everything that is not a digit', () => {
    expect(keepDigits('₹1a5', 4)).toBe('15');
  });

  it('cuts to the allowed number of digits', () => {
    expect(keepDigits('12345', 2)).toBe('12');
  });

  it('returns an empty string when nothing is left', () => {
    expect(keepDigits('₹', 4)).toBe('');
  });
});

describe('getKeyStatus', () => {
  it('names the AI when the box holds the saved key', () => {
    expect(getKeyStatus({ savedKey: 'AIza123', typedKey: 'AIza123', provider: 'gemini' })).toEqual({
      label: 'SAVED \u00B7 GEMINI',
      tone: 'saved',
    });
    expect(getKeyStatus({ savedKey: 'sk-ant-1', typedKey: 'sk-ant-1', provider: 'anthropic' })).toEqual({
      label: 'SAVED \u00B7 CLAUDE',
      tone: 'saved',
    });
  });

  it('ignores spaces around the typed key', () => {
    expect(getKeyStatus({ savedKey: 'sk-abc', typedKey: ' sk-abc ', provider: 'openai' })).toEqual({
      label: 'SAVED \u00B7 OPENAI',
      tone: 'saved',
    });
  });

  it('warns while the box differs from the saved key', () => {
    expect(getKeyStatus({ savedKey: 'AIza123', typedKey: 'AIza1234', provider: 'gemini' })).toEqual({
      label: 'NOT SAVED YET',
      tone: 'unsaved',
    });
    expect(getKeyStatus({ savedKey: null, typedKey: 'sk-new', provider: null })).toEqual({
      label: 'NOT SAVED YET',
      tone: 'unsaved',
    });
  });

  it('says NOT SET when there is no key at all', () => {
    expect(getKeyStatus({ savedKey: null, typedKey: '', provider: null })).toEqual({ label: 'NOT SET', tone: 'empty' });
  });
});

describe('parseWholeNumber', () => {
  it('reads plain digits', () => {
    expect(parseWholeNumber('15')).toBe(15);
  });

  it('ignores everything that is not a digit', () => {
    expect(parseWholeNumber('₹ 2 0')).toBe(20);
  });

  it('returns null when there is no digit at all', () => {
    expect(parseWholeNumber('')).toBeNull();
    expect(parseWholeNumber(' . ')).toBeNull();
  });
});
