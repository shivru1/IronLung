/**
 * Splits text into plain and highlighted parts so the screens can colour
 * them. Pure functions only.
 */

export interface EmphasisPart {
  text: string;
  strong: boolean;
}

/**
 * Splits text on `**double asterisks**`. The AI uses them in briefings to
 * mark the phrase that matters most. The marked phrase may run over a line
 * break, and a marker without a partner is dropped instead of being shown.
 */
export function splitEmphasis(text: string): EmphasisPart[] {
  const parts: EmphasisPart[] = [];
  const pattern = /\*\*([\s\S]+?)\*\*/g;
  const addPlain = (plain: string) => {
    const clean = plain.replace(/\*\*/g, '');
    if (clean) {
      parts.push({ text: clean, strong: false });
    }
  };
  let cursor = 0;
  let match = pattern.exec(text);
  while (match !== null) {
    addPlain(text.slice(cursor, match.index));
    parts.push({ text: match[1] ?? '', strong: true });
    cursor = match.index + match[0].length;
    match = pattern.exec(text);
  }
  addPlain(text.slice(cursor));
  return parts;
}

export type CoachTone = 'plain' | 'quote' | 'time';

export interface CoachPart {
  text: string;
  tone: CoachTone;
}

// A quoted phrase ("..." or curly quotes), or a wait written with its unit ("8 min", "2h 30m", "45m").
const COACH_PATTERN =
  /("[^"\n]+"|\u201C[^\u201D\n]+\u201D)|(\b\d+\s?h(?:\s?\d+\s?m(?:in)?)?\b|\b\d+\s?(?:mins?|minutes?|hrs?|hours?)\b|\b\d+m\b)/g;

/**
 * Splits a coach message into plain text, quoted phrases (shown in red, used
 * for brain dump quotes) and waits such as "8 min" (shown in orange).
 */
export function splitCoachHighlights(text: string): CoachPart[] {
  const parts: CoachPart[] = [];
  const pattern = new RegExp(COACH_PATTERN.source, 'g');
  let cursor = 0;
  let match = pattern.exec(text);
  while (match !== null) {
    if (match.index > cursor) {
      parts.push({ text: text.slice(cursor, match.index), tone: 'plain' });
    }
    parts.push({ text: match[0], tone: match[1] !== undefined ? 'quote' : 'time' });
    cursor = match.index + match[0].length;
    match = pattern.exec(text);
  }
  if (cursor < text.length) {
    parts.push({ text: text.slice(cursor), tone: 'plain' });
  }
  return parts;
}
