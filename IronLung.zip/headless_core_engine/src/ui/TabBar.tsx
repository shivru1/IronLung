/** The bottom bar with the four tabs. */

import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Icon, Mono } from './primitives';
import type { IconName } from './primitives';
import { alpha, colors, layout, s } from './theme';

export type TabKey = 'tracker' | 'stats' | 'brainDump' | 'realTalk';

interface TabSpec {
  key: TabKey;
  label: string;
  icon: IconName;
  /** Icon and label colour when selected. */
  accent: string;
  /** Colour of the pill behind the selected icon. */
  tint: string;
}

const TABS: readonly TabSpec[] = [
  { key: 'tracker', label: 'TRACKER', icon: 'gauge-high', accent: colors.emberBright, tint: colors.ember },
  { key: 'stats', label: 'STATS', icon: 'chart-column', accent: colors.emberBright, tint: colors.ember },
  { key: 'brainDump', label: 'BRAIN DUMP', icon: 'microphone-lines', accent: colors.cyan, tint: colors.cyan },
  { key: 'realTalk', label: 'REAL TALK', icon: 'bolt-lightning', accent: colors.emberBright, tint: colors.ember },
];

export function TabBar({ active, onChange }: { active: TabKey; onChange: (tab: TabKey) => void }) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.bar, { height: s(layout.tabBarHeight) + insets.bottom, paddingBottom: insets.bottom }]}>
      {TABS.map((tab) => {
        const isSelected = tab.key === active;
        return (
          <Pressable
            key={tab.key}
            style={styles.tab}
            onPress={() => onChange(tab.key)}
            accessibilityRole="tab"
            accessibilityState={{ selected: isSelected }}
            accessibilityLabel={tab.label}
          >
            <View style={[styles.pill, isSelected && { backgroundColor: alpha(tab.tint, 0.15) }]}>
              <Icon name={tab.icon} color={isSelected ? tab.accent : colors.slate} style={styles.icon} />
            </View>
            <Mono
              size={9.6}
              lineHeight={13}
              weight={isSelected ? 700 : 400}
              color={isSelected ? tab.accent : colors.slate}
              tracking={1.1}
              style={styles.label}
            >
              {tab.label}
            </Mono>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    paddingHorizontal: s(8),
    backgroundColor: colors.obsidian,
    borderTopWidth: 1,
    borderTopColor: colors.steel,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
  },
  pill: {
    marginTop: s(8),
    width: s(48),
    height: s(32),
    borderRadius: s(16),
    alignItems: 'center',
    justifyContent: 'center',
  },
  // The icons sit a little above the middle of the pill, as in the design.
  icon: {
    marginBottom: s(3),
  },
  label: {
    marginTop: s(3.8),
  },
});
