/**
 * The shell every screen sits in: the dark page, the coloured glow at the top
 * and a scroll view with the design's paddings.
 */

import React from 'react';
import { ScrollView, StyleSheet, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Defs, RadialGradient, Rect, Stop } from 'react-native-svg';

import { colors, layout, s } from './theme';

export interface PageGlow {
  color: string;
  /** Strength at the centre of the glow, 0-1. */
  opacity: number;
  /** Where the glow sits across the top edge: 0 is the left side, 1 the right. */
  centerX: number;
}

const GLOW_HEIGHT = 460;
const GLOW_RADIUS_Y = 340;

export function ScreenFrame({
  glow,
  children,
  scrollRef,
  scrollEnabled = true,
}: {
  glow: PageGlow;
  children: React.ReactNode;
  scrollRef?: React.RefObject<ScrollView | null>;
  /** Set to false to keep the page still, for example while a button is held down. */
  scrollEnabled?: boolean;
}) {
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const glowHeight = s(GLOW_HEIGHT);
  const centerX = width * glow.centerX;

  return (
    <View style={styles.root}>
      <Svg width={width} height={glowHeight} style={styles.glow} pointerEvents="none">
        <Defs>
          <RadialGradient
            id="pageGlow"
            gradientUnits="userSpaceOnUse"
            cx={centerX}
            cy={0}
            fx={centerX}
            fy={0}
            rx={width * 0.62}
            ry={s(GLOW_RADIUS_Y)}
          >
            <Stop offset="0" stopColor={glow.color} stopOpacity={glow.opacity} />
            <Stop offset="1" stopColor={glow.color} stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Rect x={0} y={0} width={width} height={glowHeight} fill="url(#pageGlow)" />
      </Svg>
      <ScrollView
        ref={scrollRef}
        scrollEnabled={scrollEnabled}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        overScrollMode="never"
        contentContainerStyle={{
          paddingTop: insets.top + s(layout.screenPadding),
          paddingHorizontal: s(layout.screenPadding),
          paddingBottom: s(layout.bottomGap),
        }}
      >
        {children}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.obsidian,
  },
  glow: {
    position: 'absolute',
    top: 0,
    left: 0,
  },
});
