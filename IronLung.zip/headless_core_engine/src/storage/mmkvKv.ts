/**
 * MMKV-backed storage: synchronous reads and writes straight from memory-mapped
 * files, so the UI never waits for storage.
 *
 * react-native-mmkv changed its API between version 3 (`new MMKV()`,
 * `.delete()`) and version 4 (`createMMKV()`, `.remove()`). This adapter works
 * with either, so the app does not depend on which one gets installed.
 */

import * as MmkvModule from 'react-native-mmkv';

import type { KeyValueStore } from './kv';

interface MmkvInstance {
  getString(key: string): string | undefined;
  set(key: string, value: string): void;
  getAllKeys(): string[];
  remove?: (key: string) => unknown;
  delete?: (key: string) => unknown;
}

interface MmkvExports {
  createMMKV?: (config: { id: string }) => MmkvInstance;
  MMKV?: new (config: { id: string }) => MmkvInstance;
}

export function createMmkvKv(id: string): KeyValueStore {
  const mmkv = MmkvModule as unknown as MmkvExports;
  let instance: MmkvInstance;
  if (typeof mmkv.createMMKV === 'function') {
    instance = mmkv.createMMKV({ id });
  } else if (typeof mmkv.MMKV === 'function') {
    instance = new mmkv.MMKV({ id });
  } else {
    throw new Error(
      'react-native-mmkv is not available. This app needs its own build (npx expo run:android); it cannot run inside Expo Go.',
    );
  }

  return {
    getString: (key) => instance.getString(key),
    set: (key, value) => instance.set(key, value),
    remove: (key) => {
      if (typeof instance.remove === 'function') {
        instance.remove(key);
      } else if (typeof instance.delete === 'function') {
        instance.delete(key);
      }
    },
    getAllKeys: () => instance.getAllKeys(),
  };
}
