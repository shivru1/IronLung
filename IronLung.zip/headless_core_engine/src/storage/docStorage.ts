/**
 * Saves the app state as one small document per key instead of one big blob.
 *
 * The store hands over its whole persisted state after every change. Because
 * the state is updated immutably, a document that did not change is still the
 * very same object, so only the documents that are new or different are
 * written. Logging a cigarette therefore rewrites one day, not the full
 * history, however long the history gets.
 *
 * Document paths are the same as in Firestore (`daily_logs/2026-11-24`), and
 * every written or deleted path is remembered as "dirty" until the cloud sync
 * has uploaded it.
 *
 * The object has the shape Zustand's `persist` middleware expects from a
 * storage (`getItem` / `setItem` / `removeItem`), all synchronous.
 */

import type {
  BrainDumpDoc,
  DailyLogDoc,
  RealTalkBriefingDoc,
  RollingMemoryDoc,
  SettingsDoc,
} from '../types/schema';
import type { KeyValueStore } from './kv';

/** The part of the store that is saved on the phone and synced to the cloud. */
export interface PersistedState {
  settings: SettingsDoc;
  /** Keyed by logical date. */
  dailyLogs: Record<string, DailyLogDoc>;
  rollingMemory: RollingMemoryDoc | null;
  /** Keyed by brain dump id. */
  brainDumps: Record<string, BrainDumpDoc>;
  /** Keyed by week id. */
  briefings: Record<string, RealTalkBriefingDoc>;
}

export interface StoredValue {
  state: PersistedState;
  version?: number;
}

export const DOC_PATHS = {
  settings: 'settings/app',
  rollingMemory: 'ai_context/rolling_memory',
  dailyLogs: 'daily_logs/',
  brainDumps: 'brain_dumps/',
  briefings: 'real_talk_briefings/',
} as const;

const DOC_KEY_PREFIX = 'doc:';
const VERSION_KEY = 'meta:version';
const DIRTY_KEY = 'meta:dirty';

export class DocStorage {
  private lastSaved: PersistedState | null = null;
  private dirty: Set<string> | null = null;

  /**
   * @param kv Where the documents are kept.
   * @param emptyState Used for any part that is missing on disk.
   */
  constructor(
    private readonly kv: KeyValueStore,
    private readonly emptyState: PersistedState,
  ) {}

  // -------------------------------------------------------------------------
  // Zustand storage interface
  // -------------------------------------------------------------------------

  /** Loads everything. Returns `null` when nothing was ever saved. */
  getItem(_name: string): StoredValue | null {
    const versionText = this.kv.getString(VERSION_KEY);
    if (versionText === undefined) {
      return null;
    }
    const state: PersistedState = {
      settings: this.emptyState.settings,
      dailyLogs: {},
      rollingMemory: null,
      brainDumps: {},
      briefings: {},
    };
    for (const key of this.kv.getAllKeys()) {
      if (!key.startsWith(DOC_KEY_PREFIX)) {
        continue;
      }
      const path = key.slice(DOC_KEY_PREFIX.length);
      const doc = this.readDoc(path);
      if (doc === undefined) {
        continue;
      }
      if (path === DOC_PATHS.settings) {
        state.settings = { ...this.emptyState.settings, ...(doc as Partial<SettingsDoc>) };
      } else if (path === DOC_PATHS.rollingMemory) {
        state.rollingMemory = doc as RollingMemoryDoc;
      } else if (path.startsWith(DOC_PATHS.dailyLogs)) {
        state.dailyLogs[path.slice(DOC_PATHS.dailyLogs.length)] = doc as DailyLogDoc;
      } else if (path.startsWith(DOC_PATHS.brainDumps)) {
        state.brainDumps[path.slice(DOC_PATHS.brainDumps.length)] = doc as BrainDumpDoc;
      } else if (path.startsWith(DOC_PATHS.briefings)) {
        state.briefings[path.slice(DOC_PATHS.briefings.length)] = doc as RealTalkBriefingDoc;
      }
    }
    this.lastSaved = state;
    return { state, version: Number(versionText) || 0 };
  }

  /** Saves the documents that changed since the last call. */
  setItem(_name: string, value: StoredValue): void {
    const next = value.state;
    const previous = this.lastSaved;

    if (!previous || previous.settings !== next.settings) {
      this.writeDoc(DOC_PATHS.settings, next.settings);
    }
    if (!previous || previous.rollingMemory !== next.rollingMemory) {
      if (next.rollingMemory) {
        this.writeDoc(DOC_PATHS.rollingMemory, next.rollingMemory);
      } else if (previous?.rollingMemory) {
        this.deleteDoc(DOC_PATHS.rollingMemory);
      }
    }
    this.saveCollection(DOC_PATHS.dailyLogs, next.dailyLogs, previous?.dailyLogs);
    this.saveCollection(DOC_PATHS.brainDumps, next.brainDumps, previous?.brainDumps);
    this.saveCollection(DOC_PATHS.briefings, next.briefings, previous?.briefings);

    const version = String(value.version ?? 0);
    if (this.kv.getString(VERSION_KEY) !== version) {
      this.kv.set(VERSION_KEY, version);
    }
    this.lastSaved = next;
  }

  /** Deletes everything this storage wrote. */
  removeItem(_name: string): void {
    for (const key of this.kv.getAllKeys()) {
      if (key.startsWith(DOC_KEY_PREFIX) || key === VERSION_KEY || key === DIRTY_KEY) {
        this.kv.remove(key);
      }
    }
    this.lastSaved = null;
    this.dirty = new Set();
  }

  // -------------------------------------------------------------------------
  // For the cloud sync
  // -------------------------------------------------------------------------

  /** Reads one document by its path. `undefined` when it is missing or unreadable. */
  readDoc(path: string): unknown {
    const text = this.kv.getString(DOC_KEY_PREFIX + path);
    if (text === undefined) {
      return undefined;
    }
    try {
      return JSON.parse(text) as unknown;
    } catch {
      return undefined;
    }
  }

  /** Paths of all documents on the phone. */
  listDocPaths(): string[] {
    return this.kv
      .getAllKeys()
      .filter((key) => key.startsWith(DOC_KEY_PREFIX))
      .map((key) => key.slice(DOC_KEY_PREFIX.length))
      .sort();
  }

  /** Paths that were written or deleted and not uploaded yet. */
  getDirtyPaths(): string[] {
    return [...this.loadDirty()].sort();
  }

  /** Call after the given paths were uploaded (or deleted) in the cloud. */
  clearDirtyPaths(paths: readonly string[]): void {
    const dirty = this.loadDirty();
    let changed = false;
    for (const path of paths) {
      changed = dirty.delete(path) || changed;
    }
    if (changed) {
      this.saveDirty();
    }
  }

  /** Queues every document for upload, for example for the first backup. */
  markAllDirty(): void {
    const dirty = this.loadDirty();
    for (const path of this.listDocPaths()) {
      dirty.add(path);
    }
    this.saveDirty();
  }

  // -------------------------------------------------------------------------
  // Internals
  // -------------------------------------------------------------------------

  private saveCollection<T>(
    prefix: string,
    next: Readonly<Record<string, T>>,
    previous: Readonly<Record<string, T>> | undefined,
  ): void {
    if (next === previous) {
      return;
    }
    for (const id of Object.keys(next)) {
      if (!previous || previous[id] !== next[id]) {
        this.writeDoc(prefix + id, next[id]);
      }
    }
    if (previous) {
      for (const id of Object.keys(previous)) {
        if (!(id in next)) {
          this.deleteDoc(prefix + id);
        }
      }
    }
  }

  private writeDoc(path: string, doc: unknown): void {
    this.kv.set(DOC_KEY_PREFIX + path, JSON.stringify(doc));
    this.markDirty(path);
  }

  private deleteDoc(path: string): void {
    this.kv.remove(DOC_KEY_PREFIX + path);
    this.markDirty(path);
  }

  private markDirty(path: string): void {
    const dirty = this.loadDirty();
    if (!dirty.has(path)) {
      dirty.add(path);
      this.saveDirty();
    }
  }

  private loadDirty(): Set<string> {
    if (this.dirty) {
      return this.dirty;
    }
    let paths: unknown = [];
    try {
      paths = JSON.parse(this.kv.getString(DIRTY_KEY) ?? '[]') as unknown;
    } catch {
      paths = [];
    }
    this.dirty = new Set(Array.isArray(paths) ? paths.filter((p): p is string => typeof p === 'string') : []);
    return this.dirty;
  }

  private saveDirty(): void {
    this.kv.set(DIRTY_KEY, JSON.stringify([...this.loadDirty()]));
  }
}
