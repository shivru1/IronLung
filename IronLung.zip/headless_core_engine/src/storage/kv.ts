/**
 * The smallest storage interface the app needs: synchronous string values by
 * key. On the phone it is backed by MMKV (`mmkvKv.ts`); tests use the
 * in-memory version below.
 */
export interface KeyValueStore {
  getString(key: string): string | undefined;
  set(key: string, value: string): void;
  remove(key: string): void;
  getAllKeys(): string[];
}

/** A store that lives in memory only. Used by tests. */
export function createMemoryKv(initial: Record<string, string> = {}): KeyValueStore {
  const values = new Map<string, string>(Object.entries(initial));
  return {
    getString: (key) => values.get(key),
    set: (key, value) => {
      values.set(key, value);
    },
    remove: (key) => {
      values.delete(key);
    },
    getAllKeys: () => [...values.keys()],
  };
}
