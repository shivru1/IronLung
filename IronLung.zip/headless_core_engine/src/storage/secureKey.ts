/**
 * The AI API key, kept in the phone's secure storage (Android Keystore) and
 * never in the app's normal data or in the cloud backup.
 */

import * as SecureStore from 'expo-secure-store';

const STORAGE_KEY = 'ironlung_ai_api_key';

let cachedKey: string | null = null;
let isLoaded = false;
let loading: Promise<string | null> | null = null;
const listeners = new Set<() => void>();

function notify(): void {
  for (const listener of listeners) {
    listener();
  }
}

/** Reads the key from secure storage (once) and returns it, or `null` when none is saved. */
export function loadApiKey(): Promise<string | null> {
  if (isLoaded) {
    return Promise.resolve(cachedKey);
  }
  if (!loading) {
    loading = SecureStore.getItemAsync(STORAGE_KEY)
      .then((value) => (value && value.trim() ? value.trim() : null))
      .catch(() => null)
      .then((key) => {
        // A key saved while this read was running wins.
        if (!isLoaded) {
          cachedKey = key;
          isLoaded = true;
          notify();
        }
        return cachedKey;
      });
  }
  return loading;
}

/** The key if it was already read or saved in this session, else `null`. Does not touch storage. */
export function getCachedApiKey(): string | null {
  return cachedKey;
}

/** Saves the key. An empty string removes it. */
export async function saveApiKey(key: string): Promise<void> {
  const clean = key.trim();
  cachedKey = clean === '' ? null : clean;
  isLoaded = true;
  notify();
  if (clean === '') {
    await SecureStore.deleteItemAsync(STORAGE_KEY);
  } else {
    await SecureStore.setItemAsync(STORAGE_KEY, clean);
  }
}

/** Calls `listener` whenever the key changes. Returns a function that stops it. */
export function subscribeToApiKey(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
