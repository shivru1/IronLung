/**
 * Bridges to the phone itself: haptics, notifications and speech-to-text.
 *
 * This file knows nothing about the app's data. Notification buttons call the
 * handlers registered with `setNotificationActionHandlers`, and the texts come
 * from `notificationContent.ts`, so everything here stays a thin wrapper
 * around the native modules.
 */

import * as Haptics from 'expo-haptics';
import * as Notifications from 'expo-notifications';
import { ExpoSpeechRecognitionModule } from 'expo-speech-recognition';
import * as TaskManager from 'expo-task-manager';

import { APP_CONFIG } from '../config/appConfig';
import { buildDangerAlertPlan } from './notificationContent';
import type { NotificationText } from './notificationContent';
import { applySpeechResult, commitInterim, EMPTY_TRANSCRIPT, getFullTranscript } from './speechTranscript';
import type { TranscriptState } from './speechTranscript';

// ---------------------------------------------------------------------------
// 1. Haptics
// ---------------------------------------------------------------------------

function ignoreFailure(): void {
  // A phone without a vibration motor must not break the action that asked for feedback.
}

/** Medium impact: a cigarette was logged. */
export function triggerSmokeLoggedHaptic(): void {
  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(ignoreFailure);
}

/** Heavy double "success" pattern: a craving was crushed. */
export function triggerCravingCrushedHaptic(): void {
  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(ignoreFailure);
}

/** Light tick: a chip or toggle was selected. */
export function triggerChipSelectHaptic(): void {
  Haptics.selectionAsync().catch(ignoreFailure);
}

// ---------------------------------------------------------------------------
// 2. Interactive lock-screen notification
// ---------------------------------------------------------------------------

/** Ids of the two buttons on the tracker notification. */
export const NOTIFICATION_ACTIONS = {
  logSmoke: 'LOG_SMOKE_DEFAULT',
  crushCraving: 'CRUSH_CRAVING',
} as const;

const SMOKE_CATEGORY_ID = 'SMOKE_ACTIONS';
const TRACKER_CHANNEL_ID = 'tracker';
const ALERT_CHANNEL_ID = 'danger-window';
const TRACKER_NOTIFICATION_ID = 'tracker-persistent';
const DANGER_ALERT_NOTIFICATION_ID = 'danger-window-alert';
const NOTIFICATION_ACTION_TASK = 'notification-action-task';
/** The same tap can arrive through the listener and the background task. */
const DUPLICATE_TAP_WINDOW_MS = 1000;

export interface NotificationActionHandlers {
  onLogSmoke: () => void;
  onCrushCraving: () => void;
}

let actionHandlers: NotificationActionHandlers | null = null;
let lastAction = { id: '', atMs: 0 };

/** Tells this service what the two notification buttons should do. */
export function setNotificationActionHandlers(handlers: NotificationActionHandlers): void {
  actionHandlers = handlers;
}

function dispatchNotificationAction(actionIdentifier: string): void {
  const nowMs = Date.now();
  if (lastAction.id === actionIdentifier && nowMs - lastAction.atMs < DUPLICATE_TAP_WINDOW_MS) {
    return;
  }
  if (actionIdentifier === NOTIFICATION_ACTIONS.logSmoke) {
    lastAction = { id: actionIdentifier, atMs: nowMs };
    actionHandlers?.onLogSmoke();
  } else if (actionIdentifier === NOTIFICATION_ACTIONS.crushCraving) {
    lastAction = { id: actionIdentifier, atMs: nowMs };
    actionHandlers?.onCrushCraving();
  }
}

let isActionTaskDefined = false;

/**
 * Defines the background task that receives button taps while the app is not
 * on screen. Must run when the JavaScript bundle starts (it is called from
 * `index.ts`), not inside a component.
 */
export function defineNotificationActionTask(): void {
  if (isActionTaskDefined) {
    return;
  }
  isActionTaskDefined = true;
  TaskManager.defineTask(NOTIFICATION_ACTION_TASK, async ({ data, error }) => {
    if (error || typeof data !== 'object' || data === null) {
      return;
    }
    const actionIdentifier = (data as { actionIdentifier?: unknown }).actionIdentifier;
    if (typeof actionIdentifier === 'string') {
      dispatchNotificationAction(actionIdentifier);
    }
  });
}

/**
 * Sets up channels, the two-button category and the permission.
 * Returns whether notifications are allowed.
 */
export async function initNotifications(): Promise<boolean> {
  Notifications.setNotificationHandler({
    handleNotification: async (notification) => {
      const isTracker = notification.request.identifier === TRACKER_NOTIFICATION_ID;
      return {
        // The tracker is updated silently; only the danger alert may pop up over the app.
        shouldShowBanner: !isTracker,
        shouldShowList: true,
        shouldPlaySound: false,
        shouldSetBadge: false,
      };
    },
  });

  await Notifications.setNotificationChannelAsync(TRACKER_CHANNEL_ID, {
    name: 'Smoke tracker',
    description: 'The always-there notification with the +1 Smoke and Craving Crushed buttons.',
    importance: Notifications.AndroidImportance.DEFAULT,
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
    sound: null,
    enableVibrate: false,
    showBadge: false,
  });
  await Notifications.setNotificationChannelAsync(ALERT_CHANNEL_ID, {
    name: 'Danger window alert',
    description: 'A heads-up shortly before the hours in which you smoke most.',
    importance: Notifications.AndroidImportance.HIGH,
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
    vibrationPattern: [0, 250, 150, 250],
  });
  await Notifications.setNotificationCategoryAsync(SMOKE_CATEGORY_ID, [
    {
      identifier: NOTIFICATION_ACTIONS.logSmoke,
      buttonTitle: '+1 Smoke',
      options: { opensAppToForeground: false },
    },
    {
      identifier: NOTIFICATION_ACTIONS.crushCraving,
      buttonTitle: 'Craving Crushed',
      options: { opensAppToForeground: false },
    },
  ]);

  let permission = await Notifications.getPermissionsAsync();
  if (!permission.granted && permission.canAskAgain) {
    permission = await Notifications.requestPermissionsAsync();
  }

  try {
    defineNotificationActionTask();
    await Notifications.registerTaskAsync(NOTIFICATION_ACTION_TASK);
  } catch {
    // Without the background task the buttons still work while the app is alive.
  }
  return permission.granted;
}

/**
 * Listens for button taps while the app is running (on screen or in the
 * background). Returns a function that stops listening.
 */
export function addNotificationActionListener(): () => void {
  const subscription = Notifications.addNotificationResponseReceivedListener((response) => {
    dispatchNotificationAction(response.actionIdentifier);
  });
  return () => subscription.remove();
}

let lastTrackerText = '';

/**
 * Shows or updates the tracker notification. It is marked ongoing, but
 * Android 14 and later still let the user swipe it away, so call this again
 * whenever the app comes to the front.
 */
export async function showTrackerNotification(text: NotificationText, force = false): Promise<void> {
  const signature = `${text.title}\n${text.body}`;
  if (!force && signature === lastTrackerText) {
    return;
  }
  lastTrackerText = signature;
  await Notifications.scheduleNotificationAsync({
    identifier: TRACKER_NOTIFICATION_ID,
    content: {
      title: text.title,
      body: text.body,
      categoryIdentifier: SMOKE_CATEGORY_ID,
      sticky: true,
      autoDismiss: false,
      color: '#FF5500',
      data: { kind: 'tracker' },
    },
    trigger: { channelId: TRACKER_CHANNEL_ID },
  });
}

let lastAlertSignature = '';

/**
 * Schedules the daily heads-up 10 minutes before the peak danger window, with
 * the current wait target in its text. A notification's text is fixed when it
 * is scheduled, so call this again whenever the window or the target changes.
 * Passing no window cancels the alert.
 */
export async function scheduleDangerWindowAlert(peakDangerWindow: string | null | undefined, targetGapMins: number): Promise<void> {
  const plan = buildDangerAlertPlan(peakDangerWindow, targetGapMins);
  const signature = plan ? `${plan.hour}:${plan.minute}|${plan.title}|${plan.body}` : 'none';
  if (signature === lastAlertSignature) {
    return;
  }
  lastAlertSignature = signature;
  await Notifications.cancelScheduledNotificationAsync(DANGER_ALERT_NOTIFICATION_ID).catch(ignoreFailure);
  if (!plan) {
    return;
  }
  await Notifications.scheduleNotificationAsync({
    identifier: DANGER_ALERT_NOTIFICATION_ID,
    content: {
      title: plan.title,
      body: plan.body,
      color: '#FF2A55',
      data: { kind: 'danger-alert' },
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DAILY,
      hour: plan.hour,
      minute: plan.minute,
      channelId: ALERT_CHANNEL_ID,
    },
  });
}

// ---------------------------------------------------------------------------
// 3. Speech-to-text
// ---------------------------------------------------------------------------

export interface SpeechCallbacks {
  /** Called with the settled text and the current guess whenever either changes. */
  onTranscript: (transcript: TranscriptState) => void;
  /** Called once when listening cannot continue (no permission, no speech service, no network). */
  onError: (message: string) => void;
}

export interface SpeechSession {
  /** Stops listening and resolves with everything that was said. */
  stop: () => Promise<string>;
  /** Stops listening and throws the transcript away. */
  cancel: () => void;
}

const RESTART_DELAY_MS = 250;
const STOP_TIMEOUT_MS = 1500;
/** Errors that only mean "nobody is talking right now". Listening continues. */
const QUIET_ERRORS = ['no-speech', 'speech-timeout', 'aborted'];

/** Whether this phone has a speech recognition service at all. */
export function isSpeechRecognitionAvailable(): boolean {
  try {
    return ExpoSpeechRecognitionModule.isRecognitionAvailable();
  } catch {
    return false;
  }
}

/**
 * Starts listening. Android's recogniser stops by itself after a few seconds
 * of silence; this wrapper restarts it and stitches the pieces together, so a
 * long brain dump with thinking pauses comes through in one transcript.
 * Rejects when the microphone permission is denied.
 */
export async function startSpeechRecognition(
  callbacks: SpeechCallbacks,
  language: string = APP_CONFIG.speech.language,
): Promise<SpeechSession> {
  const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
  if (!permission.granted) {
    throw new Error('Microphone permission was not granted.');
  }

  const options = { lang: language, interimResults: true, continuous: true, maxAlternatives: 1 };
  let transcript: TranscriptState = EMPTY_TRANSCRIPT;
  let wantsToListen = true;
  let isRecognizerRunning = false;
  let isClosed = false;
  let restartTimer: ReturnType<typeof setTimeout> | null = null;
  let resolveStop: ((text: string) => void) | null = null;

  const startRecognizer = () => {
    isRecognizerRunning = true;
    ExpoSpeechRecognitionModule.start(options);
  };

  const close = () => {
    if (isClosed) {
      return;
    }
    isClosed = true;
    if (restartTimer) {
      clearTimeout(restartTimer);
    }
    for (const subscription of subscriptions) {
      subscription.remove();
    }
    if (resolveStop) {
      resolveStop(getFullTranscript(transcript));
      resolveStop = null;
    }
  };

  const subscriptions = [
    ExpoSpeechRecognitionModule.addListener('result', (event) => {
      const text = event.results[0]?.transcript ?? '';
      transcript = applySpeechResult(transcript, text, event.isFinal);
      callbacks.onTranscript(transcript);
    }),
    ExpoSpeechRecognitionModule.addListener('error', (event) => {
      if (QUIET_ERRORS.includes(event.error) || !wantsToListen) {
        return;
      }
      wantsToListen = false;
      callbacks.onError(event.message || `Speech recognition stopped (${event.error}).`);
    }),
    ExpoSpeechRecognitionModule.addListener('end', () => {
      isRecognizerRunning = false;
      transcript = commitInterim(transcript);
      callbacks.onTranscript(transcript);
      if (wantsToListen) {
        restartTimer = setTimeout(() => {
          if (wantsToListen) {
            startRecognizer();
          }
        }, RESTART_DELAY_MS);
      } else {
        close();
      }
    }),
  ];

  startRecognizer();

  return {
    stop: () =>
      new Promise<string>((resolve) => {
        if (isClosed) {
          resolve(getFullTranscript(transcript));
          return;
        }
        wantsToListen = false;
        resolveStop = resolve;
        if (restartTimer) {
          clearTimeout(restartTimer);
        }
        if (!isRecognizerRunning) {
          close();
          return;
        }
        ExpoSpeechRecognitionModule.stop();
        // The recogniser normally answers with "end"; do not wait for it forever.
        setTimeout(close, STOP_TIMEOUT_MS);
      }),
    cancel: () => {
      wantsToListen = false;
      transcript = EMPTY_TRANSCRIPT;
      ExpoSpeechRecognitionModule.abort();
      close();
    },
  };
}
