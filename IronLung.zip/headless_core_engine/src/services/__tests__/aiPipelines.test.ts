import { createMemoryKv } from '../../storage/kv';
import { createAppStore } from '../../store/createAppStore';
import type { BrainDumpDoc } from '../../types/schema';
import { createAiPipelines } from '../aiPipelines';
import { BRAIN_DUMP_SYSTEM_PROMPT, REAL_TALK_SYSTEM_PROMPT, SMOKE_COACH_SYSTEM_PROMPT } from '../aiPrompts';
import { LlmError } from '../llmClient';
import type { LlmJsonRequest } from '../llmClient';

// Dates are built with the local-time constructor, so the tests give the same
// result in every time zone.

/** A moment on a day of November 2026, on the phone's clock. */
function november(day: number, hour: number, minute = 0): Date {
  return new Date(2026, 10, day, hour, minute);
}

type Answer = unknown | Error | Promise<unknown>;

/** A real in-memory store wired to a fake AI that gives the queued answers in order. */
function setup(options: { apiKey?: string | null; answers?: Answer[]; now?: Date } = {}) {
  const store = createAppStore(createMemoryKv()).useStore;
  const requests: LlmJsonRequest[] = [];
  const loadingFlagDuringRequests: boolean[] = [];
  const answers = [...(options.answers ?? [])];
  let now = options.now ?? november(19, 14, 52);
  const pipelines = createAiPipelines({
    store,
    getApiKey: async () => (options.apiKey === undefined ? 'AIza-test-key' : options.apiKey),
    requestJson: async (request) => {
      requests.push(request);
      loadingFlagDuringRequests.push(store.getState().isCoachLoading);
      const answer = answers.shift();
      if (answer instanceof Error) {
        throw answer;
      }
      return answer;
    },
    now: () => now,
  });
  return {
    store,
    pipelines,
    requests,
    loadingFlagDuringRequests,
    setNow: (date: Date) => {
      now = date;
    },
  };
}

const COACH_ANSWER = {
  reply: 'Your 11:40 dump: "client deck is killing me." Same trigger.',
  suggested_target_gap_mins: 135,
  new_memory_note_to_save: 'Smokes right after review meetings.',
};

const DUMP_ANSWER = {
  headline: 'Client deck deadline is crushing my focus',
  mood_detected: 'Stressed',
  category: 'Work',
  action_items: [{ id: 'a', task: 'Send revised client deck', done: true, due_time: '15:00' }],
};

const BRIEFING_ANSWER = {
  smoke_trend_summary: 'Three smokes in two recorded days.',
  brain_habit_correlation: 'Not enough data yet.',
  next_week_micro_goal: 'Zero smokes before **11:00 AM**.',
  micro_goal_reward: '**₹60 saved**.',
};

function finishedDump(id: string, logicalDate: string): BrainDumpDoc {
  return {
    id,
    logical_date: logicalDate,
    created_at: `${logicalDate}T10:00:00.000+05:30`,
    raw_transcript: 'transcript',
    ai_processed: {
      headline: 'Headline',
      mood_detected: 'Stressed',
      category: 'Work',
      action_items: [{ id: 'open-task', task: 'Send revised client deck', done: false }],
    },
    ai_status: 'done',
  };
}

describe('triggerSmokeCoachAI', () => {
  it('adds the reply to the chat, moves the wait target and saves the memory note', async () => {
    const { store, pipelines, requests } = setup({ answers: [COACH_ANSWER] });
    const entry = store.getState().logSmoke({ trigger: 'Work Stress', now: november(19, 14, 52) });

    const outcome = await pipelines.triggerSmokeCoachAI({ type: 'SMOKE_LOGGED', entry });

    const today = store.getState().dailyLogs['2026-11-19'];
    expect(outcome).toEqual({ ok: true, reply: 'Your 11:40 dump: "client deck is killing me." Same trigger.' });
    expect(today?.chat_buffer.map((m) => [m.role, m.text])).toEqual([
      ['assistant', 'Your 11:40 dump: "client deck is killing me." Same trigger.'],
    ]);
    expect(today?.active_target_gap_mins).toBe(135);
    expect(store.getState().rollingMemory?.ai_memory_notes).toEqual(['Smokes right after review meetings.']);
    expect(requests[0]?.system).toBe(SMOKE_COACH_SYSTEM_PROMPT);
    expect(requests[0]?.user).toMatch('"event":{"type":"SMOKE_LOGGED","trigger":"Work Stress"');
  });

  it('shows the user message at once even when no key is set', async () => {
    const { store, pipelines, requests } = setup({ apiKey: null });

    const outcome = await pipelines.triggerSmokeCoachAI({ type: 'USER_CHAT_MESSAGE', text: ' Holding. Deck review at 3. ' });

    expect(outcome).toEqual({ ok: false, reason: 'no_key', message: 'No AI key yet. Add it under REAL TALK > QUICK SETTINGS.' });
    expect(store.getState().dailyLogs['2026-11-19']?.chat_buffer.map((m) => [m.role, m.text])).toEqual([
      ['user', 'Holding. Deck review at 3.'],
    ]);
    expect(requests).toHaveLength(0);
  });

  it('sends the chat message as part of the context', async () => {
    const { pipelines, requests } = setup({ answers: [COACH_ANSWER] });

    await pipelines.triggerSmokeCoachAI({ type: 'USER_CHAT_MESSAGE', text: 'Can I push the gap?' });

    expect(requests[0]?.user).toMatch('"recent_chat":[{"role":"user","text":"Can I push the gap?"}]');
  });

  it('reports a failed request and leaves the data alone', async () => {
    const { store, pipelines } = setup({ answers: [new LlmError('auth', 'The AI API key was rejected.')] });

    const outcome = await pipelines.triggerSmokeCoachAI({ type: 'CRAVING_CRUSHED' });

    expect(outcome).toEqual({ ok: false, reason: 'failed', message: 'The AI API key was rejected.' });
    expect(store.getState().dailyLogs['2026-11-19']?.chat_buffer).toEqual([]);
    expect(store.getState().dailyLogs['2026-11-19']?.active_target_gap_mins).toBe(120);
  });

  it('reports an answer in the wrong format', async () => {
    const { pipelines } = setup({ answers: [{ reply: '' }] });

    const outcome = await pipelines.triggerSmokeCoachAI({ type: 'CRAVING_CRUSHED' });

    expect(outcome).toEqual({ ok: false, reason: 'failed', message: 'The AI answered in the wrong format. Try again.' });
  });

  it('ignores an empty chat message', async () => {
    const { store, pipelines } = setup();

    const outcome = await pipelines.triggerSmokeCoachAI({ type: 'USER_CHAT_MESSAGE', text: '   ' });

    expect(outcome.ok).toBe(false);
    expect(store.getState().dailyLogs).toEqual({});
  });

  it('shows the loading state only while the AI is working', async () => {
    const { store, pipelines, loadingFlagDuringRequests } = setup({ answers: [COACH_ANSWER] });

    await pipelines.triggerSmokeCoachAI({ type: 'CRAVING_CRUSHED' });

    expect(loadingFlagDuringRequests).toEqual([true]);
    expect(store.getState().isCoachLoading).toBe(false);
  });

  it('answers events in the order they happened', async () => {
    let releaseFirst: (value: unknown) => void = () => {};
    const slowFirstAnswer = new Promise<unknown>((resolve) => {
      releaseFirst = resolve;
    });
    const { store, pipelines, requests } = setup({
      answers: [slowFirstAnswer, { ...COACH_ANSWER, reply: 'Second reply.' }],
    });

    const first = pipelines.triggerSmokeCoachAI({ type: 'CRAVING_CRUSHED' });
    const second = pipelines.triggerSmokeCoachAI({ type: 'CRAVING_CRUSHED' });
    await Promise.resolve();
    await Promise.resolve();
    const requestsWhileFirstIsPending = requests.length;
    releaseFirst({ ...COACH_ANSWER, reply: 'First reply.' });
    await Promise.all([first, second]);

    expect(requestsWhileFirstIsPending).toBe(1);
    expect(store.getState().dailyLogs['2026-11-19']?.chat_buffer.map((m) => m.text)).toEqual([
      'First reply.',
      'Second reply.',
    ]);
  });
});

describe('processBrainDumpAI', () => {
  it('saves the dump with the AI result and tells the coach about the headline', async () => {
    const { store, pipelines, requests } = setup({ answers: [DUMP_ANSWER], now: november(19, 11, 40) });

    const dump = await pipelines.processBrainDumpAI('  Need to send the revised deck before the 3 pm review.  ');

    expect(dump?.ai_status).toBe('done');
    expect(dump?.logical_date).toBe('2026-11-19');
    expect(dump?.raw_transcript).toBe('Need to send the revised deck before the 3 pm review.');
    expect(dump?.ai_processed.headline).toBe('Client deck deadline is crushing my focus');
    expect(dump?.ai_processed.mood_detected).toBe('Stressed');
    expect(dump?.ai_processed.action_items.map((item) => [item.task, item.done, item.due_time])).toEqual([
      ['Send revised client deck', false, '15:00'],
    ]);
    expect(dump?.ai_processed.action_items[0]?.id).toMatch(/^task_/);
    expect(store.getState().brainDumps[dump?.id ?? '']).toEqual(dump);
    expect(store.getState().dailyLogs['2026-11-19']?.todays_brain_dump_headlines).toEqual([
      'Client deck deadline is crushing my focus',
    ]);
    expect(store.getState().processingDumpCount).toBe(0);
    expect(requests[0]?.system).toBe(BRAIN_DUMP_SYSTEM_PROMPT);
    expect(requests[0]?.user).toBe('CURRENT TIME: 11:40\nTRANSCRIPT:\nNeed to send the revised deck before the 3 pm review.');
  });

  it('keeps the dump as pending when the AI cannot be reached, then finishes it on retry', async () => {
    const { store, pipelines } = setup({
      answers: [new LlmError('network', 'Could not reach the AI.'), DUMP_ANSWER],
      now: november(19, 11, 40),
    });

    const dump = await pipelines.processBrainDumpAI('Need to send the revised deck before the 3 pm review.');
    const headlinesWhilePending = store.getState().dailyLogs['2026-11-19']?.todays_brain_dump_headlines;
    const processed = await pipelines.retryPendingBrainDumps();

    expect(dump?.ai_status).toBe('pending');
    expect(dump?.ai_processed.headline).toBe('Need to send the revised deck before the');
    expect(headlinesWhilePending).toEqual([]);
    expect(processed).toBe(1);
    expect(store.getState().brainDumps[dump?.id ?? '']?.ai_status).toBe('done');
    expect(store.getState().processingDumpCount).toBe(0);
  });

  it('saves the dump even without an API key', async () => {
    const { store, pipelines, requests } = setup({ apiKey: null });

    const dump = await pipelines.processBrainDumpAI('Call Dad about the weekend.');

    expect(dump?.ai_status).toBe('pending');
    expect(Object.keys(store.getState().brainDumps)).toEqual([dump?.id ?? '']);
    expect(requests).toHaveLength(0);
  });

  it('ignores an empty transcript', async () => {
    const { store, pipelines } = setup();

    const dump = await pipelines.processBrainDumpAI('   ');

    expect(dump).toBeNull();
    expect(store.getState().brainDumps).toEqual({});
  });
});

describe('generateRealTalkAI', () => {
  it('says so when there is no finished day to brief on', async () => {
    const { pipelines, requests } = setup({ answers: [BRIEFING_ANSWER], now: november(24, 10) });

    const outcome = await pipelines.generateRealTalkAI();

    expect(outcome).toEqual({ ok: false, reason: 'no_data', message: 'Nothing to brief on yet. Log at least one full day first.' });
    expect(requests).toHaveLength(0);
  });

  it('saves a briefing with the numbers from the app and the words from the AI', async () => {
    const { store, pipelines, requests } = setup({ answers: [BRIEFING_ANSWER], now: november(24, 10) });
    store.getState().logSmoke({ now: november(17, 12) });
    store.getState().logSmoke({ now: november(18, 12) });
    store.getState().logSmoke({ now: november(18, 15) });
    store.getState().addBrainDump(finishedDump('d1', '2026-11-18'));

    const outcome = await pipelines.generateRealTalkAI();

    const saved = store.getState().briefings['2026-W48'];
    expect(outcome.ok).toBe(true);
    expect(saved?.week_id).toBe('2026-W48');
    expect(saved?.period_start).toBe('2026-11-17');
    expect(saved?.period_end).toBe('2026-11-23');
    expect(saved?.smoke_trend_summary).toBe('Three smokes in two recorded days.');
    expect(saved?.next_week_micro_goal).toBe('Zero smokes before **11:00 AM**.');
    expect(saved?.micro_goal_reward).toBe('**₹60 saved**.');
    expect(saved?.stats.smokes_this_week).toBe(3);
    expect(saved?.stats.days_recorded).toBe(2);
    expect(saved?.stats.stressed_dates).toEqual(['2026-11-18']);
    expect(saved?.carryover_tasks).toEqual([
      { id: 'open-task', task: 'Send revised client deck', source_date: '2026-11-18', dump_id: 'd1' },
    ]);
    expect(store.getState().isGeneratingBriefing).toBe(false);
    expect(requests[0]?.system).toBe(REAL_TALK_SYSTEM_PROMPT);
    expect(requests[0]?.user).toMatch('"smokes_this_week":3');
  });

  it('asks for a key when none is set', async () => {
    const { store, pipelines } = setup({ apiKey: null, now: november(24, 10) });
    store.getState().logSmoke({ now: november(18, 12) });

    const outcome = await pipelines.generateRealTalkAI();

    expect(outcome).toEqual({ ok: false, reason: 'no_key', message: 'No AI key yet. Add it under REAL TALK > QUICK SETTINGS.' });
    expect(store.getState().briefings).toEqual({});
  });

  it('reports a failed request and saves nothing', async () => {
    const { store, pipelines } = setup({
      answers: [new LlmError('server', 'The AI service had a problem (503).')],
      now: november(24, 10),
    });
    store.getState().logSmoke({ now: november(18, 12) });

    const outcome = await pipelines.generateRealTalkAI();

    expect(outcome).toEqual({ ok: false, reason: 'failed', message: 'The AI service had a problem (503).' });
    expect(store.getState().briefings).toEqual({});
    expect(store.getState().isGeneratingBriefing).toBe(false);
  });
});
