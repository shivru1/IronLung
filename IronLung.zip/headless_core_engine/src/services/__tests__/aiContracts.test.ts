import {
  AiContractError,
  buildPlaceholderBrainDumpResult,
  extractJson,
  parseBrainDumpResult,
  parseRealTalkTexts,
  parseSmokeCoachResult,
  SMOKE_COACH_SCHEMA,
  toGeminiSchema,
  toStandardSchema,
} from '../aiContracts';
import type { JsonSchema } from '../aiContracts';

/** Hands out `task_1`, `task_2`, ... so tests can see which ids were generated. */
function sequentialIds(): () => string {
  let next = 0;
  return () => {
    next += 1;
    return `task_${next}`;
  };
}

describe('toGeminiSchema', () => {
  it('writes upper-case types, required keys and nullable flags', () => {
    expect(toGeminiSchema(SMOKE_COACH_SCHEMA)).toEqual({
      type: 'OBJECT',
      properties: {
        reply: { type: 'STRING', description: 'What the coach says. 2-3 short sentences.' },
        suggested_target_gap_mins: {
          type: 'INTEGER',
          description: 'Minutes to wait before the next cigarette, between 15 and 480.',
        },
        new_memory_note_to_save: {
          type: 'STRING',
          nullable: true,
          description: 'A lasting pattern learned about the user this turn, or null.',
        },
      },
      required: ['reply', 'suggested_target_gap_mins', 'new_memory_note_to_save'],
      propertyOrdering: ['reply', 'suggested_target_gap_mins', 'new_memory_note_to_save'],
    });
  });
});

describe('toStandardSchema', () => {
  it('forbids extra keys, requires every key and writes nullable as a type list', () => {
    const schema: JsonSchema = {
      type: 'object',
      properties: {
        mood: { type: 'string', enum: ['Calm', 'Stressed'] },
        note: { type: 'string', nullable: true },
        items: { type: 'array', items: { type: 'object', properties: { done: { type: 'boolean' } } } },
      },
    };

    expect(toStandardSchema(schema)).toEqual({
      type: 'object',
      properties: {
        mood: { type: 'string', enum: ['Calm', 'Stressed'] },
        note: { type: ['string', 'null'] },
        items: {
          type: 'array',
          items: {
            type: 'object',
            properties: { done: { type: 'boolean' } },
            required: ['done'],
            additionalProperties: false,
          },
        },
      },
      required: ['mood', 'note', 'items'],
      additionalProperties: false,
    });
  });
});

describe('extractJson', () => {
  it('reads plain JSON', () => {
    expect(extractJson('{"reply":"ok"}')).toEqual({ reply: 'ok' });
  });

  it('reads JSON inside a code fence', () => {
    expect(extractJson('```json\n{"reply":"ok"}\n```')).toEqual({ reply: 'ok' });
  });

  it('reads JSON with words around it', () => {
    expect(extractJson('Here you go: {"reply":"ok"} Done.')).toEqual({ reply: 'ok' });
  });

  it('rejects text without JSON', () => {
    expect(() => extractJson('I cannot help with that.')).toThrow(AiContractError);
  });
});

describe('parseSmokeCoachResult', () => {
  it('accepts a complete answer', () => {
    const result = parseSmokeCoachResult({
      reply: ' Same trigger as this morning. ',
      suggested_target_gap_mins: 150,
      new_memory_note_to_save: 'Smokes right after the 3 pm review.',
    });

    expect(result).toEqual({
      reply: 'Same trigger as this morning.',
      suggested_target_gap_mins: 150,
      new_memory_note_to_save: 'Smokes right after the 3 pm review.',
    });
  });

  it('rounds the wait to whole minutes', () => {
    const result = parseSmokeCoachResult({ reply: 'ok', suggested_target_gap_mins: 149.6, new_memory_note_to_save: null });

    expect(result.suggested_target_gap_mins).toBe(150);
  });

  it('gives no wait when the model sent none', () => {
    const result = parseSmokeCoachResult({ reply: 'ok', suggested_target_gap_mins: 'soon', new_memory_note_to_save: null });

    expect(result.suggested_target_gap_mins).toBeNull();
  });

  it('treats the text "null" as no memory note', () => {
    const result = parseSmokeCoachResult({ reply: 'ok', suggested_target_gap_mins: 120, new_memory_note_to_save: 'null' });

    expect(result.new_memory_note_to_save).toBeNull();
  });

  it('rejects an answer without a reply', () => {
    expect(() => parseSmokeCoachResult({ reply: '  ', suggested_target_gap_mins: 120 })).toThrow(AiContractError);
  });

  it('rejects an answer that is not an object', () => {
    expect(() => parseSmokeCoachResult(['reply'])).toThrow(AiContractError);
  });
});

describe('parseBrainDumpResult', () => {
  it('tidies a complete answer and makes its own task ids', () => {
    const result = parseBrainDumpResult(
      {
        headline: 'Client deck deadline is crushing my focus',
        mood_detected: 'stressed',
        category: 'Work',
        action_items: [
          { id: 'x', task: 'Send revised client deck', done: true, due_time: '15:00' },
          { id: 'y', task: 'Ask Priya for final numbers', done: false, due_time: null },
        ],
      },
      sequentialIds(),
    );

    expect(result).toEqual({
      headline: 'Client deck deadline is crushing my focus',
      mood_detected: 'Stressed',
      category: 'Work',
      action_items: [
        { id: 'task_1', task: 'Send revised client deck', done: false, due_time: '15:00' },
        { id: 'task_2', task: 'Ask Priya for final numbers', done: false, due_time: null },
      ],
    });
  });

  it('cuts the headline to eight words', () => {
    const result = parseBrainDumpResult(
      { headline: 'one two three four five six seven eight nine ten', mood_detected: 'Calm', category: 'Idea', action_items: [] },
      sequentialIds(),
    );

    expect(result.headline).toBe('one two three four five six seven eight');
  });

  it('pads a deadline to HH:mm and drops one that is not a clock time', () => {
    const result = parseBrainDumpResult(
      {
        headline: 'Headline',
        mood_detected: 'Tired',
        category: 'Personal',
        action_items: [
          { task: 'Call Dad', due_time: '9:05' },
          { task: 'Book dentist', due_time: 'tomorrow' },
        ],
      },
      sequentialIds(),
    );

    expect(result.action_items.map((item) => item.due_time)).toEqual(['09:05', null]);
  });

  it('skips tasks without text and tolerates a missing list', () => {
    const withEmptyTask = parseBrainDumpResult(
      { headline: 'Headline', mood_detected: 'Calm', category: 'Work', action_items: [{ task: '  ' }, 'junk', { task: 'Real task' }] },
      sequentialIds(),
    );
    const withoutList = parseBrainDumpResult({ headline: 'Headline', mood_detected: 'Calm', category: 'Work' }, sequentialIds());

    expect(withEmptyTask.action_items.map((item) => item.task)).toEqual(['Real task']);
    expect(withoutList.action_items).toEqual([]);
  });

  it('rejects a mood that is not on the list', () => {
    expect(() =>
      parseBrainDumpResult({ headline: 'Headline', mood_detected: 'Angry', category: 'Work', action_items: [] }, sequentialIds()),
    ).toThrow(AiContractError);
  });

  it('rejects a category that is not on the list', () => {
    expect(() =>
      parseBrainDumpResult({ headline: 'Headline', mood_detected: 'Calm', category: 'Health', action_items: [] }, sequentialIds()),
    ).toThrow(AiContractError);
  });
});

describe('buildPlaceholderBrainDumpResult', () => {
  it('uses the first eight words as the headline and has no tasks', () => {
    expect(buildPlaceholderBrainDumpResult('Need to send the revised deck before the 3 pm review')).toEqual({
      headline: 'Need to send the revised deck before the',
      mood_detected: 'Calm',
      category: 'Personal',
      action_items: [],
    });
  });
});

describe('parseRealTalkTexts', () => {
  it('accepts a complete answer', () => {
    const texts = {
      smoke_trend_summary: 'Down from 44.',
      brain_habit_correlation: 'Stress is your tell.',
      next_week_micro_goal: 'Zero smokes before **11:00 AM**.',
      micro_goal_reward: '**₹300 saved**.',
    };

    expect(parseRealTalkTexts(texts)).toEqual(texts);
  });

  it('allows a missing reward', () => {
    const result = parseRealTalkTexts({
      smoke_trend_summary: 'Down from 44.',
      brain_habit_correlation: 'Stress is your tell.',
      next_week_micro_goal: 'Zero smokes before 11.',
    });

    expect(result.micro_goal_reward).toBe('');
  });

  it('rejects an answer with an empty section', () => {
    expect(() =>
      parseRealTalkTexts({ smoke_trend_summary: '', brain_habit_correlation: 'x', next_week_micro_goal: 'y' }),
    ).toThrow(AiContractError);
  });
});
