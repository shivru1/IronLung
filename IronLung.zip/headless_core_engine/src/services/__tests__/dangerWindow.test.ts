import {
  formatDangerWindow,
  getAlertTime,
  getWindowHours,
  getWindowSharePercent,
  isInDangerWindow,
  minutesUntilWindowCloses,
  minutesUntilWindowOpens,
  parseDangerWindow,
} from '../dangerWindow';

const AFTERNOON = { startHour: 15, endHour: 18 };
const OVERNIGHT = { startHour: 23, endHour: 2 };

/** A moment on 19 November 2026, on the phone's clock. */
function clock(hour: number, minute = 0): Date {
  return new Date(2026, 10, 19, hour, minute);
}

/** A 24-slot histogram that is zero everywhere except the given hours. */
function hourlyCounts(countsByHour: Record<number, number>): number[] {
  const counts = new Array<number>(24).fill(0);
  for (const [hour, count] of Object.entries(countsByHour)) {
    counts[Number(hour)] = count;
  }
  return counts;
}

describe('parseDangerWindow', () => {
  it('reads the text the rollup stores', () => {
    expect(parseDangerWindow('15:00 - 18:00')).toEqual({ startHour: 15, endHour: 18 });
  });

  it('reads a window that crosses midnight', () => {
    expect(parseDangerWindow('23:00 - 02:00')).toEqual({ startHour: 23, endHour: 2 });
  });

  it('accepts an en dash without spaces', () => {
    expect(parseDangerWindow('09:00–12:00')).toEqual({ startHour: 9, endHour: 12 });
  });

  it('returns null when there is no window', () => {
    expect(parseDangerWindow(null)).toBeNull();
  });

  it('returns null for text in another shape', () => {
    expect(parseDangerWindow('afternoon')).toBeNull();
  });

  it('returns null for an hour that does not exist', () => {
    expect(parseDangerWindow('24:00 - 03:00')).toBeNull();
  });
});

describe('getWindowHours', () => {
  it('lists the hours of a daytime window', () => {
    expect(getWindowHours(AFTERNOON)).toEqual([15, 16, 17]);
  });

  it('wraps around midnight', () => {
    expect(getWindowHours(OVERNIGHT)).toEqual([23, 0, 1]);
  });
});

describe('isInDangerWindow', () => {
  it('is true at the first minute of the window', () => {
    expect(isInDangerWindow(AFTERNOON, clock(15, 0))).toBe(true);
  });

  it('is true in the last minute of the window', () => {
    expect(isInDangerWindow(AFTERNOON, clock(17, 59))).toBe(true);
  });

  it('is false at the hour the window ends', () => {
    expect(isInDangerWindow(AFTERNOON, clock(18, 0))).toBe(false);
  });

  it('is true after midnight inside an overnight window', () => {
    expect(isInDangerWindow(OVERNIGHT, clock(1, 30))).toBe(true);
  });
});

describe('minutesUntilWindowOpens', () => {
  it('counts down to the start', () => {
    expect(minutesUntilWindowOpens(AFTERNOON, clock(14, 52))).toBe(8);
  });

  it('is zero while the window is open', () => {
    expect(minutesUntilWindowOpens(AFTERNOON, clock(16, 0))).toBe(0);
  });

  it('counts to tomorrow once the window has passed', () => {
    expect(minutesUntilWindowOpens(AFTERNOON, clock(19, 30))).toBe(1170);
  });
});

describe('minutesUntilWindowCloses', () => {
  it('counts down to the end while the window is open', () => {
    expect(minutesUntilWindowCloses(AFTERNOON, clock(16, 20))).toBe(100);
  });

  it('counts across midnight', () => {
    expect(minutesUntilWindowCloses(OVERNIGHT, clock(23, 30))).toBe(150);
  });

  it('is zero while the window is closed', () => {
    expect(minutesUntilWindowCloses(AFTERNOON, clock(10, 0))).toBe(0);
  });
});

describe('getAlertTime', () => {
  it('is ten minutes before the window opens', () => {
    expect(getAlertTime(AFTERNOON)).toEqual({ hour: 14, minute: 50 });
  });

  it('moves to the evening before for a window that opens at midnight', () => {
    expect(getAlertTime({ startHour: 0, endHour: 3 })).toEqual({ hour: 23, minute: 50 });
  });

  it('uses the given lead time', () => {
    expect(getAlertTime(AFTERNOON, 30)).toEqual({ hour: 14, minute: 30 });
  });
});

describe('formatDangerWindow', () => {
  it('writes the banner form', () => {
    expect(formatDangerWindow(AFTERNOON, 'spaced')).toBe('15:00 – 18:00');
  });

  it('writes the badge form', () => {
    expect(formatDangerWindow(AFTERNOON, 'tight')).toBe('15:00–18:00');
  });

  it('writes the axis form with leading zeros', () => {
    expect(formatDangerWindow({ startHour: 6, endHour: 9 }, 'hours')).toBe('06–09');
  });
});

describe('getWindowSharePercent', () => {
  it('returns null when nothing was smoked', () => {
    expect(getWindowSharePercent(hourlyCounts({}), AFTERNOON)).toBeNull();
  });

  it('gives the share of cigarettes inside the window', () => {
    const counts = hourlyCounts({ 9: 10, 15: 6, 16: 7, 17: 4, 21: 23 });

    expect(getWindowSharePercent(counts, AFTERNOON)).toBe(34);
  });

  it('counts both sides of midnight for an overnight window', () => {
    const counts = hourlyCounts({ 23: 2, 0: 1, 1: 1, 12: 4 });

    expect(getWindowSharePercent(counts, OVERNIGHT)).toBe(50);
  });
});
