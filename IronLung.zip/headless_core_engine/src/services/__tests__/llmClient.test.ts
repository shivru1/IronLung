import type { JsonSchema } from '../aiContracts';
import { buildProviderRequest, detectProvider, LlmError, orderModels, readProviderResponse, requestJson } from '../llmClient';
import type { FetchLike, LlmErrorKind, LlmJsonRequest } from '../llmClient';

const SCHEMA: JsonSchema = { type: 'object', properties: { reply: { type: 'string' } } };

const REQUEST: LlmJsonRequest = {
  system: 'You are terse.',
  user: 'Say ok.',
  schema: SCHEMA,
  schemaName: 'reply_schema',
  temperature: 0.5,
};

interface RecordedCall {
  url: string;
  body: unknown;
  headers: Record<string, string>;
}

/** A fake `fetch` that answers with the given responses in order and records every call. */
function fakeFetch(responses: Array<{ status: number; body: unknown } | 'network-error'>): {
  fetchImpl: FetchLike;
  calls: RecordedCall[];
} {
  const calls: RecordedCall[] = [];
  const fetchImpl: FetchLike = async (url, init) => {
    calls.push({ url, body: JSON.parse(init.body) as unknown, headers: init.headers });
    const response = responses[calls.length - 1];
    if (response === undefined || response === 'network-error') {
      throw new Error('offline');
    }
    return {
      ok: response.status >= 200 && response.status < 300,
      status: response.status,
      text: async () => (typeof response.body === 'string' ? response.body : JSON.stringify(response.body)),
    };
  };
  return { fetchImpl, calls };
}

function geminiAnswer(text: string): unknown {
  return { candidates: [{ content: { parts: [{ text }] } }] };
}

/** Runs the request and returns the kind of error it failed with, or `null` when it succeeded. */
async function failureKind(run: Promise<unknown>): Promise<LlmErrorKind | 'other' | null> {
  try {
    await run;
    return null;
  } catch (error) {
    return error instanceof LlmError ? error.kind : 'other';
  }
}

const NO_WAIT = async () => {};

describe('detectProvider', () => {
  it('recognises a Claude key', () => {
    expect(detectProvider('sk-ant-api03-abc')).toBe('anthropic');
  });

  it('recognises an OpenAI key', () => {
    expect(detectProvider('sk-proj-abc')).toBe('openai');
  });

  it('recognises a Gemini key', () => {
    expect(detectProvider('  AIzaSyAbc  ')).toBe('gemini');
  });

  it('falls back to Gemini for an unknown key shape', () => {
    expect(detectProvider('something-else')).toBe('gemini');
  });
});

describe('buildProviderRequest', () => {
  it('builds a Gemini request with a JSON response schema', () => {
    expect(buildProviderRequest('gemini', 'gemini-3.8-flash', 'AIzaKey', REQUEST)).toEqual({
      url: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': 'AIzaKey' },
      body: {
        systemInstruction: { parts: [{ text: 'You are terse.' }] },
        contents: [{ role: 'user', parts: [{ text: 'Say ok.' }] }],
        generationConfig: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: 'OBJECT',
            properties: { reply: { type: 'STRING' } },
            required: ['reply'],
            propertyOrdering: ['reply'],
          },
          temperature: 0.5,
        },
      },
    });
  });

  it('builds an OpenAI request with a strict JSON schema', () => {
    expect(buildProviderRequest('openai', 'gpt-4o-mini', 'sk-key', REQUEST)).toEqual({
      url: 'https://api.openai.com/v1/chat/completions',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer sk-key' },
      body: {
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are terse.' },
          { role: 'user', content: 'Say ok.' },
        ],
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'reply_schema',
            strict: true,
            schema: {
              type: 'object',
              properties: { reply: { type: 'string' } },
              required: ['reply'],
              additionalProperties: false,
            },
          },
        },
      },
    });
  });

  it('builds a Claude request that forces one tool', () => {
    expect(buildProviderRequest('anthropic', 'claude-haiku-4-5', 'sk-ant-key', REQUEST)).toEqual({
      url: 'https://api.anthropic.com/v1/messages',
      headers: { 'Content-Type': 'application/json', 'x-api-key': 'sk-ant-key', 'anthropic-version': '2023-06-01' },
      body: {
        model: 'claude-haiku-4-5',
        max_tokens: 1024,
        system: 'You are terse.',
        messages: [{ role: 'user', content: 'Say ok.' }],
        tools: [
          {
            name: 'reply_schema',
            description: 'Return the answer in exactly this structure.',
            input_schema: {
              type: 'object',
              properties: { reply: { type: 'string' } },
              required: ['reply'],
              additionalProperties: false,
            },
          },
        ],
        tool_choice: { type: 'tool', name: 'reply_schema' },
      },
    });
  });
});

describe('readProviderResponse', () => {
  it('reads a Gemini answer split over several parts', () => {
    const payload = { candidates: [{ content: { parts: [{ text: '{"reply":' }, { text: '"ok"}' }] } }] };

    expect(readProviderResponse('gemini', payload)).toEqual({ reply: 'ok' });
  });

  it('reports a blocked Gemini answer', () => {
    const payload = { promptFeedback: { blockReason: 'SAFETY' } };

    expect(() => readProviderResponse('gemini', payload)).toThrow('SAFETY');
  });

  it('reads an OpenAI answer', () => {
    const payload = { choices: [{ message: { content: '{"reply":"ok"}' } }] };

    expect(readProviderResponse('openai', payload)).toEqual({ reply: 'ok' });
  });

  it('reads the tool input of a Claude answer', () => {
    const payload = { content: [{ type: 'tool_use', name: 'reply_schema', input: { reply: 'ok' } }] };

    expect(readProviderResponse('anthropic', payload)).toEqual({ reply: 'ok' });
  });

  it('falls back to the text of a Claude answer', () => {
    const payload = { content: [{ type: 'text', text: '{"reply":"ok"}' }] };

    expect(readProviderResponse('anthropic', payload)).toEqual({ reply: 'ok' });
  });

  it('rejects an answer that is not JSON', () => {
    expect(() => readProviderResponse('openai', { choices: [{ message: { content: 'Sure!' } }] })).toThrow(LlmError);
  });
});

describe('requestJson', () => {
  it('fails right away without an API key', async () => {
    const { fetchImpl, calls } = fakeFetch([]);

    const kind = await failureKind(requestJson(REQUEST, { apiKey: '  ', fetchImpl }));

    expect(kind).toBe('no_key');
    expect(calls).toHaveLength(0);
  });

  it('returns the JSON the model answered with', async () => {
    const { fetchImpl, calls } = fakeFetch([{ status: 200, body: geminiAnswer('{"reply":"ok"}') }]);

    const answer = await requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl });

    expect(answer).toEqual({ reply: 'ok' });
    expect(calls).toHaveLength(1);
    expect(calls[0]?.url).toBe('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent');
  });

  it('picks the provider from the key', async () => {
    const { fetchImpl, calls } = fakeFetch([{ status: 200, body: { choices: [{ message: { content: '{"reply":"ok"}' } }] } }]);

    await requestJson(REQUEST, { apiKey: 'sk-openai-key', fetchImpl });

    expect(calls[0]?.url).toBe('https://api.openai.com/v1/chat/completions');
  });

  it('tries the same model once more after a server error when there is no backup model', async () => {
    const { fetchImpl, calls } = fakeFetch([
      { status: 503, body: { error: { message: 'overloaded' } } },
      { status: 200, body: geminiAnswer('{"reply":"ok"}') },
    ]);

    const answer = await requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, model: 'main', backupModels: [] });

    expect(answer).toEqual({ reply: 'ok' });
    expect(calls.map((call) => call.url)).toEqual([
      'https://generativelanguage.googleapis.com/v1beta/models/main:generateContent',
      'https://generativelanguage.googleapis.com/v1beta/models/main:generateContent',
    ]);
  });

  it('tries once more after an unreadable answer', async () => {
    const { fetchImpl, calls } = fakeFetch([
      { status: 200, body: geminiAnswer('not json') },
      { status: 200, body: geminiAnswer('{"reply":"ok"}') },
    ]);

    const answer = await requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT });

    expect(answer).toEqual({ reply: 'ok' });
    expect(calls).toHaveLength(2);
  });

  it('does not retry a rejected key', async () => {
    const { fetchImpl, calls } = fakeFetch([{ status: 401, body: { error: { message: 'API key not valid' } } }]);

    const kind = await failureKind(requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT }));

    expect(kind).toBe('auth');
    expect(calls).toHaveLength(1);
  });

  it('passes on the provider message for a request it does not accept', async () => {
    const { fetchImpl } = fakeFetch([{ status: 404, body: { error: { message: 'models/old-model is not found' } } }]);

    await expect(requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, backupModels: [] })).rejects.toThrow(
      'models/old-model is not found',
    );
  });

  it('gives up after the allowed number of tries', async () => {
    const { fetchImpl, calls } = fakeFetch([
      { status: 500, body: 'oops' },
      { status: 500, body: 'oops' },
      { status: 200, body: geminiAnswer('{"reply":"ok"}') },
    ]);

    const kind = await failureKind(requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, backupModels: [] }));

    expect(kind).toBe('server');
    expect(calls).toHaveLength(2);
  });

  it('reports a network problem', async () => {
    const { fetchImpl } = fakeFetch(['network-error', 'network-error']);

    const kind = await failureKind(requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT }));

    expect(kind).toBe('network');
  });

  it('reports a rate limit', async () => {
    const { fetchImpl } = fakeFetch([{ status: 429, body: {} }]);

    const kind = await failureKind(requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, maxAttempts: 1, backupModels: [] }));

    expect(kind).toBe('rate_limit');
  });
});

describe('orderModels', () => {
  it('lists the main model first, then the backups', () => {
    expect(orderModels('main', ['backup-a', 'backup-b'])).toEqual(['main', 'backup-a', 'backup-b']);
  });

  it('moves the preferred model to the front and keeps the rest in order', () => {
    expect(orderModels('main', ['backup-a', 'backup-b'], 'backup-b')).toEqual(['backup-b', 'main', 'backup-a']);
  });

  it('ignores a preferred model that is not in the list', () => {
    expect(orderModels('main', ['backup-a'], 'retired-model')).toEqual(['main', 'backup-a']);
  });

  it('lists a model once even when it is named twice', () => {
    expect(orderModels('main', ['backup-a', 'main', 'backup-a'])).toEqual(['main', 'backup-a']);
  });
});

describe('requestJson with backup models', () => {
  const MODELS = { model: 'main', backupModels: ['backup-a', 'backup-b'] };
  const urlOf = (model: string) => `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

  it('asks the next model, without a second try, when a model is out of quota', async () => {
    const { fetchImpl, calls } = fakeFetch([
      { status: 429, body: { error: { message: 'Quota exceeded' } } },
      { status: 200, body: geminiAnswer('{"reply":"ok"}') },
    ]);

    const answer = await requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, ...MODELS });

    expect(answer).toEqual({ reply: 'ok' });
    expect(calls.map((call) => call.url)).toEqual([urlOf('main'), urlOf('backup-a')]);
  });

  it('moves on from an overloaded model and from one that is closed to the key', async () => {
    const { fetchImpl, calls } = fakeFetch([
      { status: 503, body: { error: { message: 'high demand' } } },
      { status: 404, body: { error: { message: 'no longer available to new users' } } },
      { status: 200, body: geminiAnswer('{"reply":"ok"}') },
    ]);

    const answer = await requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, ...MODELS });

    expect(answer).toEqual({ reply: 'ok' });
    expect(calls.map((call) => call.url)).toEqual([urlOf('main'), urlOf('backup-a'), urlOf('backup-b')]);
  });

  it('reports which model answered', async () => {
    const { fetchImpl } = fakeFetch([
      { status: 429, body: {} },
      { status: 200, body: geminiAnswer('{"reply":"ok"}') },
    ]);
    const answered: string[] = [];

    await requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, ...MODELS, onModelAnswered: (model) => answered.push(model) });

    expect(answered).toEqual(['backup-a']);
  });

  it('starts with the preferred model', async () => {
    const { fetchImpl, calls } = fakeFetch([{ status: 200, body: geminiAnswer('{"reply":"ok"}') }]);

    await requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, ...MODELS, preferredModel: 'backup-b' });

    expect(calls.map((call) => call.url)).toEqual([urlOf('backup-b')]);
  });

  it('asks every model once and names them when all refuse', async () => {
    const { fetchImpl, calls } = fakeFetch([
      { status: 429, body: { error: { message: 'Quota exceeded for main' } } },
      { status: 503, body: {} },
      { status: 429, body: {} },
    ]);

    const failure = await requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, ...MODELS }).then(
      () => null,
      (error: unknown) => error,
    );

    expect(calls).toHaveLength(3);
    expect(failure instanceof LlmError ? failure.message : '').toBe(
      'Tried 3 AI models, none answered. main: The AI is rate limited or out of quota. Quota exceeded for main Then: backup-a (503), backup-b (429).',
    );
    expect(failure instanceof LlmError ? failure.kind : '').toBe('rate_limit');
  });

  it('does not ask another model when the key is rejected', async () => {
    const { fetchImpl, calls } = fakeFetch([{ status: 403, body: { error: { message: 'API key not valid' } } }]);

    const kind = await failureKind(requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, ...MODELS }));

    expect(kind).toBe('auth');
    expect(calls).toHaveLength(1);
  });

  it('does not ask another model when there is no internet', async () => {
    const { fetchImpl, calls } = fakeFetch(['network-error', 'network-error']);

    const kind = await failureKind(requestJson(REQUEST, { apiKey: 'AIzaKey', fetchImpl, sleep: NO_WAIT, ...MODELS }));

    expect(kind).toBe('network');
    expect(calls.map((call) => call.url)).toEqual([urlOf('main'), urlOf('main')]);
  });
});
