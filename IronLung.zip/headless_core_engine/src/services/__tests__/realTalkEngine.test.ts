import type { ActionItem, BrainDumpDoc, DailyLogDoc, MoodType, SmokeEntry } from '../../types/schema';
import {
  buildWeekRows,
  collectCarryoverTasks,
  computeRealTalkStats,
  formatPeriodHeader,
  getBriefingPeriod,
} from '../realTalkEngine';

// Every timestamp carries its own UTC offset, so these tests give the same
// result in every time zone. 24 November 2026 is a Tuesday.

function smoke(timestamp: string): SmokeEntry {
  return { id: timestamp, timestamp, trigger: 'Craving', gap_from_previous_mins: null, backdated_mins: 0 };
}

function dayLog(logicalDate: string, overrides: Partial<DailyLogDoc> = {}): DailyLogDoc {
  return {
    logical_date: logicalDate,
    total_count: 0,
    daily_target: 6,
    daily_baseline: 15,
    cost_per_cig_inr: 20,
    smoke_entries: [],
    cravings_crushed: 0,
    money_saved_inr: 0,
    active_target_gap_mins: 120,
    todays_brain_dump_headlines: [],
    chat_buffer: [],
    is_finalized: true,
    ...overrides,
  };
}

function task(id: string, done = false): ActionItem {
  return { id, task: `Task ${id}`, done };
}

function dump(
  id: string,
  logicalDate: string,
  mood: MoodType,
  overrides: Partial<BrainDumpDoc> = {},
  actionItems: ActionItem[] = [],
): BrainDumpDoc {
  return {
    id,
    logical_date: logicalDate,
    created_at: `${logicalDate}T10:00:00.000+05:30`,
    raw_transcript: 'transcript',
    ai_processed: { headline: `Headline ${id}`, mood_detected: mood, category: 'Work', action_items: actionItems },
    ai_status: 'done',
    ...overrides,
  };
}

describe('getBriefingPeriod', () => {
  it('covers the seven finished days before today', () => {
    expect(getBriefingPeriod('2026-11-24')).toEqual({
      start: '2026-11-17',
      end: '2026-11-23',
      dates: [
        '2026-11-17',
        '2026-11-18',
        '2026-11-19',
        '2026-11-20',
        '2026-11-21',
        '2026-11-22',
        '2026-11-23',
      ],
      weekId: '2026-W48',
      weekNumber: 48,
    });
  });
});

describe('formatPeriodHeader', () => {
  it('writes the week number and the first and last day', () => {
    const header = formatPeriodHeader({ start: '2026-11-17', end: '2026-11-23', weekNumber: 48 });

    expect(header).toBe('WEEK 48 // TUE 17 – MON 23');
  });

  it('pads single digits', () => {
    const header = formatPeriodHeader({ start: '2026-01-03', end: '2026-01-09', weekNumber: 2 });

    expect(header).toBe('WEEK 02 // SAT 03 – FRI 09');
  });
});

describe('computeRealTalkStats', () => {
  const logs = {
    // The week before.
    '2026-11-12': dayLog('2026-11-12', {
      total_count: 10,
      smoke_entries: [smoke('2026-11-12T09:00:00.000+05:30'), smoke('2026-11-12T10:40:00.000+05:30')],
    }),
    '2026-11-14': dayLog('2026-11-14', { total_count: 10 }),
    // The briefing week.
    '2026-11-17': dayLog('2026-11-17', {
      total_count: 4,
      smoke_entries: [
        smoke('2026-11-17T10:00:00.000+05:30'),
        smoke('2026-11-17T12:00:00.000+05:30'),
        smoke('2026-11-17T16:00:00.000+05:30'),
      ],
    }),
    '2026-11-18': dayLog('2026-11-18', { total_count: 8 }),
    '2026-11-20': dayLog('2026-11-20', {
      total_count: 3,
      smoke_entries: [smoke('2026-11-20T09:00:00.000+05:30'), smoke('2026-11-20T10:00:00.000+05:30')],
    }),
    // Today: must be ignored.
    '2026-11-24': dayLog('2026-11-24', { total_count: 50 }),
  };
  const dumps = [
    dump('a', '2026-11-17', 'Calm'),
    dump('b', '2026-11-17', 'Stressed'),
    dump('c', '2026-11-18', 'Stressed'),
    dump('d', '2026-11-20', 'Calm'),
    dump('e', '2026-11-20', 'Stressed', { ai_status: 'pending' }),
  ];

  it('summarises the week and compares it with the week before', () => {
    const stats = computeRealTalkStats({ logs, dumps, period: getBriefingPeriod('2026-11-24') });

    expect(stats).toEqual({
      days_recorded: 3,
      smokes_this_week: 15,
      smokes_last_week: 20,
      change_pct: -25,
      avg_gap_mins: 140,
      avg_gap_delta_mins: 40,
      days_on_target: 2,
      worst_day: { date: '2026-11-18', count: 8 },
      stressed_days_avg: 6,
      calm_days_avg: 3,
      stressed_dates: ['2026-11-17', '2026-11-18'],
    });
  });

  it('has no comparison when the week before was not recorded', () => {
    const onlyThisWeek = { '2026-11-18': dayLog('2026-11-18', { total_count: 8 }) };

    const stats = computeRealTalkStats({ logs: onlyThisWeek, dumps: [], period: getBriefingPeriod('2026-11-24') });

    expect(stats.smokes_last_week).toBeNull();
    expect(stats.change_pct).toBeNull();
    expect(stats.avg_gap_mins).toBeNull();
    expect(stats.avg_gap_delta_mins).toBeNull();
    expect(stats.stressed_days_avg).toBeNull();
    expect(stats.calm_days_avg).toBeNull();
  });

  it('returns zeros for a week without any record', () => {
    const stats = computeRealTalkStats({ logs: {}, dumps: [], period: getBriefingPeriod('2026-11-24') });

    expect(stats.days_recorded).toBe(0);
    expect(stats.smokes_this_week).toBe(0);
    expect(stats.worst_day).toBeNull();
  });
});

describe('collectCarryoverTasks', () => {
  it('returns unfinished tasks from the period, oldest first', () => {
    const dumps = [
      dump('late', '2026-11-22', 'Calm', { created_at: '2026-11-22T18:00:00.000+05:30' }, [task('t3')]),
      dump('early', '2026-11-18', 'Calm', { created_at: '2026-11-18T09:00:00.000+05:30' }, [
        task('t1'),
        task('t2', true),
      ]),
      dump('before', '2026-11-10', 'Calm', {}, [task('old')]),
      dump('today', '2026-11-24', 'Calm', {}, [task('new')]),
    ];

    const tasks = collectCarryoverTasks(dumps, { start: '2026-11-17', end: '2026-11-23' });

    expect(tasks).toEqual([
      { id: 't1', task: 'Task t1', source_date: '2026-11-18', dump_id: 'early' },
      { id: 't3', task: 'Task t3', source_date: '2026-11-22', dump_id: 'late' },
    ]);
  });
});

describe('buildWeekRows', () => {
  it('describes each day of the period, with or without a record', () => {
    const logs = { '2026-11-18': dayLog('2026-11-18', { total_count: 8, cravings_crushed: 1 }) };
    const dumps = [dump('c', '2026-11-18', 'Stressed'), dump('p', '2026-11-18', 'Calm', { ai_status: 'pending' })];

    const rows = buildWeekRows(logs, dumps, getBriefingPeriod('2026-11-24'));

    expect(rows).toHaveLength(7);
    expect(rows[0]).toEqual({
      date: '2026-11-17',
      weekday: 'TUE',
      smokes: null,
      target: null,
      cravings_crushed: null,
      brain_dump_moods: [],
      brain_dump_headlines: [],
    });
    expect(rows[1]).toEqual({
      date: '2026-11-18',
      weekday: 'WED',
      smokes: 8,
      target: 6,
      cravings_crushed: 1,
      brain_dump_moods: ['Stressed'],
      brain_dump_headlines: ['Headline c'],
    });
  });
});
