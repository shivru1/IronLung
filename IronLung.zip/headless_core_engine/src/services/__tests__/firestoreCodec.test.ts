import type { DailyLogDoc } from '../../types/schema';
import { decodeFields, decodeValue, encodeFields, encodeValue } from '../firestoreCodec';

const DAY: DailyLogDoc = {
  logical_date: '2026-11-19',
  total_count: 1,
  daily_target: 8,
  daily_baseline: 15,
  cost_per_cig_inr: 20,
  smoke_entries: [
    {
      id: 'smk_1',
      timestamp: '2026-11-19T15:20:00.000+05:30',
      trigger: 'Work Stress',
      gap_from_previous_mins: null,
      backdated_mins: 0,
    },
  ],
  cravings_crushed: 3,
  money_saved_inr: 60,
  active_target_gap_mins: 150,
  todays_brain_dump_headlines: ['Client deck deadline is crushing my focus'],
  chat_buffer: [],
  is_finalized: false,
};

describe('encodeValue', () => {
  it('writes whole numbers as integer strings', () => {
    expect(encodeValue(4)).toEqual({ integerValue: '4' });
  });

  it('writes fractions as doubles', () => {
    expect(encodeValue(5.5)).toEqual({ doubleValue: 5.5 });
  });

  it('writes text, booleans and null', () => {
    expect(encodeValue('Craving')).toEqual({ stringValue: 'Craving' });
    expect(encodeValue(false)).toEqual({ booleanValue: false });
    expect(encodeValue(null)).toEqual({ nullValue: null });
  });

  it('writes lists and nested objects', () => {
    expect(encodeValue([{ done: true }, 'x'])).toEqual({
      arrayValue: {
        values: [{ mapValue: { fields: { done: { booleanValue: true } } } }, { stringValue: 'x' }],
      },
    });
  });
});

describe('encodeFields', () => {
  it('leaves out properties that are undefined', () => {
    expect(encodeFields({ task: 'Call Dad', due_time: undefined })).toEqual({ task: { stringValue: 'Call Dad' } });
  });
});

describe('decodeValue', () => {
  it('reads an integer string as a number', () => {
    expect(decodeValue({ integerValue: '42' })).toBe(42);
  });

  it('reads an empty list that has no values field', () => {
    expect(decodeValue({ arrayValue: {} })).toEqual([]);
  });

  it('reads an empty object that has no fields', () => {
    expect(decodeValue({ mapValue: {} })).toEqual({});
  });

  it('reads a timestamp as text', () => {
    expect(decodeValue({ timestampValue: '2026-11-19T09:50:00Z' })).toBe('2026-11-19T09:50:00Z');
  });
});

describe('decodeFields', () => {
  it('gives an empty object when the document has no fields', () => {
    expect(decodeFields(undefined)).toEqual({});
  });

  it('gives back a daily log exactly as it was encoded', () => {
    const encoded = encodeFields(DAY as unknown as Record<string, unknown>);

    expect(decodeFields(encoded)).toEqual(DAY);
  });
});
