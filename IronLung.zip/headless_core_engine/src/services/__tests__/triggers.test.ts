import {
  addCustomTrigger,
  findTrigger,
  isBuiltInTrigger,
  listTriggers,
  normalizeTriggerName,
  removeCustomTrigger,
  sanitizeCustomTriggers,
} from '../triggers';

const TWELVE_TRIGGERS = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'];

describe('normalizeTriggerName', () => {
  it('removes spaces at the ends and doubles inside', () => {
    expect(normalizeTriggerName('  With   Chai ')).toBe('With Chai');
  });

  it('cuts a long name to 18 characters', () => {
    expect(normalizeTriggerName('After a long phone call')).toBe('After a long phone');
  });

  it('leaves no space at the end after cutting', () => {
    expect(normalizeTriggerName('Seventeen letters x y')).toBe('Seventeen letters');
  });

  it('counts an emoji as one character and never cuts it in half', () => {
    expect(normalizeTriggerName('12345678901234567😀x')).toBe('12345678901234567😀');
  });

  it('gives an empty name for spaces only', () => {
    expect(normalizeTriggerName('   ')).toBe('');
  });
});

describe('isBuiltInTrigger', () => {
  it('knows the two triggers added later', () => {
    expect(isBuiltInTrigger('Post-Bath')).toBe(true);
    expect(isBuiltInTrigger('With Alcohol')).toBe(true);
  });

  it('says no to a trigger the user made', () => {
    expect(isBuiltInTrigger('With Chai')).toBe(false);
  });
});

describe('listTriggers', () => {
  it('lists the built-in triggers first, then the user\'s own', () => {
    expect(listTriggers(['With Chai', 'Driving'])).toEqual([
      'Work Stress',
      'Post-Meal',
      'Boredom',
      'Social',
      'Late Night',
      'Craving',
      'Post-Bath',
      'With Alcohol',
      'With Chai',
      'Driving',
    ]);
  });
});

describe('findTrigger', () => {
  it('finds a built-in trigger whatever the case', () => {
    expect(findTrigger('post-bath', [])).toBe('Post-Bath');
  });

  it('finds one of the user\'s own and returns it as it was saved', () => {
    expect(findTrigger(' WITH chai ', ['With Chai'])).toBe('With Chai');
  });

  it('returns null for a name that is not in the list', () => {
    expect(findTrigger('Driving', ['With Chai'])).toBeNull();
  });
});

describe('addCustomTrigger', () => {
  it('adds a tidied name to the end of the list', () => {
    expect(addCustomTrigger(['Driving'], '  With  Chai ')).toEqual({
      ok: true,
      trigger: 'With Chai',
      customTriggers: ['Driving', 'With Chai'],
    });
  });

  it('refuses an empty name', () => {
    expect(addCustomTrigger([], '   ')).toEqual({ ok: false, reason: 'empty' });
  });

  it('refuses a name that is built in and says how it is spelled', () => {
    expect(addCustomTrigger([], 'social')).toEqual({ ok: false, reason: 'exists', trigger: 'Social' });
  });

  it('refuses a name the user already added', () => {
    expect(addCustomTrigger(['With Chai'], 'with chai')).toEqual({ ok: false, reason: 'exists', trigger: 'With Chai' });
  });

  it('refuses a thirteenth trigger', () => {
    expect(addCustomTrigger(TWELVE_TRIGGERS, 'One more')).toEqual({ ok: false, reason: 'full' });
  });

  it('does not change the list it was given', () => {
    const before = ['Driving'];

    addCustomTrigger(before, 'With Chai');

    expect(before).toEqual(['Driving']);
  });
});

describe('removeCustomTrigger', () => {
  it('takes the named trigger off the list', () => {
    expect(removeCustomTrigger(['Driving', 'With Chai'], 'Driving')).toEqual(['With Chai']);
  });

  it('leaves the list as it is when the name is not on it', () => {
    expect(removeCustomTrigger(['Driving'], 'With Chai')).toEqual(['Driving']);
  });
});

describe('sanitizeCustomTriggers', () => {
  it('keeps a clean list as it is', () => {
    expect(sanitizeCustomTriggers(['Driving', 'With Chai'])).toEqual(['Driving', 'With Chai']);
  });

  it('gives an empty list for anything that is not a list', () => {
    expect(sanitizeCustomTriggers(undefined)).toEqual([]);
    expect(sanitizeCustomTriggers('Driving')).toEqual([]);
    expect(sanitizeCustomTriggers({ 0: 'Driving' })).toEqual([]);
  });

  it('drops entries that are not text, are empty, are built in or appear twice', () => {
    expect(sanitizeCustomTriggers(['Driving', 7, null, '  ', 'Social', 'driving', ' With  Chai '])).toEqual([
      'Driving',
      'With Chai',
    ]);
  });

  it('keeps only the first 12', () => {
    expect(sanitizeCustomTriggers([...TWELVE_TRIGGERS, 'T13'])).toEqual(TWELVE_TRIGGERS);
  });
});
