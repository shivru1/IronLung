import type { DailyLogDoc, SmokeEntry } from '../../types/schema';
import { buildDangerAlertPlan, buildTrackerNotificationText } from '../notificationContent';
import { applySpeechResult, commitInterim, EMPTY_TRANSCRIPT, getFullTranscript } from '../speechTranscript';

const LAST_SMOKE: SmokeEntry = {
  id: 's1',
  timestamp: '2026-11-19T14:52:00.000+05:30',
  trigger: 'Work Stress',
  gap_from_previous_mins: 138,
  backdated_mins: 0,
};

const TODAY: DailyLogDoc = {
  logical_date: '2026-11-19',
  total_count: 4,
  daily_target: 8,
  daily_baseline: 15,
  cost_per_cig_inr: 20,
  smoke_entries: [LAST_SMOKE],
  cravings_crushed: 3,
  money_saved_inr: 60,
  active_target_gap_mins: 150,
  todays_brain_dump_headlines: [],
  chat_buffer: [],
  is_finalized: false,
};

describe('buildTrackerNotificationText', () => {
  it('shows the count, the wait target, the last cigarette and the savings', () => {
    expect(buildTrackerNotificationText(TODAY, LAST_SMOKE)).toEqual({
      title: '4 / 8 today · wait 2h 30m',
      body: 'Last smoke 14:52 · 3 crushed · ₹60 saved',
    });
  });

  it('says so when nothing was logged yet', () => {
    const fresh = { ...TODAY, total_count: 0, smoke_entries: [], cravings_crushed: 0, money_saved_inr: 0 };

    expect(buildTrackerNotificationText(fresh, null)).toEqual({
      title: '0 / 8 today · wait 2h 30m',
      body: 'No smoke logged yet · 0 crushed · ₹0 saved',
    });
  });

  it('has a fallback before today has a log', () => {
    expect(buildTrackerNotificationText(undefined, null)).toEqual({
      title: 'Smoke tracker',
      body: 'Open the app to start today.',
    });
  });
});

describe('buildDangerAlertPlan', () => {
  it('fires ten minutes before the window and names the current wait target', () => {
    expect(buildDangerAlertPlan('15:00 - 18:00', 150)).toEqual({
      hour: 14,
      minute: 50,
      title: 'Danger window opens in 10 min',
      body: "15:00 – 18:00 is when you smoke most. Hold your 2h 30m gap. Walk. Water. Don't negotiate.",
    });
  });

  it('fires on the evening before for a window that opens at midnight', () => {
    const plan = buildDangerAlertPlan('00:00 - 03:00', 45);

    expect(plan?.hour).toBe(23);
    expect(plan?.minute).toBe(50);
  });

  it('has no alert without a window', () => {
    expect(buildDangerAlertPlan(null, 150)).toBeNull();
  });
});

describe('speech transcript', () => {
  it('replaces the current guess with each interim result', () => {
    const first = applySpeechResult(EMPTY_TRANSCRIPT, 'need to', false);

    const second = applySpeechResult(first, 'need to send the deck', false);

    expect(second).toEqual({ finalText: '', interimText: 'need to send the deck' });
  });

  it('moves a final result into the settled text', () => {
    const guessing = applySpeechResult(EMPTY_TRANSCRIPT, 'need to send', false);

    const settled = applySpeechResult(guessing, 'Need to send the deck.', true);

    expect(settled).toEqual({ finalText: 'Need to send the deck.', interimText: '' });
  });

  it('joins the stretches of a long recording with spaces', () => {
    const first = applySpeechResult(EMPTY_TRANSCRIPT, 'Need to send the deck.', true);

    const second = applySpeechResult(first, ' Then call Dad. ', true);

    expect(second.finalText).toBe('Need to send the deck. Then call Dad.');
  });

  it('keeps the last guess when the recogniser stops on its own', () => {
    const settled = applySpeechResult(EMPTY_TRANSCRIPT, 'Need to send the deck.', true);
    const guessing = applySpeechResult(settled, 'then call', false);

    const committed = commitInterim(guessing);

    expect(committed).toEqual({ finalText: 'Need to send the deck. then call', interimText: '' });
  });

  it('gives the settled text followed by the current guess', () => {
    const settled = applySpeechResult(EMPTY_TRANSCRIPT, 'Need to send the deck.', true);
    const guessing = applySpeechResult(settled, 'then call', false);

    expect(getFullTranscript(guessing)).toBe('Need to send the deck. then call');
  });

  it('is empty before anything was said', () => {
    expect(getFullTranscript(EMPTY_TRANSCRIPT)).toBe('');
  });
});
