import type { DailyLogDoc, RollingMemoryDoc, SmokeEntry } from '../../types/schema';
import { buildBrainDumpUserPrompt, buildSmokeCoachContext, buildSmokeCoachUserPrompt } from '../aiPrompts';

const MEMORY: RollingMemoryDoc = {
  last_computed_date: '2026-11-18',
  stats: {
    current_daily_target: 8,
    avg_7_day: 5.249,
    avg_30_day: 6.06,
    longest_gap_7_day_mins: 255,
    peak_danger_window: '15:00 - 18:00',
    top_triggers_7_day: { 'Work Stress': 9, 'Post-Meal': 5, Boredom: 2, Social: 1, 'Late Night': 4, Craving: 0 },
    total_money_saved_all_time: 4720,
  },
  ai_memory_notes: ['Smokes right after the 3 pm review meetings.'],
  chart_cache_30_days: [],
};

const WORK_STRESS_SMOKE: SmokeEntry = {
  id: 's2',
  timestamp: '2026-11-19T14:52:00.000+05:30',
  trigger: 'Work Stress',
  gap_from_previous_mins: 138,
  backdated_mins: 0,
};

const TODAY: DailyLogDoc = {
  logical_date: '2026-11-19',
  total_count: 2,
  daily_target: 8,
  daily_baseline: 15,
  cost_per_cig_inr: 20,
  smoke_entries: [
    { id: 's1', timestamp: '2026-11-19T12:34:00.000+05:30', trigger: 'Post-Meal', gap_from_previous_mins: null, backdated_mins: 0 },
    WORK_STRESS_SMOKE,
  ],
  cravings_crushed: 3,
  money_saved_inr: 60,
  active_target_gap_mins: 150,
  todays_brain_dump_headlines: ['Client deck deadline is crushing my focus'],
  chat_buffer: [{ id: 'm1', role: 'user', text: 'Holding. Deck review at 3.', timestamp: '2026-11-19T14:40:00.000+05:30' }],
  is_finalized: false,
};

/** A moment on 19 November 2026, on the phone's clock. */
function clock(hour: number, minute: number): Date {
  return new Date(2026, 10, 19, hour, minute);
}

describe('buildSmokeCoachContext', () => {
  it('packs the event, today, the danger window, history and chat', () => {
    const context = buildSmokeCoachContext({
      memory: MEMORY,
      today: TODAY,
      event: { type: 'SMOKE_LOGGED', entry: WORK_STRESS_SMOKE },
      now: clock(14, 52),
      minutesSinceLastSmoke: 0,
    });

    expect(context).toEqual({
      now: '14:52',
      event: { type: 'SMOKE_LOGGED', trigger: 'Work Stress', gap_from_previous_mins: 138, backdated_mins: 0 },
      today: {
        smokes_so_far: 2,
        daily_target: 8,
        cravings_crushed: 3,
        money_saved_inr: 60,
        current_target_gap_mins: 150,
        minutes_since_last_smoke: 0,
        smokes: [
          { time: '12:34', trigger: 'Post-Meal', gap_from_previous_mins: null },
          { time: '14:52', trigger: 'Work Stress', gap_from_previous_mins: 138 },
        ],
        brain_dump_headlines: ['Client deck deadline is crushing my focus'],
      },
      danger_window: { window: '15:00 - 18:00', inside_now: false, minutes_until_it_opens: 8 },
      history: {
        avg_per_day_last_7_days: 5.2,
        avg_per_day_last_30_days: 6.1,
        longest_gap_last_7_days_mins: 255,
        trigger_counts_last_7_days: { 'Work Stress': 9, 'Post-Meal': 5, Boredom: 2, Social: 1, 'Late Night': 4, Craving: 0 },
        total_money_saved_inr: 4780,
      },
      memory_notes: ['Smokes right after the 3 pm review meetings.'],
      recent_chat: [{ role: 'user', text: 'Holding. Deck review at 3.' }],
    });
  });

  it('says so when the danger window is open', () => {
    const context = buildSmokeCoachContext({
      memory: MEMORY,
      today: TODAY,
      event: { type: 'CRAVING_CRUSHED' },
      now: clock(16, 10),
      minutesSinceLastSmoke: 78,
    });

    expect(context.danger_window).toEqual({ window: '15:00 - 18:00', inside_now: true, minutes_until_it_opens: 0 });
    expect(context.event).toEqual({ type: 'CRAVING_CRUSHED' });
  });

  it('passes the chat message of the user', () => {
    const context = buildSmokeCoachContext({
      memory: MEMORY,
      today: TODAY,
      event: { type: 'USER_CHAT_MESSAGE', text: 'Can I push the gap to 3 hours?' },
      now: clock(10, 0),
      minutesSinceLastSmoke: null,
    });

    expect(context.event).toEqual({ type: 'USER_CHAT_MESSAGE', text: 'Can I push the gap to 3 hours?' });
  });

  it('has no history and no danger window for a new user', () => {
    const context = buildSmokeCoachContext({
      memory: null,
      today: TODAY,
      event: { type: 'CRAVING_CRUSHED' },
      now: clock(10, 0),
      minutesSinceLastSmoke: null,
    });

    expect(context.history).toBeNull();
    expect(context.danger_window).toBeNull();
    expect(context.memory_notes).toEqual([]);
  });
});

describe('buildSmokeCoachUserPrompt', () => {
  it('sends the context as JSON', () => {
    const prompt = buildSmokeCoachUserPrompt({
      memory: null,
      today: TODAY,
      event: { type: 'CRAVING_CRUSHED' },
      now: clock(10, 0),
      minutesSinceLastSmoke: null,
    });

    expect(prompt).toMatch(/^CONTEXT:\n\{"now":"10:00","event":\{"type":"CRAVING_CRUSHED"\}/);
  });
});

describe('buildBrainDumpUserPrompt', () => {
  it('sends the time and the trimmed transcript', () => {
    const prompt = buildBrainDumpUserPrompt('  Need to send the deck before the 3 pm review.  ', clock(11, 40));

    expect(prompt).toBe('CURRENT TIME: 11:40\nTRANSCRIPT:\nNeed to send the deck before the 3 pm review.');
  });
});
