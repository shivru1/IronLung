import { createMemoryKv } from '../../storage/kv';
import { createAppStore } from '../../store/createAppStore';
import type { DailyLogDoc } from '../../types/schema';
import { encodeFields } from '../firestoreCodec';
import { createFirestoreSync } from '../firestoreSync';
import type { FirebaseConfig, SyncFetch } from '../firestoreSync';

// Dates are built with the local-time constructor, so the tests give the same
// result in every time zone.

const CONFIG: FirebaseConfig = {
  apiKey: 'web-api-key',
  projectId: 'my-project',
  email: 'me@example.com',
  password: 'secret',
};

const DOCS = 'https://firestore.googleapis.com/v1/projects/my-project/databases/(default)/documents/users/uid-1';

/** A moment on a day of November 2026, on the phone's clock. */
function november(day: number, hour: number): Date {
  return new Date(2026, 10, day, hour, 0);
}

interface Call {
  method: string;
  url: string;
  body: unknown;
  authorization: string | undefined;
}

/**
 * A fake Firebase. Sign-in always works; every other request is answered by
 * the first route whose text is part of "<METHOD> <url>", or with an empty 200.
 */
function fakeFirebase(routes: Array<{ match: string; status: number; body: unknown }> = []): {
  fetchImpl: SyncFetch;
  calls: Call[];
} {
  const calls: Call[] = [];
  const fetchImpl: SyncFetch = async (url, init) => {
    calls.push({
      method: init.method,
      url,
      body: init.body === undefined ? undefined : (JSON.parse(init.body) as unknown),
      authorization: init.headers.Authorization,
    });
    const key = `${init.method} ${url}`;
    const route = routes.find((r) => key.includes(r.match));
    if (route) {
      return { ok: route.status >= 200 && route.status < 300, status: route.status, text: async () => JSON.stringify(route.body) };
    }
    if (url.includes('accounts:signInWithPassword')) {
      return {
        ok: true,
        status: 200,
        text: async () => JSON.stringify({ idToken: 'token-1', localId: 'uid-1', expiresIn: '3600' }),
      };
    }
    return { ok: true, status: 200, text: async () => '{}' };
  };
  return { fetchImpl, calls };
}

function remoteDay(logicalDate: string, totalCount: number): DailyLogDoc {
  return {
    logical_date: logicalDate,
    total_count: totalCount,
    daily_target: 8,
    daily_baseline: 15,
    cost_per_cig_inr: 20,
    smoke_entries: [],
    cravings_crushed: 0,
    money_saved_inr: 0,
    active_target_gap_mins: 120,
    todays_brain_dump_headlines: [],
    chat_buffer: [],
    is_finalized: true,
  };
}

/** A phone that already has two days and a brain dump, so no restore is attempted. */
function usedPhone() {
  const { useStore, storage } = createAppStore(createMemoryKv());
  useStore.getState().logSmoke({ now: november(18, 12) });
  useStore.getState().logSmoke({ now: november(19, 12) });
  return { useStore, storage };
}

describe('createFirestoreSync', () => {
  it('does nothing when Firebase is not configured', async () => {
    const { useStore, storage } = usedPhone();
    const { fetchImpl, calls } = fakeFirebase();
    const sync = createFirestoreSync({ config: { ...CONFIG, apiKey: '' }, storage, store: useStore, fetchImpl });

    const result = await sync.syncNow();

    expect(sync.isEnabled()).toBe(false);
    expect(result).toEqual({ ok: true, uploaded: 0, deleted: 0, restored: 0 });
    expect(calls).toHaveLength(0);
  });

  it('signs in and uploads every changed document under the user', async () => {
    const { useStore, storage } = usedPhone();
    const { fetchImpl, calls } = fakeFirebase();
    const sync = createFirestoreSync({ config: CONFIG, storage, store: useStore, fetchImpl });

    const result = await sync.syncNow();

    expect(result).toEqual({ ok: true, uploaded: 4, deleted: 0, restored: 0 });
    expect(calls.map((call) => `${call.method} ${call.url}`)).toEqual([
      'POST https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=web-api-key',
      `PATCH ${DOCS}/ai_context/rolling_memory`,
      `PATCH ${DOCS}/daily_logs/2026-11-18`,
      `PATCH ${DOCS}/daily_logs/2026-11-19`,
      `PATCH ${DOCS}/settings/app`,
    ]);
    expect(calls[0]?.body).toEqual({ email: 'me@example.com', password: 'secret', returnSecureToken: true });
    expect(calls[2]?.authorization).toBe('Bearer token-1');
    expect(calls[2]?.body).toEqual({
      fields: encodeFields(useStore.getState().dailyLogs['2026-11-18'] as unknown as Record<string, unknown>),
    });
    expect(storage.getDirtyPaths()).toEqual([]);
  });

  it('uploads only what changed since the last sync and reuses the sign-in', async () => {
    const { useStore, storage } = usedPhone();
    const { fetchImpl, calls } = fakeFirebase();
    const sync = createFirestoreSync({ config: CONFIG, storage, store: useStore, fetchImpl });
    await sync.syncNow();
    calls.length = 0;
    useStore.getState().crushCraving(november(19, 13));

    const result = await sync.syncNow();

    expect(result.uploaded).toBe(1);
    expect(calls.map((call) => `${call.method} ${call.url}`)).toEqual([`PATCH ${DOCS}/daily_logs/2026-11-19`]);
  });

  it('deletes the cloud copy of a document that was deleted on the phone', async () => {
    const { useStore, storage } = usedPhone();
    useStore.getState().addBrainDump({
      id: 'd1',
      logical_date: '2026-11-19',
      created_at: '2026-11-19T10:00:00.000+05:30',
      raw_transcript: 'transcript',
      ai_processed: { headline: 'Headline', mood_detected: 'Calm', category: 'Work', action_items: [] },
      ai_status: 'pending',
    });
    const { fetchImpl, calls } = fakeFirebase();
    const sync = createFirestoreSync({ config: CONFIG, storage, store: useStore, fetchImpl });
    await sync.syncNow();
    calls.length = 0;
    useStore.getState().deleteDump('d1');

    const result = await sync.syncNow();

    expect(result).toEqual({ ok: true, uploaded: 0, deleted: 1, restored: 0 });
    expect(calls.map((call) => `${call.method} ${call.url}`)).toEqual([`DELETE ${DOCS}/brain_dumps/d1`]);
  });

  it('keeps a document queued when the cloud refuses it', async () => {
    const { useStore, storage } = usedPhone();
    const { fetchImpl } = fakeFirebase([
      { match: 'PATCH', status: 403, body: { error: { message: 'Missing or insufficient permissions.' } } },
    ]);
    const sync = createFirestoreSync({ config: CONFIG, storage, store: useStore, fetchImpl });

    const result = await sync.syncNow();

    expect(result.ok).toBe(false);
    expect(result.message).toBe(
      'The cloud backup refused a request (403). Check the Firestore security rules. Missing or insufficient permissions.',
    );
    expect(storage.getDirtyPaths()).toHaveLength(4);
  });

  it('reports a failed sign-in', async () => {
    const { useStore, storage } = usedPhone();
    const { fetchImpl } = fakeFirebase([
      { match: 'accounts:signInWithPassword', status: 400, body: { error: { message: 'INVALID_LOGIN_CREDENTIALS' } } },
    ]);
    const sync = createFirestoreSync({ config: CONFIG, storage, store: useStore, fetchImpl });

    const result = await sync.syncNow();

    expect(result).toEqual({
      ok: false,
      uploaded: 0,
      deleted: 0,
      restored: 0,
      message: 'Cloud sign-in failed. INVALID_LOGIN_CREDENTIALS',
    });
  });

  it('reports a missing connection', async () => {
    const { useStore, storage } = usedPhone();
    const offline: SyncFetch = async () => {
      throw new Error('offline');
    };
    const sync = createFirestoreSync({ config: CONFIG, storage, store: useStore, fetchImpl: offline });

    const result = await sync.syncNow();

    expect(result.ok).toBe(false);
    expect(result.message).toBe('No connection to the cloud backup.');
  });

  it('restores the backup on a fresh install without uploading it again', async () => {
    const { useStore, storage } = createAppStore(createMemoryKv());
    useStore.getState().ensureToday(november(19, 9));
    const backupDay = remoteDay('2026-11-17', 6);
    const { fetchImpl, calls } = fakeFirebase([
      {
        match: `GET ${DOCS}/daily_logs?`,
        status: 200,
        body: {
          documents: [
            {
              name: 'projects/my-project/databases/(default)/documents/users/uid-1/daily_logs/2026-11-17',
              fields: encodeFields(backupDay as unknown as Record<string, unknown>),
            },
          ],
        },
      },
      { match: `GET ${DOCS}/settings/app`, status: 404, body: {} },
      { match: `GET ${DOCS}/ai_context/rolling_memory`, status: 404, body: {} },
    ]);
    const sync = createFirestoreSync({ config: CONFIG, storage, store: useStore, fetchImpl });

    const result = await sync.syncNow();

    const uploadedUrls = calls.filter((call) => call.method === 'PATCH').map((call) => call.url);
    expect(result.ok).toBe(true);
    expect(result.restored).toBe(1);
    expect(useStore.getState().dailyLogs['2026-11-17']).toEqual(backupDay);
    expect(uploadedUrls.includes(`${DOCS}/daily_logs/2026-11-17`)).toBe(false);
    expect(storage.getDirtyPaths()).toEqual([]);
  });

  it('does not try to restore on a phone that already has data', async () => {
    const { useStore, storage } = usedPhone();
    const { fetchImpl, calls } = fakeFirebase();
    const sync = createFirestoreSync({ config: CONFIG, storage, store: useStore, fetchImpl });

    await sync.syncNow();

    expect(calls.filter((call) => call.method === 'GET')).toHaveLength(0);
  });
});
