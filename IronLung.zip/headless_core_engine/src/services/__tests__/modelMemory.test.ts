import { createMemoryKv } from '../../storage/kv';
import { createModelMemory } from '../modelMemory';

const SIX_HOURS_MS = 6 * 60 * 60 * 1000;
const ONE_HOUR_MS = 60 * 60 * 1000;

describe('createModelMemory', () => {
  it('remembers nothing at first', () => {
    const memory = createModelMemory(createMemoryKv(), SIX_HOURS_MS, () => 0);

    expect(memory.get()).toBeNull();
  });

  it('remembers a backup model that answered', () => {
    const memory = createModelMemory(createMemoryKv(), SIX_HOURS_MS, () => 1000);

    memory.remember('backup-a', 'main');

    expect(memory.get()).toBe('backup-a');
  });

  it('keeps the memory across restarts (a new object over the same storage)', () => {
    const kv = createMemoryKv();
    createModelMemory(kv, SIX_HOURS_MS, () => 1000).remember('backup-a', 'main');

    expect(createModelMemory(kv, SIX_HOURS_MS, () => 2000).get()).toBe('backup-a');
  });

  it('forgets the backup model once it is too old', () => {
    let nowMs = 0;
    const memory = createModelMemory(createMemoryKv(), SIX_HOURS_MS, () => nowMs);
    memory.remember('backup-a', 'main');

    nowMs = SIX_HOURS_MS;

    expect(memory.get()).toBeNull();
  });

  it('does not restart the clock when the same backup model answers again', () => {
    let nowMs = 0;
    const memory = createModelMemory(createMemoryKv(), SIX_HOURS_MS, () => nowMs);
    memory.remember('backup-a', 'main');
    nowMs = 5 * ONE_HOUR_MS;
    memory.remember('backup-a', 'main');

    nowMs = 6 * ONE_HOUR_MS;

    expect(memory.get()).toBeNull();
  });

  it('starts a new clock when the old memory has worn off', () => {
    let nowMs = 0;
    const memory = createModelMemory(createMemoryKv(), SIX_HOURS_MS, () => nowMs);
    memory.remember('backup-a', 'main');
    nowMs = 7 * ONE_HOUR_MS;
    memory.remember('backup-a', 'main');

    nowMs = 12 * ONE_HOUR_MS;

    expect(memory.get()).toBe('backup-a');
  });

  it('switches to another backup model', () => {
    const memory = createModelMemory(createMemoryKv(), SIX_HOURS_MS, () => 0);
    memory.remember('backup-a', 'main');

    memory.remember('backup-b', 'main');

    expect(memory.get()).toBe('backup-b');
  });

  it('forgets the backup model when the main model answers', () => {
    const memory = createModelMemory(createMemoryKv(), SIX_HOURS_MS, () => 0);
    memory.remember('backup-a', 'main');

    memory.remember('main', 'main');

    expect(memory.get()).toBeNull();
  });

  it('treats unreadable saved data as no memory', () => {
    const memory = createModelMemory(createMemoryKv({ answering_model: 'not json' }), SIX_HOURS_MS, () => 0);

    expect(memory.get()).toBeNull();
  });
});
