/**
 * The three AI pipelines and what they do to the app's data.
 *
 * - Smoke Coach: reads the rolling memory and today's log, answers in the
 *   chat, moves the wait target and may save a memory note.
 * - Brain Dump: saves the transcript on the phone first, then lets the AI add
 *   a headline, a mood, a category and tasks.
 * - Real Talk: turns the last 7 finished days into a weekly briefing.
 *
 * `createAiPipelines` takes the store, the key lookup and the AI client as
 * parameters, so the pipelines can be tested with a fake AI. The app uses the
 * ready-made instance exported from `aiService.ts`.
 */

import type { AppStore } from '../store/createAppStore';
import { selectTodayLog } from '../store/createAppStore';
import type { BrainDumpDoc, RealTalkBriefingDoc } from '../types/schema';
import { toLocalIsoString } from '../utils/dateUtils';
import { createId } from '../utils/id';
import {
  AiContractError,
  BRAIN_DUMP_SCHEMA,
  buildPlaceholderBrainDumpResult,
  parseBrainDumpResult,
  parseRealTalkTexts,
  parseSmokeCoachResult,
  REAL_TALK_SCHEMA,
  SMOKE_COACH_SCHEMA,
} from './aiContracts';
import {
  BRAIN_DUMP_SYSTEM_PROMPT,
  buildBrainDumpUserPrompt,
  buildRealTalkUserPrompt,
  buildSmokeCoachUserPrompt,
  REAL_TALK_SYSTEM_PROMPT,
  SMOKE_COACH_SYSTEM_PROMPT,
} from './aiPrompts';
import type { CoachEvent } from './aiPrompts';
import { LlmError } from './llmClient';
import type { LlmClientOptions, LlmJsonRequest } from './llmClient';
import { buildWeekRows, collectCarryoverTasks, computeRealTalkStats, getBriefingPeriod } from './realTalkEngine';
import { findLastSmoke, getElapsedMins } from './smokeEngine';

export interface AiPipelineDeps {
  /** The app store (anything with `getState`). */
  store: { getState: () => AppStore };
  /** Returns the API key from secure storage, or `null` when none is set. */
  getApiKey: () => Promise<string | null>;
  requestJson: (request: LlmJsonRequest, options: LlmClientOptions) => Promise<unknown>;
  now: () => Date;
}

/** Why a pipeline produced nothing. `message` is short and can be shown to the user. */
export interface AiFailure {
  ok: false;
  reason: 'no_key' | 'no_data' | 'failed';
  message: string;
}

export type CoachOutcome = { ok: true; reply: string } | AiFailure;
export type BriefingOutcome = { ok: true; briefing: RealTalkBriefingDoc } | AiFailure;

export const NO_KEY_MESSAGE = 'No AI key yet. Add it under REAL TALK > QUICK SETTINGS.';
const NO_DATA_MESSAGE = 'Nothing to brief on yet. Log at least one full day first.';
const MAX_PENDING_PER_RETRY = 5;

function describeError(error: unknown): AiFailure {
  if (error instanceof LlmError) {
    return error.kind === 'no_key'
      ? { ok: false, reason: 'no_key', message: NO_KEY_MESSAGE }
      : { ok: false, reason: 'failed', message: error.message };
  }
  if (error instanceof AiContractError) {
    return { ok: false, reason: 'failed', message: 'The AI answered in the wrong format. Try again.' };
  }
  return { ok: false, reason: 'failed', message: 'The AI request failed. Try again.' };
}

export function createAiPipelines(deps: AiPipelineDeps) {
  const state = () => deps.store.getState();

  // Coach calls run one after another so replies land in the order of the events.
  let coachQueue: Promise<unknown> = Promise.resolve();
  let waitingCoachCalls = 0;

  async function runCoach(event: CoachEvent): Promise<CoachOutcome> {
    const apiKey = await deps.getApiKey();
    if (!apiKey) {
      return { ok: false, reason: 'no_key', message: NO_KEY_MESSAGE };
    }
    const now = deps.now();
    state().ensureToday(now);
    const current = state();
    const today = selectTodayLog(current, now);
    if (!today) {
      return { ok: false, reason: 'failed', message: 'Today has no log yet.' };
    }
    try {
      const lastSmoke = findLastSmoke(current.dailyLogs, now.getTime());
      const raw = await deps.requestJson(
        {
          system: SMOKE_COACH_SYSTEM_PROMPT,
          user: buildSmokeCoachUserPrompt({
            memory: current.rollingMemory,
            today,
            event,
            now,
            minutesSinceLastSmoke: getElapsedMins(lastSmoke ? lastSmoke.entry : null, now.getTime()),
          }),
          schema: SMOKE_COACH_SCHEMA,
          schemaName: 'smoke_coach_reply',
          temperature: 0.7,
        },
        { apiKey },
      );
      const result = parseSmokeCoachResult(raw);
      const answeredAt = deps.now();
      state().addChatMessage('assistant', result.reply, answeredAt);
      state().applyCoachResult(
        { suggestedTargetGapMins: result.suggested_target_gap_mins, newMemoryNote: result.new_memory_note_to_save },
        answeredAt,
      );
      return { ok: true, reply: result.reply };
    } catch (error) {
      return describeError(error);
    }
  }

  /**
   * Pipeline A. Call it after a cigarette was logged, a craving was crushed
   * or the user sent a chat message. A chat message is added to the
   * conversation right away, before the AI answers.
   */
  function triggerSmokeCoachAI(event: CoachEvent): Promise<CoachOutcome> {
    if (event.type === 'USER_CHAT_MESSAGE') {
      const text = event.text.trim();
      if (!text) {
        return Promise.resolve({ ok: false, reason: 'failed', message: 'The message is empty.' });
      }
      state().addChatMessage('user', text, deps.now());
    }
    waitingCoachCalls += 1;
    state().setCoachLoading(true);
    const run = coachQueue.then(() => runCoach(event));
    coachQueue = run.then(
      () => undefined,
      () => undefined,
    );
    return run.finally(() => {
      waitingCoachCalls -= 1;
      if (waitingCoachCalls === 0) {
        state().setCoachLoading(false);
      }
    });
  }

  async function runBrainDumpAi(dumpId: string): Promise<boolean> {
    const dump = state().brainDumps[dumpId];
    if (!dump || dump.ai_status === 'done') {
      return false;
    }
    const apiKey = await deps.getApiKey();
    if (!apiKey) {
      return false;
    }
    state().adjustProcessingDumps(1);
    try {
      const raw = await deps.requestJson(
        {
          system: BRAIN_DUMP_SYSTEM_PROMPT,
          user: buildBrainDumpUserPrompt(dump.raw_transcript, new Date(dump.created_at)),
          schema: BRAIN_DUMP_SCHEMA,
          schemaName: 'brain_dump',
          temperature: 0.2,
        },
        { apiKey },
      );
      const result = parseBrainDumpResult(raw, () => createId('task'));
      state().completeBrainDump(dumpId, result);
      return true;
    } catch {
      return false;
    } finally {
      state().adjustProcessingDumps(-1);
    }
  }

  /**
   * Pipeline B. Saves the transcript on the phone at once (as "pending"), then
   * asks the AI. If the AI cannot be reached the dump stays pending and
   * `retryPendingBrainDumps` picks it up later, so no thought is lost.
   * Returns the saved dump, or `null` for an empty transcript.
   */
  async function processBrainDumpAI(rawTranscript: string): Promise<BrainDumpDoc | null> {
    const transcript = rawTranscript.trim();
    if (!transcript) {
      return null;
    }
    const now = deps.now();
    const dump: BrainDumpDoc = {
      id: createId('dump'),
      logical_date: state().ensureToday(now),
      created_at: toLocalIsoString(now),
      raw_transcript: transcript,
      ai_processed: buildPlaceholderBrainDumpResult(transcript),
      ai_status: 'pending',
    };
    state().addBrainDump(dump);
    await runBrainDumpAi(dump.id);
    return state().brainDumps[dump.id] ?? dump;
  }

  /** Sends brain dumps that are still pending to the AI, oldest first. Returns how many were processed. */
  async function retryPendingBrainDumps(): Promise<number> {
    const pending = Object.values(state().brainDumps)
      .filter((dump) => dump.ai_status === 'pending')
      .sort((a, b) => Date.parse(a.created_at) - Date.parse(b.created_at))
      .slice(0, MAX_PENDING_PER_RETRY);
    let processed = 0;
    for (const dump of pending) {
      if (await runBrainDumpAi(dump.id)) {
        processed += 1;
      } else {
        break;
      }
    }
    return processed;
  }

  /**
   * Pipeline C. Builds the briefing for the 7 finished days before today and
   * saves it under its week id (a second run in the same week replaces the first).
   */
  async function generateRealTalkAI(): Promise<BriefingOutcome> {
    const now = deps.now();
    const today = state().ensureToday(now);
    const current = state();
    const period = getBriefingPeriod(today);
    const dumps = Object.values(current.brainDumps);
    const stats = computeRealTalkStats({ logs: current.dailyLogs, dumps, period });
    if (stats.days_recorded === 0) {
      return { ok: false, reason: 'no_data', message: NO_DATA_MESSAGE };
    }
    const apiKey = await deps.getApiKey();
    if (!apiKey) {
      return { ok: false, reason: 'no_key', message: NO_KEY_MESSAGE };
    }
    const carryoverTasks = collectCarryoverTasks(dumps, period);

    current.setGeneratingBriefing(true);
    try {
      const raw = await deps.requestJson(
        {
          system: REAL_TALK_SYSTEM_PROMPT,
          user: buildRealTalkUserPrompt({
            memory: current.rollingMemory,
            period,
            days: buildWeekRows(current.dailyLogs, dumps, period),
            stats,
            settings: current.settings,
            openTasks: carryoverTasks,
          }),
          schema: REAL_TALK_SCHEMA,
          schemaName: 'real_talk_briefing',
          temperature: 0.6,
        },
        { apiKey },
      );
      const texts = parseRealTalkTexts(raw);
      const briefing: RealTalkBriefingDoc = {
        week_id: period.weekId,
        generated_at: toLocalIsoString(deps.now()),
        period_start: period.start,
        period_end: period.end,
        ...texts,
        carryover_tasks: carryoverTasks,
        stats,
      };
      state().saveBriefing(briefing);
      return { ok: true, briefing };
    } catch (error) {
      return describeError(error);
    } finally {
      state().setGeneratingBriefing(false);
    }
  }

  return { triggerSmokeCoachAI, processBrainDumpAI, retryPendingBrainDumps, generateRealTalkAI };
}

export type AiPipelines = ReturnType<typeof createAiPipelines>;
