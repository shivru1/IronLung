/**
 * The AI service the app uses: the three pipelines wired to the real store,
 * the saved API key and the network.
 *
 * - `triggerSmokeCoachAI(event)`   Pipeline A: Smoke Coach
 * - `processBrainDumpAI(text)`     Pipeline B: Voice Brain Dump Processor
 * - `generateRealTalkAI()`         Pipeline C: Real Talk Weekly Synthesizer
 *
 * The logic lives in `aiPipelines.ts`, the prompts in `aiPrompts.ts`, the
 * JSON contracts in `aiContracts.ts` and the provider calls in `llmClient.ts`.
 */

import { APP_CONFIG } from '../config/appConfig';
import { createMmkvKv } from '../storage/mmkvKv';
import { loadApiKey } from '../storage/secureKey';
import { useAppStore } from '../store/useAppStore';
import { createAiPipelines } from './aiPipelines';
import { detectProvider, requestJson } from './llmClient';
import type { LlmClientOptions, LlmJsonRequest } from './llmClient';
import { createModelMemory } from './modelMemory';

const MS_PER_HOUR = 60 * 60 * 1000;

const modelMemory = createModelMemory(createMmkvKv('ironlung-ai'), APP_CONFIG.ai.rememberModelHours * MS_PER_HOUR);

/** `requestJson` that starts with the model that answered last and remembers the one that answers now. */
function requestJsonWithMemory(request: LlmJsonRequest, options: LlmClientOptions): Promise<unknown> {
  const mainModel = APP_CONFIG.ai.models[detectProvider(options.apiKey ?? '')];
  return requestJson(request, {
    ...options,
    preferredModel: modelMemory.get(),
    onModelAnswered: (model) => modelMemory.remember(model, mainModel),
  });
}

const pipelines = createAiPipelines({
  store: useAppStore,
  getApiKey: loadApiKey,
  requestJson: requestJsonWithMemory,
  now: () => new Date(),
});

export const { triggerSmokeCoachAI, processBrainDumpAI, retryPendingBrainDumps, generateRealTalkAI } = pipelines;

export type { AiFailure, BriefingOutcome, CoachOutcome } from './aiPipelines';
export type { CoachEvent } from './aiPrompts';
