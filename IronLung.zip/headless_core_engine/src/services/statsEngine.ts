/**
 * Numbers for the Stats screen and the charts. Pure functions only.
 *
 * The Stats screen is a live view: its windows end today and include today's
 * cigarettes so far. The one exception is the average per day, which only
 * uses finished days so that a half-finished day does not pull it down.
 */

import type { ChartPoint, DailyLogDoc, TriggerType } from '../types/schema';
import { addDaysToDateString, getDayOfMonth, getLogicalDateRange, getWeekdayLabel } from '../utils/dateUtils';
import { formatDangerWindow, getWindowHours, getWindowSharePercent, parseDangerWindow } from './dangerWindow';
import type { DangerWindow } from './dangerWindow';
import {
  buildHourlyHistogram,
  calculateAverageDailyCount,
  countTriggers,
  findPeakDangerWindow,
  selectLogsInWindow,
  SHORT_WINDOW_DAYS,
} from './rollupEngine';
import type { DailyLogs } from './smokeEngine';

const MS_PER_MINUTE = 60 * 1000;

// ---------------------------------------------------------------------------
// Daily chart
// ---------------------------------------------------------------------------

/** One day on the daily chart. Days without a record keep their place with `null` values. */
export interface ChartSlot {
  date: string;
  /** `MON` ... `SUN`. */
  weekday: string;
  dayOfMonth: number;
  count: number | null;
  target: number | null;
  rolling7dAvg: number | null;
  cravingsCrushed: number | null;
  isToday: boolean;
}

/**
 * Builds the slots for the `numDays` days ending today. Finished days come
 * straight from the pre-computed chart cache; today is added live.
 */
export function buildChartSlots(input: {
  chartCache: readonly ChartPoint[];
  todayLog: DailyLogDoc | null | undefined;
  todayDate: string;
  numDays: number;
}): ChartSlot[] {
  const cacheByDate = new Map<string, ChartPoint>();
  for (const point of input.chartCache) {
    cacheByDate.set(point.date, point);
  }

  return getLogicalDateRange(input.todayDate, input.numDays).map((date) => {
    const base = { date, weekday: getWeekdayLabel(date), dayOfMonth: getDayOfMonth(date) };
    if (date === input.todayDate) {
      const today = input.todayLog;
      if (!today) {
        return { ...base, count: null, target: null, rolling7dAvg: null, cravingsCrushed: null, isToday: true };
      }
      const earlierCounts = getLogicalDateRange(addDaysToDateString(date, -1), SHORT_WINDOW_DAYS - 1)
        .map((d) => cacheByDate.get(d)?.count)
        .filter((count): count is number => count !== undefined);
      const counts = [...earlierCounts, today.total_count];
      return {
        ...base,
        count: today.total_count,
        target: today.daily_target,
        rolling7dAvg: counts.reduce((sum, count) => sum + count, 0) / counts.length,
        cravingsCrushed: today.cravings_crushed,
        isToday: true,
      };
    }
    const point = cacheByDate.get(date);
    return {
      ...base,
      count: point ? point.count : null,
      target: point ? point.target : null,
      rolling7dAvg: point ? point.rolling_7d_avg : null,
      cravingsCrushed: point ? point.cravings_crushed : null,
      isToday: false,
    };
  });
}

/** How a day's bar is coloured: at or under target, one over, or further over. */
export type BarTone = 'under' | 'over' | 'wayOver';

export function getBarTone(count: number, target: number): BarTone {
  if (count <= target) {
    return 'under';
  }
  return count === target + 1 ? 'over' : 'wayOver';
}

// ---------------------------------------------------------------------------
// Headline numbers
// ---------------------------------------------------------------------------

export interface StatsKpis {
  /** Average cigarettes per day over the finished days of the range. */
  avgPerDay: number | null;
  /** Change of that average against the same number of days before. Negative means fewer. */
  avgDelta: number | null;
  /** Longest wait between two cigarettes of the same day in the range (today included). */
  longestGapMins: number | null;
  /** Timestamp of the cigarette that ended the longest wait. */
  longestGapEndedAt: string | null;
  /** Rupees saved on every recorded day, today included. */
  totalSavedInr: number;
}

function findLongestGap(logs: readonly DailyLogDoc[]): { mins: number; endedAt: string } | null {
  let best: { mins: number; endedAt: string } | null = null;
  for (const log of logs) {
    const entries = [...log.smoke_entries].sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp));
    for (let index = 1; index < entries.length; index += 1) {
      const current = entries[index];
      const previous = entries[index - 1];
      if (!current || !previous) {
        continue;
      }
      const mins = Math.floor((Date.parse(current.timestamp) - Date.parse(previous.timestamp)) / MS_PER_MINUTE);
      if (best === null || mins > best.mins) {
        best = { mins, endedAt: current.timestamp };
      }
    }
  }
  return best;
}

export function computeStatsKpis(input: { logs: DailyLogs; todayDate: string; rangeDays: number }): StatsKpis {
  const all = Object.values(input.logs);
  const yesterday = addDaysToDateString(input.todayDate, -1);
  const current = selectLogsInWindow(all, yesterday, input.rangeDays);
  const before = selectLogsInWindow(all, addDaysToDateString(yesterday, -input.rangeDays), input.rangeDays);
  const avgPerDay = calculateAverageDailyCount(current);
  const avgBefore = calculateAverageDailyCount(before);
  const longest = findLongestGap(selectLogsInWindow(all, input.todayDate, input.rangeDays));

  return {
    avgPerDay,
    avgDelta: avgPerDay !== null && avgBefore !== null ? avgPerDay - avgBefore : null,
    longestGapMins: longest ? longest.mins : null,
    longestGapEndedAt: longest ? longest.endedAt : null,
    totalSavedInr: all.reduce((sum, log) => sum + log.money_saved_inr, 0),
  };
}

// ---------------------------------------------------------------------------
// Triggers
// ---------------------------------------------------------------------------

export interface TriggerRank {
  trigger: TriggerType;
  count: number;
  /** Share of all cigarettes in whole percent. */
  percent: number;
}

/**
 * Sorts triggers from most to least used and leaves out the unused ones.
 * Triggers used equally often keep the order they have in `counts`.
 * When nothing was smoked, every trigger in `counts` is returned with 0 so
 * the list is never empty.
 */
export function rankTriggers(counts: Readonly<Record<TriggerType, number>>): TriggerRank[] {
  const entries = Object.entries(counts);
  const total = entries.reduce((sum, [, count]) => sum + count, 0);
  if (total === 0) {
    return entries.map(([trigger]) => ({ trigger, count: 0, percent: 0 }));
  }
  return entries
    .map(([trigger, count], order) => ({ trigger, count, order }))
    .filter((item) => item.count > 0)
    .sort((a, b) => b.count - a.count || a.order - b.order)
    .map(({ trigger, count }) => ({ trigger, count, percent: Math.round((count / total) * 100) }));
}

/** Trigger ranking for the `rangeDays` days ending today. */
export function rankTriggersInRange(logs: DailyLogs, todayDate: string, rangeDays: number): TriggerRank[] {
  return rankTriggers(countTriggers(selectLogsInWindow(Object.values(logs), todayDate, rangeDays)));
}

// ---------------------------------------------------------------------------
// Hours of the day
// ---------------------------------------------------------------------------

export interface DangerBar {
  /** Clock hour 0-23. */
  hour: number;
  count: number;
  /** Count relative to the busiest hour, from 0 to 1. */
  ratio: number;
  inWindow: boolean;
}

export interface DangerProfile {
  bars: DangerBar[];
  window: DangerWindow | null;
  /** `15:00–18:00`, or `null` when nothing was smoked. */
  windowLabel: string | null;
  /** `15–18` for the axis. */
  windowShortLabel: string | null;
  /** Share of all cigarettes inside the window, in whole percent. */
  sharePercent: number | null;
  totalSmokes: number;
}

/** Cigarettes per clock hour and the busiest 3 hours, for the `rangeDays` days ending today. */
export function buildDangerProfile(logs: DailyLogs, todayDate: string, rangeDays: number): DangerProfile {
  const histogram = buildHourlyHistogram(selectLogsInWindow(Object.values(logs), todayDate, rangeDays));
  const window = parseDangerWindow(findPeakDangerWindow(histogram));
  const windowHours = window ? getWindowHours(window) : [];
  const busiest = Math.max(0, ...histogram);
  return {
    bars: histogram.map((count, hour) => ({
      hour,
      count,
      ratio: busiest === 0 ? 0 : count / busiest,
      inWindow: windowHours.includes(hour),
    })),
    window,
    windowLabel: window ? formatDangerWindow(window, 'tight') : null,
    windowShortLabel: window ? formatDangerWindow(window, 'hours') : null,
    sharePercent: window ? getWindowSharePercent(histogram, window) : null,
    totalSmokes: histogram.reduce((sum, count) => sum + count, 0),
  };
}
