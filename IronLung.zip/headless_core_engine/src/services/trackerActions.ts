/**
 * The tracker's three actions with everything that goes with them: the data
 * change, the haptic, the notification update and the Smoke Coach.
 *
 * Both the screens (through `useSmokeTracker`) and the lock-screen buttons go
 * through these functions, so a tap behaves the same wherever it comes from.
 */

import { selectTodayLog } from '../store/createAppStore';
import { useAppStore } from '../store/useAppStore';
import type { SmokeEntry, TriggerType } from '../types/schema';
import { triggerSmokeCoachAI } from './aiService';
import {
  defineNotificationActionTask,
  setNotificationActionHandlers,
  showTrackerNotification,
  triggerChipSelectHaptic,
  triggerCravingCrushedHaptic,
  triggerSmokeLoggedHaptic,
} from './nativeAndroidService';
import { buildTrackerNotificationText } from './notificationContent';
import { findLastSmoke } from './smokeEngine';

function ignore(): void {
  // Notifications and the coach are extras; a failure there must not undo the logged action.
}

/** Rewrites the tracker notification from the current data. `force` re-posts it even if the text is unchanged. */
export function refreshTrackerNotification(force = false): void {
  const state = useAppStore.getState();
  const lastSmoke = findLastSmoke(state.dailyLogs);
  const text = buildTrackerNotificationText(selectTodayLog(state), lastSmoke ? lastSmoke.entry : null);
  showTrackerNotification(text, force).catch(ignore);
}

/** Logs a cigarette, buzzes, updates the notification and asks the coach to react. */
export function performLogSmoke(input: { trigger?: TriggerType; backdateMins?: number } = {}): SmokeEntry {
  const entry = useAppStore.getState().logSmoke(input);
  triggerSmokeLoggedHaptic();
  refreshTrackerNotification();
  triggerSmokeCoachAI({ type: 'SMOKE_LOGGED', entry }).catch(ignore);
  return entry;
}

/** Removes the most recent cigarette. Returns it, or `null` when there was nothing recent to undo. */
export function performUndoLastSmoke(): SmokeEntry | null {
  const removed = useAppStore.getState().undoLastSmoke();
  if (removed) {
    triggerChipSelectHaptic();
    refreshTrackerNotification();
  }
  return removed;
}

/** Counts a crushed craving, buzzes, updates the notification and asks the coach to react. */
export function performCrushCraving(): void {
  useAppStore.getState().crushCraving();
  triggerCravingCrushedHaptic();
  refreshTrackerNotification();
  triggerSmokeCoachAI({ type: 'CRAVING_CRUSHED' }).catch(ignore);
}

/**
 * Connects the two lock-screen buttons to the actions above. Called from
 * `index.ts` when the bundle starts, which also covers Android waking the app
 * in the background for a button tap.
 */
export function registerNotificationActions(): void {
  defineNotificationActionTask();
  setNotificationActionHandlers({
    onLogSmoke: () => {
      performLogSmoke();
    },
    onCrushCraving: performCrushCraving,
  });
}
