/**
 * Rules for logging cigarettes and cravings.
 *
 * Everything here is a pure function: it takes the daily logs (or one day) and
 * returns new objects without changing its input and without reading the
 * clock, storage or network. The store calls these and saves the result.
 */

import { APP_CONFIG } from '../config/appConfig';
import { CHAT_BUFFER_LIMIT, MAX_MEMORY_NOTES } from '../types/schema';
import type { ChatMessage, DailyLogDoc, SettingsDoc, SmokeEntry, TriggerType } from '../types/schema';
import { getLogicalDateString, toLocalIsoString } from '../utils/dateUtils';

/** All daily logs, keyed by logical date. */
export type DailyLogs = Readonly<Record<string, DailyLogDoc>>;

/** Values a new day starts with. */
export interface DayDefaults {
  dailyTarget: number;
  dailyBaseline: number;
  costPerCigInr: number;
  activeTargetGapMins: number;
}

export interface SmokeLocation {
  entry: SmokeEntry;
  logicalDate: string;
}

const MS_PER_MINUTE = 60 * 1000;
/** Headlines kept per day for the coach. Older ones are dropped first. */
const MAX_HEADLINES_PER_DAY = 12;

function toMs(timestamp: string): number {
  return Date.parse(timestamp);
}

function sortByTime(entries: readonly SmokeEntry[]): SmokeEntry[] {
  return [...entries].sort((a, b) => toMs(a.timestamp) - toMs(b.timestamp));
}

// ---------------------------------------------------------------------------
// Targets and money
// ---------------------------------------------------------------------------

/** Keeps a wait target inside the allowed range and on a whole minute. */
export function clampTargetGapMins(mins: number): number {
  const { minMins, maxMins } = APP_CONFIG.targetGap;
  if (!Number.isFinite(mins)) {
    return minMins;
  }
  return Math.min(maxMins, Math.max(minMins, Math.round(mins)));
}

/**
 * The wait between cigarettes that spreads `dailyTarget` evenly over the
 * waking day, rounded to 5 minutes. A target of 8 gives 120 minutes.
 */
export function defaultTargetGapMins(dailyTarget: number): number {
  if (dailyTarget <= 0) {
    return APP_CONFIG.targetGap.maxMins;
  }
  const even = APP_CONFIG.targetGap.wakingMinutes / dailyTarget;
  return clampTargetGapMins(Math.round(even / 5) * 5);
}

/**
 * Rupees saved in a day.
 * - While the day is running: every crushed craving saves one cigarette.
 * - Once the day is over: the larger of that and the cigarettes smoked under
 *   the baseline, so the same cigarette is never counted twice.
 */
export function calculateMoneySaved(input: {
  cravingsCrushed: number;
  smokeCount: number;
  dailyBaseline: number;
  costPerCigInr: number;
  isFinal: boolean;
}): number {
  const fromCravings = input.cravingsCrushed * input.costPerCigInr;
  if (!input.isFinal) {
    return fromCravings;
  }
  const underBaseline = Math.max(0, input.dailyBaseline - input.smokeCount) * input.costPerCigInr;
  return Math.max(fromCravings, underBaseline);
}

function moneyFor(log: DailyLogDoc, smokeCount: number, cravingsCrushed: number): number {
  return calculateMoneySaved({
    cravingsCrushed,
    smokeCount,
    dailyBaseline: log.daily_baseline,
    costPerCigInr: log.cost_per_cig_inr,
    isFinal: log.is_finalized,
  });
}

// ---------------------------------------------------------------------------
// Days
// ---------------------------------------------------------------------------

export function createDailyLog(logicalDate: string, defaults: DayDefaults): DailyLogDoc {
  return {
    logical_date: logicalDate,
    total_count: 0,
    daily_target: defaults.dailyTarget,
    daily_baseline: defaults.dailyBaseline,
    cost_per_cig_inr: defaults.costPerCigInr,
    smoke_entries: [],
    cravings_crushed: 0,
    money_saved_inr: 0,
    active_target_gap_mins: clampTargetGapMins(defaults.activeTargetGapMins),
    todays_brain_dump_headlines: [],
    chat_buffer: [],
    is_finalized: false,
  };
}

function withEntries(log: DailyLogDoc, entries: SmokeEntry[]): DailyLogDoc {
  return {
    ...log,
    smoke_entries: entries,
    total_count: entries.length,
    money_saved_inr: moneyFor(log, entries.length, log.cravings_crushed),
  };
}

/** Closes a day: from now on its money saved uses the end-of-day rule. */
export function finalizeDay(log: DailyLogDoc): DailyLogDoc {
  const closed = { ...log, is_finalized: true };
  return { ...closed, money_saved_inr: moneyFor(closed, closed.total_count, closed.cravings_crushed) };
}

/** Copies changed settings into a day that is still running. Finished days are left alone. */
export function applySettingsToDay(log: DailyLogDoc, settings: SettingsDoc): DailyLogDoc {
  if (log.is_finalized) {
    return log;
  }
  const updated = {
    ...log,
    daily_target: settings.daily_target,
    daily_baseline: settings.daily_baseline,
    cost_per_cig_inr: settings.cost_per_cig_inr,
  };
  return { ...updated, money_saved_inr: moneyFor(updated, updated.total_count, updated.cravings_crushed) };
}

/** Counts one craving the user did not give in to. */
export function addCravingCrushed(log: DailyLogDoc): DailyLogDoc {
  const cravingsCrushed = log.cravings_crushed + 1;
  return {
    ...log,
    cravings_crushed: cravingsCrushed,
    money_saved_inr: moneyFor(log, log.total_count, cravingsCrushed),
  };
}

// ---------------------------------------------------------------------------
// Cigarettes
// ---------------------------------------------------------------------------

/**
 * The most recent cigarette on record, or `null` when there is none.
 * With `atOrBeforeMs` only cigarettes up to that moment count.
 */
export function findLastSmoke(logs: DailyLogs, atOrBeforeMs?: number): SmokeLocation | null {
  const dates = Object.keys(logs).sort().reverse();
  for (const date of dates) {
    const entries = sortByTime(logs[date]?.smoke_entries ?? []).reverse();
    for (const entry of entries) {
      if (atOrBeforeMs === undefined || toMs(entry.timestamp) <= atOrBeforeMs) {
        return { entry, logicalDate: date };
      }
    }
  }
  return null;
}

/**
 * Rewrites `gap_from_previous_mins` for every cigarette on `date` and for the
 * first cigarette of the next day that has any, because that one is measured
 * from `date`'s last cigarette.
 */
export function recomputeGaps(logs: DailyLogs, date: string): DailyLogs {
  const dates = Object.keys(logs).sort();
  const earlier = dates.filter((d) => d < date).reverse();
  const later = dates.filter((d) => d > date);

  let previousMs: number | null = null;
  for (const d of earlier) {
    const entries = sortByTime(logs[d]?.smoke_entries ?? []);
    const last = entries[entries.length - 1];
    if (last) {
      previousMs = toMs(last.timestamp);
      break;
    }
  }

  const gapFrom = (entry: SmokeEntry): SmokeEntry => {
    const ms = toMs(entry.timestamp);
    const gap = previousMs === null ? null : Math.max(0, Math.floor((ms - previousMs) / MS_PER_MINUTE));
    previousMs = ms;
    return entry.gap_from_previous_mins === gap ? entry : { ...entry, gap_from_previous_mins: gap };
  };

  const result: Record<string, DailyLogDoc> = { ...logs };
  const day = logs[date];
  if (day) {
    result[date] = withEntries(day, sortByTime(day.smoke_entries).map(gapFrom));
  }
  for (const d of later) {
    const next = logs[d];
    if (next && next.smoke_entries.length > 0) {
      const sorted = sortByTime(next.smoke_entries);
      const first = sorted[0];
      if (first) {
        result[d] = withEntries(next, [gapFrom(first), ...sorted.slice(1)]);
      }
      break;
    }
  }
  return result;
}

/**
 * Adds one cigarette smoked at `smokedAt`. The cigarette is filed under the
 * logical day it was smoked on, which can be an earlier day when it was
 * backdated past 04:00.
 */
export function addSmoke(
  logs: DailyLogs,
  params: {
    id: string;
    trigger: TriggerType;
    smokedAt: Date;
    backdatedMins: number;
    /** Starting values for the day, used when it has no log yet. */
    defaultsFor: (logicalDate: string) => DayDefaults;
  },
): { logs: DailyLogs; entry: SmokeEntry; logicalDate: string } {
  const logicalDate = getLogicalDateString(params.smokedAt);
  const day = logs[logicalDate] ?? createDailyLog(logicalDate, params.defaultsFor(logicalDate));
  const draft: SmokeEntry = {
    id: params.id,
    timestamp: toLocalIsoString(params.smokedAt),
    trigger: params.trigger,
    gap_from_previous_mins: null,
    backdated_mins: Math.max(0, Math.round(params.backdatedMins)),
  };
  const withNew: DailyLogs = { ...logs, [logicalDate]: withEntries(day, [...day.smoke_entries, draft]) };
  const updated = recomputeGaps(withNew, logicalDate);
  const entry = updated[logicalDate]?.smoke_entries.find((e) => e.id === params.id) ?? draft;
  return { logs: updated, entry, logicalDate };
}

/** Removes the most recent cigarette on record. Returns `null` when there is none. */
export function removeLastSmoke(
  logs: DailyLogs,
): { logs: DailyLogs; removed: SmokeEntry; logicalDate: string } | null {
  const last = findLastSmoke(logs);
  if (!last) {
    return null;
  }
  const day = logs[last.logicalDate];
  if (!day) {
    return null;
  }
  const remaining = day.smoke_entries.filter((entry) => entry.id !== last.entry.id);
  const withoutLast: DailyLogs = { ...logs, [last.logicalDate]: withEntries(day, remaining) };
  return {
    logs: recomputeGaps(withoutLast, last.logicalDate),
    removed: last.entry,
    logicalDate: last.logicalDate,
  };
}

/** Changes the trigger of the most recent cigarette. Returns `null` when there is none. */
export function retagLastSmoke(
  logs: DailyLogs,
  trigger: TriggerType,
): { logs: DailyLogs; entry: SmokeEntry; logicalDate: string } | null {
  const last = findLastSmoke(logs);
  const day = last ? logs[last.logicalDate] : undefined;
  if (!last || !day) {
    return null;
  }
  const entry: SmokeEntry = { ...last.entry, trigger };
  const entries = day.smoke_entries.map((e) => (e.id === entry.id ? entry : e));
  return {
    logs: { ...logs, [last.logicalDate]: { ...day, smoke_entries: entries } },
    entry,
    logicalDate: last.logicalDate,
  };
}

/** Whole minutes since `entry` was smoked, or `null` when there is no entry. */
export function getElapsedMins(entry: SmokeEntry | null, nowMs: number): number | null {
  if (!entry) {
    return null;
  }
  return Math.max(0, Math.floor((nowMs - toMs(entry.timestamp)) / MS_PER_MINUTE));
}

/** How far the current wait is toward the target, from 0 to 100. */
export function getGapProgressPercent(elapsedMins: number | null, targetGapMins: number): number {
  if (elapsedMins === null || targetGapMins <= 0) {
    return 0;
  }
  return Math.min(100, Math.max(0, (elapsedMins / targetGapMins) * 100));
}

// ---------------------------------------------------------------------------
// Coach context kept on the day
// ---------------------------------------------------------------------------

/** Adds a chat message and keeps only the newest `CHAT_BUFFER_LIMIT`. */
export function appendChatMessage(log: DailyLogDoc, message: ChatMessage): DailyLogDoc {
  return { ...log, chat_buffer: [...log.chat_buffer, message].slice(-CHAT_BUFFER_LIMIT) };
}

/** Remembers a brain dump headline on the day so the coach can refer to it. */
export function addBrainDumpHeadline(log: DailyLogDoc, headline: string): DailyLogDoc {
  const clean = headline.trim();
  if (!clean) {
    return log;
  }
  return {
    ...log,
    todays_brain_dump_headlines: [...log.todays_brain_dump_headlines, clean].slice(-MAX_HEADLINES_PER_DAY),
  };
}

/** Forgets one copy of a headline, used when its brain dump is deleted. */
export function removeBrainDumpHeadline(log: DailyLogDoc, headline: string): DailyLogDoc {
  const index = log.todays_brain_dump_headlines.indexOf(headline.trim());
  if (index < 0) {
    return log;
  }
  const headlines = [...log.todays_brain_dump_headlines];
  headlines.splice(index, 1);
  return { ...log, todays_brain_dump_headlines: headlines };
}

/**
 * Adds a note the AI learned about the user. A note that is already there is
 * not added twice, and only the newest `MAX_MEMORY_NOTES` are kept.
 */
export function appendMemoryNote(notes: readonly string[], note: string | null | undefined): string[] {
  const clean = (note ?? '').trim();
  if (!clean) {
    return [...notes];
  }
  const alreadyKnown = notes.some((existing) => existing.trim().toLowerCase() === clean.toLowerCase());
  if (alreadyKnown) {
    return [...notes];
  }
  return [...notes, clean].slice(-MAX_MEMORY_NOTES);
}
