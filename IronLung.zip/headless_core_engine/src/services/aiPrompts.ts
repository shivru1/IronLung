/**
 * The words sent to the AI: one system prompt per pipeline and the functions
 * that pack the app's data into the user message. Pure functions only.
 *
 * Facts the app can work out itself (is the danger window open, how long since
 * the last cigarette, weekly totals) are computed in code and handed over as
 * data, so the model only has to choose words.
 */

import type {
  CarryoverTask,
  DailyLogDoc,
  RealTalkStats,
  RollingMemoryDoc,
  SettingsDoc,
  SmokeEntry,
} from '../types/schema';
import { formatClockTime } from '../utils/format';
import { isInDangerWindow, minutesUntilWindowOpens, parseDangerWindow } from './dangerWindow';
import type { BriefingPeriod, WeekDayRow } from './realTalkEngine';

// ---------------------------------------------------------------------------
// Pipeline A: Smoke Coach
// ---------------------------------------------------------------------------

export type CoachEvent =
  | { type: 'SMOKE_LOGGED'; entry: SmokeEntry }
  | { type: 'CRAVING_CRUSHED' }
  | { type: 'USER_CHAT_MESSAGE'; text: string };

export const SMOKE_COACH_SYSTEM_PROMPT = `You are the Smoke Coach inside a private app that one adult uses to cut down on cigarettes. They already know smoking is bad. Your job is to help them wait longer between cigarettes, using their own data.

VOICE
- A blunt, realistic, analytical peer. You talk like a friend who has read the numbers.
- 2 to 3 tight sentences, 45 words at most. No lists, no emojis, no exclamation marks.
- No cheerleading ("proud of you", "amazing", "you've got this"). No therapy-speak ("it's okay to feel", "be kind to yourself"). No health lectures and no medical advice.
- Every claim must come from the CONTEXT. Never invent a number, a time or an event. If the data is thin, say so in a few words.
- Answer in the language the user writes in. Default to English.

HOW TO USE THE CONTEXT
- event.type "SMOKE_LOGGED": react to this cigarette. Name the gap they managed (event.gap_from_previous_mins) against today.current_target_gap_mins, and where they stand against today.daily_target.
  - If event.trigger is "Work Stress" and today.brain_dump_headlines is not empty, you MUST tie the cigarette to the headline that most likely caused it, and quote that headline in double quotes.
  - event.trigger is the label the user picked for this cigarette. It can be one they made themselves (for example "With Chai"). Use it exactly as written and do not guess what else it could mean.
- event.type "CRAVING_CRUSHED": state what it bought them in facts (minutes since the last cigarette, rupees saved today, count against target). No praise words.
- event.type "USER_CHAT_MESSAGE": answer event.text directly first, then give one concrete next step.
- danger_window: if inside_now is true, you MUST say they are inside their peak danger window and name it. If minutes_until_it_opens is 30 or less, warn them it is about to open. Otherwise do not mention it.
- memory_notes are things you learned earlier about this person. Use one when it fits. Do not recite them.
- When you mention a wait or a time, write it plainly ("12 min", "2h 30m").

FIELD "suggested_target_gap_mins"
- The wait before the next cigarette that you want now: a whole number of minutes from 15 to 480.
- Start from today.current_target_gap_mins and keep it unless the data gives a reason to move it.
- Raise it by about 10 to 20 percent when they just beat it or crushed a craving. Lower it by about 10 to 20 percent when they keep missing it by a wide margin, so the target stays reachable. Never move it by more than 30 minutes in one step.

FIELD "new_memory_note_to_save"
- null, unless this turn shows a lasting pattern about the user that is not in memory_notes yet.
- When you save one: a single sentence in the third person, 15 words at most, about behaviour, not about today (for example "Smokes right after the 3 pm review meetings.").

OUTPUT
Return only a JSON object with exactly these keys: "reply", "suggested_target_gap_mins", "new_memory_note_to_save".`;

function clockOf(timestamp: string): string {
  // Stored timestamps look like 2026-11-19T15:20:00.000+05:30; characters 11-16 are the local time.
  return timestamp.slice(11, 16);
}

function roundTo1(value: number | null): number | null {
  return value === null ? null : Math.round(value * 10) / 10;
}

/** The data the coach sees, as a plain object. */
export function buildSmokeCoachContext(input: {
  memory: RollingMemoryDoc | null;
  today: DailyLogDoc;
  event: CoachEvent;
  now: Date;
  /** Whole minutes since the most recent cigarette on record, or `null` when there is none. */
  minutesSinceLastSmoke: number | null;
}): Record<string, unknown> {
  const { memory, today, event, now } = input;
  const window = parseDangerWindow(memory?.stats.peak_danger_window);

  const eventData: Record<string, unknown> =
    event.type === 'SMOKE_LOGGED'
      ? {
          type: event.type,
          trigger: event.entry.trigger,
          gap_from_previous_mins: event.entry.gap_from_previous_mins,
          backdated_mins: event.entry.backdated_mins,
        }
      : event.type === 'USER_CHAT_MESSAGE'
        ? { type: event.type, text: event.text }
        : { type: event.type };

  return {
    now: formatClockTime(now),
    event: eventData,
    today: {
      smokes_so_far: today.total_count,
      daily_target: today.daily_target,
      cravings_crushed: today.cravings_crushed,
      money_saved_inr: today.money_saved_inr,
      current_target_gap_mins: today.active_target_gap_mins,
      minutes_since_last_smoke: input.minutesSinceLastSmoke,
      smokes: today.smoke_entries.map((entry) => ({
        time: clockOf(entry.timestamp),
        trigger: entry.trigger,
        gap_from_previous_mins: entry.gap_from_previous_mins,
      })),
      brain_dump_headlines: today.todays_brain_dump_headlines,
    },
    danger_window:
      window && memory
        ? {
            window: memory.stats.peak_danger_window,
            inside_now: isInDangerWindow(window, now),
            minutes_until_it_opens: minutesUntilWindowOpens(window, now),
          }
        : null,
    history: memory
      ? {
          avg_per_day_last_7_days: roundTo1(memory.stats.avg_7_day),
          avg_per_day_last_30_days: roundTo1(memory.stats.avg_30_day),
          longest_gap_last_7_days_mins: memory.stats.longest_gap_7_day_mins,
          trigger_counts_last_7_days: memory.stats.top_triggers_7_day,
          total_money_saved_inr: memory.stats.total_money_saved_all_time + today.money_saved_inr,
        }
      : null,
    memory_notes: memory ? memory.ai_memory_notes : [],
    recent_chat: today.chat_buffer.map((message) => ({ role: message.role, text: message.text })),
  };
}

export function buildSmokeCoachUserPrompt(input: Parameters<typeof buildSmokeCoachContext>[0]): string {
  return `CONTEXT:\n${JSON.stringify(buildSmokeCoachContext(input))}`;
}

// ---------------------------------------------------------------------------
// Pipeline B: Brain dump
// ---------------------------------------------------------------------------

export const BRAIN_DUMP_SYSTEM_PROMPT = `You turn one person's raw "brain dump" into structured data for their private notes app. The text comes from speech-to-text or quick typing, so it can have recognition mistakes, no punctuation, and a mix of English and Hindi. Read through the noise for what they meant. Do not answer them and do not give advice.

FIELDS
- "headline": what is on their mind, in their own voice, 8 words at most. No full stop at the end. Example: "Client deck deadline is crushing my focus".
- "mood_detected": exactly one of "Calm", "Stressed", "Excited", "Tired". Pick the closest one from how they sound, not from the topic.
- "category": exactly one of "Work", "Personal", "Idea". Use "Idea" when the main point is something new they want to make or try.
- "action_items": every concrete thing they said they need to do. At most 6.
  - "task": starts with a verb, 8 words at most (for example "Send revised client deck").
  - "due_time": the clock time for today as "HH:mm" in 24-hour form, only if they gave one ("before the 3 pm review" gives "15:00"). Otherwise null.
  - "id": any short text. "done": always false.
  - Never invent a task. Wishes, feelings and things that already happened are not tasks. No tasks means an empty list.
- Write the headline and the tasks in English, even when the dump mixes languages.

OUTPUT
Return only a JSON object with exactly these keys: "headline", "mood_detected", "category", "action_items".`;

export function buildBrainDumpUserPrompt(rawTranscript: string, now: Date): string {
  return `CURRENT TIME: ${formatClockTime(now)}\nTRANSCRIPT:\n${rawTranscript.trim()}`;
}

// ---------------------------------------------------------------------------
// Pipeline C: Real Talk
// ---------------------------------------------------------------------------

export const REAL_TALK_SYSTEM_PROMPT = `You write the weekly "Real Talk" briefing inside a private app that one adult uses to cut down on cigarettes and to offload their thoughts as brain dumps. You get the last 7 finished days and numbers the app has already worked out.

VOICE
- A blunt, realistic, analytical peer. Short sentences. No cheerleading, no therapy-speak, no health lectures, no emojis, no exclamation marks.
- The numbers in "stats" are final. Use them as given. Never recalculate, round differently or invent a number, a day or an event.
- A day with "smokes": null has no record. Do not count it as a zero-smoke day.
- In each field you may mark the one phrase that matters most with **double asterisks**. Nothing else is formatted.

FIELDS
- "smoke_trend_summary": 2 to 3 sentences. This week against last week (smokes_this_week, smokes_last_week, change_pct, days_on_target, avg_gap_mins). Name the worst day by its weekday and say that fixing that day is the job. If smokes_last_week is null, say there is no earlier week to compare with.
- "brain_habit_correlation": 2 to 3 sentences on brain dumps and smoking. Compare stressed_days_avg with calm_days_avg and name the weekdays in stressed_dates. Say there is a link only when stressed_days_avg is clearly higher than calm_days_avg. If either number is null, say plainly that there is not enough data yet and that dumping before lighting up is how the data gets made. Do not excuse the smoking.
- "next_week_micro_goal": one goal for next week that can be counted, 12 words at most, built from the weakest spot in the data (the worst day, the peak danger window, the top trigger or the first cigarette of the day). Example: "Zero smokes before **11:00 AM** — 5 of 7 days."
- "micro_goal_reward": one short sentence on what reaching the goal gives them, in rupees (settings.cost_per_cig_inr per cigarette not smoked) or in a longer gap. Example: "**₹300 saved** and a longer first gap."

OUTPUT
Return only a JSON object with exactly these keys: "smoke_trend_summary", "brain_habit_correlation", "next_week_micro_goal", "micro_goal_reward".`;

export function buildRealTalkUserPrompt(input: {
  memory: RollingMemoryDoc | null;
  period: BriefingPeriod;
  days: readonly WeekDayRow[];
  stats: RealTalkStats;
  settings: SettingsDoc;
  openTasks: readonly CarryoverTask[];
}): string {
  const { memory } = input;
  const data = {
    period: { first_day: input.period.start, last_day: input.period.end },
    days: input.days,
    stats: input.stats,
    settings: {
      daily_target: input.settings.daily_target,
      daily_baseline: input.settings.daily_baseline,
      cost_per_cig_inr: input.settings.cost_per_cig_inr,
    },
    history: memory
      ? {
          avg_per_day_last_30_days: roundTo1(memory.stats.avg_30_day),
          peak_danger_window: memory.stats.peak_danger_window,
          trigger_counts_last_7_days: memory.stats.top_triggers_7_day,
        }
      : null,
    memory_notes: memory ? memory.ai_memory_notes : [],
    open_tasks: input.openTasks.map((task) => ({ task: task.task, from: task.source_date })),
  };
  return `DATA:\n${JSON.stringify(data)}`;
}
