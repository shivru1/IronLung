/**
 * Optional cloud backup to Firebase Firestore.
 *
 * The phone's own storage stays the source of truth: every change is saved
 * locally first and marked "dirty". This service uploads the dirty documents
 * whenever it runs, and on a fresh install it pulls the backup down once.
 * Nothing in the UI ever waits for it, and without internet the dirty list
 * simply waits for the next run.
 *
 * It talks to Firebase through plain HTTPS (Identity Toolkit for sign-in, the
 * Firestore REST API for documents), so it needs no native Firebase SDK and no
 * `google-services.json`. Documents live under `users/{uid}/...` so that
 * security rules can limit them to the signed-in owner.
 */

import { DOC_PATHS } from '../storage/docStorage';
import type { DocStorage, PersistedState } from '../storage/docStorage';
import type { AppStore } from '../store/createAppStore';
import type {
  BrainDumpDoc,
  DailyLogDoc,
  RealTalkBriefingDoc,
  RollingMemoryDoc,
  SettingsDoc,
} from '../types/schema';
import { decodeFields, encodeFields } from './firestoreCodec';
import type { FirestoreFields } from './firestoreCodec';

export interface FirebaseConfig {
  apiKey: string;
  projectId: string;
  email: string;
  password: string;
}

/** The part of `fetch` this service uses. Lets tests pass in a fake. */
export type SyncFetch = (
  url: string,
  init: { method: string; headers: Record<string, string>; body?: string },
) => Promise<{ ok: boolean; status: number; text(): Promise<string> }>;

export interface SyncResult {
  ok: boolean;
  uploaded: number;
  deleted: number;
  restored: number;
  /** Set when `ok` is false. Short enough to show or log. */
  message?: string;
}

export interface FirestoreSyncDeps {
  config: FirebaseConfig;
  storage: DocStorage;
  store: { getState: () => AppStore };
  fetchImpl?: SyncFetch;
  nowMs?: () => number;
}

interface Session {
  idToken: string;
  uid: string;
  expiresAtMs: number;
}

interface ListedDoc {
  id: string;
  data: Record<string, unknown>;
}

const AUTH_URL = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword';
const FIRESTORE_URL = 'https://firestore.googleapis.com/v1';
const PAGE_SIZE = 300;
const TOKEN_SAFETY_MS = 60 * 1000;

class SyncError extends Error {}

function parseJson(text: string): Record<string, unknown> {
  try {
    const value = JSON.parse(text) as unknown;
    return typeof value === 'object' && value !== null ? (value as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}

function errorDetail(text: string): string {
  const error = parseJson(text).error;
  const message = typeof error === 'object' && error !== null ? (error as Record<string, unknown>).message : undefined;
  return typeof message === 'string' ? message : '';
}

export function createFirestoreSync(deps: FirestoreSyncDeps) {
  const { config, storage } = deps;
  const doFetch: SyncFetch = deps.fetchImpl ?? fetch;
  const nowMs = deps.nowMs ?? (() => Date.now());

  let session: Session | null = null;
  let running: Promise<SyncResult> | null = null;
  let restoreChecked = false;

  /** True when all four Firebase values are filled in. */
  function isEnabled(): boolean {
    return Boolean(config.apiKey && config.projectId && config.email && config.password);
  }

  async function send(url: string, init: { method: string; headers: Record<string, string>; body?: string }) {
    try {
      const response = await doFetch(url, init);
      return { ok: response.ok, status: response.status, text: await response.text() };
    } catch {
      throw new SyncError('No connection to the cloud backup.');
    }
  }

  async function signIn(): Promise<Session> {
    if (session && session.expiresAtMs - nowMs() > TOKEN_SAFETY_MS) {
      return session;
    }
    const response = await send(`${AUTH_URL}?key=${encodeURIComponent(config.apiKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: config.email, password: config.password, returnSecureToken: true }),
    });
    const body = parseJson(response.text);
    if (!response.ok || typeof body.idToken !== 'string' || typeof body.localId !== 'string') {
      throw new SyncError(`Cloud sign-in failed. ${errorDetail(response.text)}`.trim());
    }
    session = {
      idToken: body.idToken,
      uid: body.localId,
      expiresAtMs: nowMs() + (Number(body.expiresIn) || 3600) * 1000,
    };
    return session;
  }

  function documentUrl(uid: string, path: string): string {
    const encodedPath = path.split('/').map(encodeURIComponent).join('/');
    return `${FIRESTORE_URL}/projects/${encodeURIComponent(config.projectId)}/databases/(default)/documents/users/${encodeURIComponent(uid)}/${encodedPath}`;
  }

  function authHeaders(current: Session): Record<string, string> {
    return { 'Content-Type': 'application/json', Authorization: `Bearer ${current.idToken}` };
  }

  function refuse(status: number, text: string): SyncError {
    const hint = status === 401 || status === 403 ? ' Check the Firestore security rules.' : '';
    return new SyncError(`The cloud backup refused a request (${status}).${hint} ${errorDetail(text)}`.trim());
  }

  /** Uploads every dirty document and deletes the ones that no longer exist on the phone. */
  async function pushDirty(current: Session): Promise<{ uploaded: number; deleted: number }> {
    let uploaded = 0;
    let deleted = 0;
    for (const path of storage.getDirtyPaths()) {
      const doc = storage.readDoc(path);
      if (typeof doc === 'object' && doc !== null) {
        const response = await send(documentUrl(current.uid, path), {
          method: 'PATCH',
          headers: authHeaders(current),
          body: JSON.stringify({ fields: encodeFields(doc as Record<string, unknown>) }),
        });
        if (!response.ok) {
          throw refuse(response.status, response.text);
        }
        uploaded += 1;
      } else {
        const response = await send(documentUrl(current.uid, path), { method: 'DELETE', headers: authHeaders(current) });
        if (!response.ok && response.status !== 404) {
          throw refuse(response.status, response.text);
        }
        deleted += 1;
      }
      storage.clearDirtyPaths([path]);
    }
    return { uploaded, deleted };
  }

  async function listCollection(current: Session, collection: string): Promise<ListedDoc[]> {
    const docs: ListedDoc[] = [];
    let pageToken = '';
    do {
      const query = `?pageSize=${PAGE_SIZE}${pageToken ? `&pageToken=${encodeURIComponent(pageToken)}` : ''}`;
      const response = await send(documentUrl(current.uid, collection) + query, { method: 'GET', headers: authHeaders(current) });
      if (!response.ok) {
        throw refuse(response.status, response.text);
      }
      const body = parseJson(response.text);
      const documents = Array.isArray(body.documents) ? body.documents : [];
      for (const item of documents) {
        const record = item as { name?: unknown; fields?: FirestoreFields };
        const name = typeof record.name === 'string' ? record.name : '';
        const id = name.slice(name.lastIndexOf('/') + 1);
        if (id) {
          docs.push({ id, data: decodeFields(record.fields) });
        }
      }
      pageToken = typeof body.nextPageToken === 'string' ? body.nextPageToken : '';
    } while (pageToken);
    return docs;
  }

  async function getDocument(current: Session, path: string): Promise<Record<string, unknown> | null> {
    const response = await send(documentUrl(current.uid, path), { method: 'GET', headers: authHeaders(current) });
    if (response.status === 404) {
      return null;
    }
    if (!response.ok) {
      throw refuse(response.status, response.text);
    }
    return decodeFields(parseJson(response.text).fields as FirestoreFields | undefined);
  }

  /** Pulls the whole backup and adds what is missing on the phone. Returns how many documents came down. */
  async function restore(current: Session): Promise<number> {
    const [dailyLogs, brainDumps, briefings, settings, rollingMemory] = await Promise.all([
      listCollection(current, DOC_PATHS.dailyLogs.slice(0, -1)),
      listCollection(current, DOC_PATHS.brainDumps.slice(0, -1)),
      listCollection(current, DOC_PATHS.briefings.slice(0, -1)),
      getDocument(current, DOC_PATHS.settings),
      getDocument(current, DOC_PATHS.rollingMemory),
    ]);
    const remote: Partial<PersistedState> = { dailyLogs: {}, brainDumps: {}, briefings: {} };
    const restoredPaths: string[] = [];
    const local = deps.store.getState();

    for (const { id, data } of dailyLogs) {
      if (typeof data.logical_date === 'string' && remote.dailyLogs && !local.dailyLogs[id]) {
        remote.dailyLogs[id] = data as unknown as DailyLogDoc;
        restoredPaths.push(DOC_PATHS.dailyLogs + id);
      }
    }
    for (const { id, data } of brainDumps) {
      if (typeof data.id === 'string' && remote.brainDumps && !local.brainDumps[id]) {
        remote.brainDumps[id] = data as unknown as BrainDumpDoc;
        restoredPaths.push(DOC_PATHS.brainDumps + id);
      }
    }
    for (const { id, data } of briefings) {
      if (typeof data.week_id === 'string' && remote.briefings && !local.briefings[id]) {
        remote.briefings[id] = data as unknown as RealTalkBriefingDoc;
        restoredPaths.push(DOC_PATHS.briefings + id);
      }
    }
    if (settings && typeof settings.daily_target === 'number') {
      remote.settings = settings as unknown as SettingsDoc;
    }
    if (rollingMemory && typeof rollingMemory.last_computed_date === 'string') {
      remote.rollingMemory = rollingMemory as unknown as RollingMemoryDoc;
    }

    if (restoredPaths.length > 0 || remote.settings || remote.rollingMemory) {
      local.mergeRemoteState(remote);
      // These documents came from the cloud unchanged, so they need no upload.
      storage.clearDirtyPaths(restoredPaths);
    }
    return restoredPaths.length;
  }

  /** A phone that has at most today's log and no brain dumps is treated as a fresh install. */
  function looksLikeFreshInstall(): boolean {
    const state = deps.store.getState();
    return Object.keys(state.dailyLogs).length <= 1 && Object.keys(state.brainDumps).length === 0;
  }

  async function run(): Promise<SyncResult> {
    if (!isEnabled()) {
      return { ok: true, uploaded: 0, deleted: 0, restored: 0 };
    }
    let restored = 0;
    try {
      const current = await signIn();
      if (!restoreChecked) {
        if (looksLikeFreshInstall()) {
          restored = await restore(current);
        }
        restoreChecked = true;
      }
      const pushed = await pushDirty(current);
      return { ok: true, ...pushed, restored };
    } catch (error) {
      return {
        ok: false,
        uploaded: 0,
        deleted: 0,
        restored,
        message: error instanceof SyncError ? error.message : 'The cloud backup failed.',
      };
    }
  }

  /**
   * Runs one sync: sign in, restore once on a fresh install, upload what
   * changed. Calls made while a sync is running share its result.
   */
  function syncNow(): Promise<SyncResult> {
    if (!running) {
      running = run().finally(() => {
        running = null;
      });
    }
    return running;
  }

  return { isEnabled, syncNow };
}

export type FirestoreSync = ReturnType<typeof createFirestoreSync>;
