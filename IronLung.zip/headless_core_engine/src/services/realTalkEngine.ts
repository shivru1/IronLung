/**
 * Facts behind the weekly "Real Talk" briefing. Pure functions only.
 *
 * The numbers are worked out here so the AI only has to put them into words.
 * A briefing covers the 7 finished logical days that end yesterday.
 */

import type { BrainDumpDoc, CarryoverTask, DailyLogDoc, MoodType, RealTalkStats } from '../types/schema';
import {
  addDaysToDateString,
  getDayOfMonth,
  getIsoWeek,
  getIsoWeekId,
  getLogicalDateRange,
  getWeekdayLabel,
} from '../utils/dateUtils';
import type { DailyLogs } from './smokeEngine';

export const BRIEFING_PERIOD_DAYS = 7;

const MS_PER_MINUTE = 60 * 1000;

export interface BriefingPeriod {
  /** First and last logical date, both included. */
  start: string;
  end: string;
  /** All 7 dates, oldest first. */
  dates: string[];
  /** ISO week of the last day, used as the document key. */
  weekId: string;
  weekNumber: number;
}

/** The 7 finished days before `todayDate`. */
export function getBriefingPeriod(todayDate: string): BriefingPeriod {
  const end = addDaysToDateString(todayDate, -1);
  const dates = getLogicalDateRange(end, BRIEFING_PERIOD_DAYS);
  return {
    start: dates[0] ?? end,
    end,
    dates,
    weekId: getIsoWeekId(end),
    weekNumber: getIsoWeek(end).week,
  };
}

/** `WEEK 47 // TUE 17 – MON 23`. */
export function formatPeriodHeader(period: Pick<BriefingPeriod, 'start' | 'end' | 'weekNumber'>): string {
  const day = (date: string) => `${getWeekdayLabel(date)} ${String(getDayOfMonth(date)).padStart(2, '0')}`;
  return `WEEK ${String(period.weekNumber).padStart(2, '0')} // ${day(period.start)} – ${day(period.end)}`;
}

function logsOn(logs: DailyLogs, dates: readonly string[]): DailyLogDoc[] {
  const found: DailyLogDoc[] = [];
  for (const date of dates) {
    const log = logs[date];
    if (log) {
      found.push(log);
    }
  }
  return found;
}

function sumCounts(logs: readonly DailyLogDoc[]): number {
  return logs.reduce((sum, log) => sum + log.total_count, 0);
}

/** Average wait between two cigarettes of the same day, or `null` when no day has two. */
function averageGapMins(logs: readonly DailyLogDoc[]): number | null {
  let total = 0;
  let gaps = 0;
  for (const log of logs) {
    const times = log.smoke_entries
      .map((entry) => Date.parse(entry.timestamp))
      .filter((time) => Number.isFinite(time))
      .sort((a, b) => a - b);
    for (let index = 1; index < times.length; index += 1) {
      total += ((times[index] ?? 0) - (times[index - 1] ?? 0)) / MS_PER_MINUTE;
      gaps += 1;
    }
  }
  return gaps === 0 ? null : total / gaps;
}

function averageCountOn(logs: DailyLogs, dates: readonly string[]): number | null {
  const found = logsOn(logs, dates);
  return found.length === 0 ? null : sumCounts(found) / found.length;
}

/** Moods the AI detected on each date, from brain dumps it has finished processing. */
function moodsByDate(dumps: readonly BrainDumpDoc[]): Map<string, MoodType[]> {
  const result = new Map<string, MoodType[]>();
  for (const dump of dumps) {
    if (dump.ai_status !== 'done') {
      continue;
    }
    const moods = result.get(dump.logical_date) ?? [];
    moods.push(dump.ai_processed.mood_detected);
    result.set(dump.logical_date, moods);
  }
  return result;
}

export function computeRealTalkStats(input: {
  logs: DailyLogs;
  dumps: readonly BrainDumpDoc[];
  period: BriefingPeriod;
}): RealTalkStats {
  const { logs, dumps, period } = input;
  const thisWeek = logsOn(logs, period.dates);
  const lastWeekDates = getLogicalDateRange(addDaysToDateString(period.start, -1), BRIEFING_PERIOD_DAYS);
  const lastWeek = logsOn(logs, lastWeekDates);

  const smokesThisWeek = sumCounts(thisWeek);
  const smokesLastWeek = lastWeek.length === 0 ? null : sumCounts(lastWeek);
  const gapThisWeek = averageGapMins(thisWeek);
  const gapLastWeek = averageGapMins(lastWeek);

  let worstDay: { date: string; count: number } | null = null;
  for (const log of thisWeek) {
    if (log.total_count > 0 && (worstDay === null || log.total_count > worstDay.count)) {
      worstDay = { date: log.logical_date, count: log.total_count };
    }
  }

  const moods = moodsByDate(dumps);
  const stressedDates = period.dates.filter((date) => (moods.get(date) ?? []).includes('Stressed'));
  const calmDates = period.dates.filter((date) => {
    const dayMoods = moods.get(date) ?? [];
    return dayMoods.includes('Calm') && !dayMoods.includes('Stressed');
  });

  return {
    days_recorded: thisWeek.length,
    smokes_this_week: smokesThisWeek,
    smokes_last_week: smokesLastWeek,
    change_pct:
      smokesLastWeek !== null && smokesLastWeek > 0
        ? Math.round(((smokesThisWeek - smokesLastWeek) / smokesLastWeek) * 100)
        : null,
    avg_gap_mins: gapThisWeek === null ? null : Math.round(gapThisWeek),
    avg_gap_delta_mins:
      gapThisWeek !== null && gapLastWeek !== null ? Math.round(gapThisWeek - gapLastWeek) : null,
    days_on_target: thisWeek.filter((log) => log.total_count <= log.daily_target).length,
    worst_day: worstDay,
    stressed_days_avg: averageCountOn(logs, stressedDates),
    calm_days_avg: averageCountOn(logs, calmDates),
    stressed_dates: stressedDates,
  };
}

/** Unfinished tasks from the period's brain dumps, oldest first. */
export function collectCarryoverTasks(
  dumps: readonly BrainDumpDoc[],
  period: Pick<BriefingPeriod, 'start' | 'end'>,
): CarryoverTask[] {
  return [...dumps]
    .filter((dump) => dump.logical_date >= period.start && dump.logical_date <= period.end)
    .sort((a, b) => Date.parse(a.created_at) - Date.parse(b.created_at))
    .flatMap((dump) =>
      dump.ai_processed.action_items
        .filter((item) => !item.done)
        .map((item) => ({ id: item.id, task: item.task, source_date: dump.logical_date, dump_id: dump.id })),
    );
}

/** One day of the period as the AI sees it. */
export interface WeekDayRow {
  date: string;
  weekday: string;
  /** `null` when the app has no record for the day. */
  smokes: number | null;
  target: number | null;
  cravings_crushed: number | null;
  brain_dump_moods: MoodType[];
  brain_dump_headlines: string[];
}

export function buildWeekRows(
  logs: DailyLogs,
  dumps: readonly BrainDumpDoc[],
  period: BriefingPeriod,
): WeekDayRow[] {
  return period.dates.map((date) => {
    const log = logs[date];
    const dayDumps = dumps.filter((dump) => dump.logical_date === date && dump.ai_status === 'done');
    return {
      date,
      weekday: getWeekdayLabel(date),
      smokes: log ? log.total_count : null,
      target: log ? log.daily_target : null,
      cravings_crushed: log ? log.cravings_crushed : null,
      brain_dump_moods: dayDumps.map((dump) => dump.ai_processed.mood_detected),
      brain_dump_headlines: dayDumps.map((dump) => dump.ai_processed.headline),
    };
  });
}
