/**
 * Keeps track of what was said during one voice recording. Pure functions only.
 *
 * Android's speech recogniser works in short stretches: it sends guesses
 * ("interim" text) while the user talks, a final text when they pause, and
 * then stops listening. The recorder restarts it, and these helpers stitch
 * the stretches into one transcript.
 */

export interface TranscriptState {
  /** Text the recogniser has settled on. */
  finalText: string;
  /** The current guess for what is being said right now. */
  interimText: string;
}

export const EMPTY_TRANSCRIPT: TranscriptState = { finalText: '', interimText: '' };

function joinText(first: string, second: string): string {
  const a = first.trim();
  const b = second.trim();
  if (!a) {
    return b;
  }
  return b ? `${a} ${b}` : a;
}

/** Applies one result from the recogniser. */
export function applySpeechResult(state: TranscriptState, transcript: string, isFinal: boolean): TranscriptState {
  if (isFinal) {
    return { finalText: joinText(state.finalText, transcript), interimText: '' };
  }
  return { finalText: state.finalText, interimText: transcript.trim() };
}

/**
 * Called when the recogniser stops on its own: the last guess is kept as
 * final text so it is not lost when listening restarts.
 */
export function commitInterim(state: TranscriptState): TranscriptState {
  if (!state.interimText) {
    return state;
  }
  return { finalText: joinText(state.finalText, state.interimText), interimText: '' };
}

/** Everything said so far, settled text first. */
export function getFullTranscript(state: TranscriptState): string {
  return joinText(state.finalText, state.interimText);
}
