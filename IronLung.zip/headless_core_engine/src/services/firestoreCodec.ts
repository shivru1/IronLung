/**
 * Converts plain JSON documents to and from the typed value format of the
 * Firestore REST API. Pure functions only.
 *
 * Firestore wraps every value in an object that names its type, for example
 * `{ "stringValue": "Craving" }` or `{ "integerValue": "4" }`.
 */

export type FirestoreValue =
  | { nullValue: null }
  | { booleanValue: boolean }
  | { integerValue: string }
  | { doubleValue: number }
  | { stringValue: string }
  | { arrayValue: { values?: FirestoreValue[] } }
  | { mapValue: { fields?: Record<string, FirestoreValue> } };

export type FirestoreFields = Record<string, FirestoreValue>;

export function encodeValue(value: unknown): FirestoreValue {
  if (value === null || value === undefined) {
    return { nullValue: null };
  }
  if (typeof value === 'boolean') {
    return { booleanValue: value };
  }
  if (typeof value === 'number') {
    return Number.isInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
  }
  if (typeof value === 'string') {
    return { stringValue: value };
  }
  if (Array.isArray(value)) {
    return { arrayValue: { values: value.map(encodeValue) } };
  }
  if (typeof value === 'object') {
    return { mapValue: { fields: encodeFields(value as Record<string, unknown>) } };
  }
  return { nullValue: null };
}

/** Encodes a document. Properties that are `undefined` are left out. */
export function encodeFields(doc: Record<string, unknown>): FirestoreFields {
  const fields: FirestoreFields = {};
  for (const [key, value] of Object.entries(doc)) {
    if (value !== undefined) {
      fields[key] = encodeValue(value);
    }
  }
  return fields;
}

export function decodeValue(value: FirestoreValue | Record<string, unknown>): unknown {
  const typed = value as Record<string, unknown>;
  if ('nullValue' in typed) {
    return null;
  }
  if ('booleanValue' in typed) {
    return typed.booleanValue === true;
  }
  if ('integerValue' in typed) {
    return Number(typed.integerValue);
  }
  if ('doubleValue' in typed) {
    return Number(typed.doubleValue);
  }
  if ('stringValue' in typed) {
    return String(typed.stringValue);
  }
  if ('timestampValue' in typed) {
    return String(typed.timestampValue);
  }
  if ('arrayValue' in typed) {
    const values = (typed.arrayValue as { values?: FirestoreValue[] } | undefined)?.values ?? [];
    return values.map(decodeValue);
  }
  if ('mapValue' in typed) {
    return decodeFields((typed.mapValue as { fields?: FirestoreFields } | undefined)?.fields);
  }
  return null;
}

/** Decodes a document's `fields`. A missing `fields` gives an empty object. */
export function decodeFields(fields: FirestoreFields | undefined): Record<string, unknown> {
  const doc: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(fields ?? {})) {
    doc[key] = decodeValue(value);
  }
  return doc;
}
