/**
 * Helpers for the "peak danger window": the 3 hours of the day in which the
 * user smokes most. The rollup stores it as text such as `"15:00 - 18:00"`.
 * All functions are pure and use the phone's local clock hours.
 */

export interface DangerWindow {
  /** First hour inside the window (0-23). */
  startHour: number;
  /** Hour at which the window ends (0-23). Smaller than `startHour` when the window crosses midnight. */
  endHour: number;
}

const WINDOW_PATTERN = /^(\d{1,2}):00\s*[-–]\s*(\d{1,2}):00$/;
const MINUTES_PER_DAY = 24 * 60;

function pad(value: number): string {
  return String(value).padStart(2, '0');
}

/** Reads `"15:00 - 18:00"`. Returns `null` for anything else. */
export function parseDangerWindow(text: string | null | undefined): DangerWindow | null {
  const match = WINDOW_PATTERN.exec((text ?? '').trim());
  if (!match) {
    return null;
  }
  const startHour = Number(match[1]);
  const endHour = Number(match[2]);
  if (startHour > 23 || endHour > 23 || startHour === endHour) {
    return null;
  }
  return { startHour, endHour };
}

/** The clock hours inside the window, in order. `23:00 - 02:00` gives `[23, 0, 1]`. */
export function getWindowHours(window: DangerWindow): number[] {
  const hours: number[] = [];
  for (let hour = window.startHour; hour !== window.endHour; hour = (hour + 1) % 24) {
    hours.push(hour);
  }
  return hours;
}

/** True when `date`'s local time is inside the window. */
export function isInDangerWindow(window: DangerWindow, date: Date): boolean {
  return getWindowHours(window).includes(date.getHours());
}

/** Minutes from `date` until the window next opens. 0 while it is open. */
export function minutesUntilWindowOpens(window: DangerWindow, date: Date): number {
  if (isInDangerWindow(window, date)) {
    return 0;
  }
  const nowMins = date.getHours() * 60 + date.getMinutes();
  const startMins = window.startHour * 60;
  return (startMins - nowMins + MINUTES_PER_DAY) % MINUTES_PER_DAY;
}

/** Minutes from `date` until the open window closes. 0 while it is closed. */
export function minutesUntilWindowCloses(window: DangerWindow, date: Date): number {
  if (!isInDangerWindow(window, date)) {
    return 0;
  }
  const nowMins = date.getHours() * 60 + date.getMinutes();
  const endMins = window.endHour * 60;
  return (endMins - nowMins + MINUTES_PER_DAY) % MINUTES_PER_DAY;
}

/** The clock time `leadMins` before the window opens, for the daily heads-up alert. */
export function getAlertTime(window: DangerWindow, leadMins = 10): { hour: number; minute: number } {
  const total = (window.startHour * 60 - leadMins + MINUTES_PER_DAY * 2) % MINUTES_PER_DAY;
  return { hour: Math.floor(total / 60), minute: total % 60 };
}

/**
 * Formats the window for display.
 * - `spaced`: `15:00 – 18:00`
 * - `tight`: `15:00–18:00`
 * - `hours`: `15–18`
 */
export function formatDangerWindow(window: DangerWindow, style: 'spaced' | 'tight' | 'hours'): string {
  const start = pad(window.startHour);
  const end = pad(window.endHour);
  if (style === 'hours') {
    return `${start}–${end}`;
  }
  return style === 'tight' ? `${start}:00–${end}:00` : `${start}:00 – ${end}:00`;
}

/**
 * Share of all cigarettes that fall inside the window, in whole percent.
 * `hourlyCounts` has one count per clock hour (index 0-23). `null` when
 * nothing was smoked.
 */
export function getWindowSharePercent(hourlyCounts: readonly number[], window: DangerWindow): number | null {
  const total = hourlyCounts.reduce((sum, count) => sum + count, 0);
  if (total === 0) {
    return null;
  }
  const inside = getWindowHours(window).reduce((sum, hour) => sum + (hourlyCounts[hour] ?? 0), 0);
  return Math.round((inside / total) * 100);
}
