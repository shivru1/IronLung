/**
 * The exact JSON each AI pipeline must return, and the checks that make sure
 * it did. Pure functions only.
 *
 * Schemas are written once in a small neutral form and converted to what each
 * provider expects. Whatever comes back is still checked here, because a
 * model can return something that is valid JSON and wrong.
 */

import { BRAIN_DUMP_CATEGORIES, MOOD_TYPES } from '../types/schema';
import type { ActionItem, BrainDumpAiResult, BrainDumpCategory, MoodType } from '../types/schema';
import { truncateWords } from '../utils/format';

// ---------------------------------------------------------------------------
// Schema description
// ---------------------------------------------------------------------------

export type JsonSchema =
  | { type: 'object'; properties: Record<string, JsonSchema>; description?: string }
  | { type: 'array'; items: JsonSchema; description?: string }
  | { type: 'string'; enum?: readonly string[]; nullable?: boolean; description?: string }
  | { type: 'integer' | 'number'; nullable?: boolean; description?: string }
  | { type: 'boolean'; description?: string };

/** Gemini's `responseSchema` form: upper-case type names and a `nullable` flag. */
export function toGeminiSchema(schema: JsonSchema): Record<string, unknown> {
  const result: Record<string, unknown> = { type: schema.type.toUpperCase() };
  if (schema.description) {
    result.description = schema.description;
  }
  if ('nullable' in schema && schema.nullable) {
    result.nullable = true;
  }
  if (schema.type === 'object') {
    const properties: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(schema.properties)) {
      properties[key] = toGeminiSchema(value);
    }
    result.properties = properties;
    result.required = Object.keys(schema.properties);
    result.propertyOrdering = Object.keys(schema.properties);
  } else if (schema.type === 'array') {
    result.items = toGeminiSchema(schema.items);
  } else if (schema.type === 'string' && schema.enum) {
    result.enum = [...schema.enum];
  }
  return result;
}

/**
 * Standard JSON Schema, as used by OpenAI (strict structured outputs) and
 * Anthropic (tool input). Every property is required, extra properties are
 * forbidden, and "may be null" is written as a type list.
 */
export function toStandardSchema(schema: JsonSchema): Record<string, unknown> {
  const nullable = 'nullable' in schema && schema.nullable === true;
  const result: Record<string, unknown> = { type: nullable ? [schema.type, 'null'] : schema.type };
  if (schema.description) {
    result.description = schema.description;
  }
  if (schema.type === 'object') {
    const properties: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(schema.properties)) {
      properties[key] = toStandardSchema(value);
    }
    result.properties = properties;
    result.required = Object.keys(schema.properties);
    result.additionalProperties = false;
  } else if (schema.type === 'array') {
    result.items = toStandardSchema(schema.items);
  } else if (schema.type === 'string' && schema.enum) {
    result.enum = nullable ? [...schema.enum, null] : [...schema.enum];
  }
  return result;
}

// ---------------------------------------------------------------------------
// Reading model output
// ---------------------------------------------------------------------------

/** The model answered, but not with what the contract asks for. */
export class AiContractError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AiContractError';
  }
}

/**
 * Turns the model's text into a JSON value. Accepts plain JSON, JSON wrapped
 * in a ``` code fence, and JSON with a few words around it.
 */
export function extractJson(text: string): unknown {
  const trimmed = text.trim();
  const candidates = [trimmed, trimmed.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '')];
  const firstBrace = trimmed.indexOf('{');
  const lastBrace = trimmed.lastIndexOf('}');
  if (firstBrace >= 0 && lastBrace > firstBrace) {
    candidates.push(trimmed.slice(firstBrace, lastBrace + 1));
  }
  for (const candidate of candidates) {
    try {
      return JSON.parse(candidate) as unknown;
    } catch {
      // Try the next form.
    }
  }
  throw new AiContractError('The AI did not answer with JSON.');
}

function asRecord(raw: unknown, what: string): Record<string, unknown> {
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
    throw new AiContractError(`${what}: expected an object.`);
  }
  return raw as Record<string, unknown>;
}

function requireText(record: Record<string, unknown>, key: string, what: string): string {
  const value = record[key];
  if (typeof value !== 'string' || value.trim() === '') {
    throw new AiContractError(`${what}: "${key}" must be a non-empty string.`);
  }
  return value.trim();
}

function optionalText(value: unknown): string | null {
  if (typeof value !== 'string') {
    return null;
  }
  const clean = value.trim();
  return clean === '' || /^(null|none|n\/a)$/i.test(clean) ? null : clean;
}

function matchOption<T extends string>(value: unknown, options: readonly T[]): T | null {
  if (typeof value !== 'string') {
    return null;
  }
  const wanted = value.trim().toLowerCase();
  return options.find((option) => option.toLowerCase() === wanted) ?? null;
}

// ---------------------------------------------------------------------------
// Pipeline A: Smoke Coach
// ---------------------------------------------------------------------------

export interface SmokeCoachResult {
  reply: string;
  /** `null` when the model gave no usable number; the current target is then kept. */
  suggested_target_gap_mins: number | null;
  new_memory_note_to_save: string | null;
}

export const SMOKE_COACH_SCHEMA: JsonSchema = {
  type: 'object',
  properties: {
    reply: { type: 'string', description: 'What the coach says. 2-3 short sentences.' },
    suggested_target_gap_mins: {
      type: 'integer',
      description: 'Minutes to wait before the next cigarette, between 15 and 480.',
    },
    new_memory_note_to_save: {
      type: 'string',
      nullable: true,
      description: 'A lasting pattern learned about the user this turn, or null.',
    },
  },
};

const MAX_REPLY_CHARS = 600;
const MAX_NOTE_CHARS = 160;

export function parseSmokeCoachResult(raw: unknown): SmokeCoachResult {
  const record = asRecord(raw, 'Smoke coach');
  const gap = record.suggested_target_gap_mins;
  const note = optionalText(record.new_memory_note_to_save);
  return {
    reply: requireText(record, 'reply', 'Smoke coach').slice(0, MAX_REPLY_CHARS),
    suggested_target_gap_mins: typeof gap === 'number' && Number.isFinite(gap) && gap > 0 ? Math.round(gap) : null,
    new_memory_note_to_save: note === null ? null : note.slice(0, MAX_NOTE_CHARS),
  };
}

// ---------------------------------------------------------------------------
// Pipeline B: Brain dump
// ---------------------------------------------------------------------------

export const BRAIN_DUMP_SCHEMA: JsonSchema = {
  type: 'object',
  properties: {
    headline: { type: 'string', description: 'Max 8 words.' },
    mood_detected: { type: 'string', enum: MOOD_TYPES },
    category: { type: 'string', enum: BRAIN_DUMP_CATEGORIES },
    action_items: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          task: { type: 'string', description: 'One concrete task, max 8 words.' },
          done: { type: 'boolean' },
          due_time: {
            type: 'string',
            nullable: true,
            description: 'Deadline today as HH:mm (24-hour) if the user gave a clock time, else null.',
          },
        },
      },
    },
  },
};

const MAX_HEADLINE_WORDS = 8;
const MAX_ACTION_ITEMS = 10;
const MAX_TASK_CHARS = 120;
const CLOCK_PATTERN = /^([01]?\d|2[0-3]):([0-5]\d)$/;

function normalizeDueTime(value: unknown): string | null {
  const text = optionalText(value);
  const match = text === null ? null : CLOCK_PATTERN.exec(text);
  if (!match) {
    return null;
  }
  return `${(match[1] ?? '').padStart(2, '0')}:${match[2] ?? '00'}`;
}

/**
 * Checks and tidies a brain dump result. Task ids always come from `makeId`
 * and tasks always start as not done, whatever the model wrote.
 */
export function parseBrainDumpResult(raw: unknown, makeId: () => string): BrainDumpAiResult {
  const record = asRecord(raw, 'Brain dump');
  const mood = matchOption<MoodType>(record.mood_detected, MOOD_TYPES);
  if (!mood) {
    throw new AiContractError('Brain dump: "mood_detected" is not one of the allowed moods.');
  }
  const category = matchOption<BrainDumpCategory>(record.category, BRAIN_DUMP_CATEGORIES);
  if (!category) {
    throw new AiContractError('Brain dump: "category" is not one of the allowed categories.');
  }

  const actionItems: ActionItem[] = [];
  const rawItems = Array.isArray(record.action_items) ? record.action_items : [];
  for (const rawItem of rawItems) {
    if (actionItems.length >= MAX_ACTION_ITEMS) {
      break;
    }
    if (typeof rawItem !== 'object' || rawItem === null) {
      continue;
    }
    const item = rawItem as Record<string, unknown>;
    const task = optionalText(item.task);
    if (task === null) {
      continue;
    }
    actionItems.push({
      id: makeId(),
      task: task.slice(0, MAX_TASK_CHARS),
      done: false,
      due_time: normalizeDueTime(item.due_time),
    });
  }

  return {
    headline: truncateWords(requireText(record, 'headline', 'Brain dump'), MAX_HEADLINE_WORDS),
    mood_detected: mood,
    category,
    action_items: actionItems,
  };
}

/** What a brain dump shows until the AI has processed it. */
export function buildPlaceholderBrainDumpResult(rawTranscript: string): BrainDumpAiResult {
  return {
    headline: truncateWords(rawTranscript, MAX_HEADLINE_WORDS),
    mood_detected: 'Calm',
    category: 'Personal',
    action_items: [],
  };
}

// ---------------------------------------------------------------------------
// Pipeline C: Real Talk
// ---------------------------------------------------------------------------

/** The words of a weekly briefing. The numbers next to them are worked out by the app. */
export interface RealTalkTexts {
  smoke_trend_summary: string;
  brain_habit_correlation: string;
  next_week_micro_goal: string;
  micro_goal_reward: string;
}

export const REAL_TALK_SCHEMA: JsonSchema = {
  type: 'object',
  properties: {
    smoke_trend_summary: { type: 'string', description: '2-3 short sentences on the week against the week before.' },
    brain_habit_correlation: {
      type: 'string',
      description: '2-3 short sentences on how "Stressed" brain dump days lined up with smoking.',
    },
    next_week_micro_goal: { type: 'string', description: 'One measurable goal for next week, max 12 words.' },
    micro_goal_reward: { type: 'string', description: 'One short sentence: what reaching the goal gives the user.' },
  },
};

const MAX_BRIEFING_CHARS = 500;

export function parseRealTalkTexts(raw: unknown): RealTalkTexts {
  const record = asRecord(raw, 'Real talk');
  return {
    smoke_trend_summary: requireText(record, 'smoke_trend_summary', 'Real talk').slice(0, MAX_BRIEFING_CHARS),
    brain_habit_correlation: requireText(record, 'brain_habit_correlation', 'Real talk').slice(0, MAX_BRIEFING_CHARS),
    next_week_micro_goal: requireText(record, 'next_week_micro_goal', 'Real talk').slice(0, MAX_BRIEFING_CHARS),
    micro_goal_reward: (optionalText(record.micro_goal_reward) ?? '').slice(0, MAX_BRIEFING_CHARS),
  };
}
