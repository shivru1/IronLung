/**
 * The list of triggers a cigarette can be tagged with: the built-in ones plus
 * the ones the user added. Pure functions only.
 */

import { BUILT_IN_TRIGGERS, MAX_CUSTOM_TRIGGERS, MAX_TRIGGER_NAME_LENGTH } from '../types/schema';
import type { BuiltInTrigger, TriggerType } from '../types/schema';

/** Tidies a typed name: no spaces at the ends, single spaces inside, cut to the allowed length. */
export function normalizeTriggerName(raw: string): string {
  const tidy = raw.replace(/\s+/g, ' ').trim();
  // Cut by whole characters, so an emoji is never split in two.
  return Array.from(tidy).slice(0, MAX_TRIGGER_NAME_LENGTH).join('').trim();
}

export function isBuiltInTrigger(name: string): name is BuiltInTrigger {
  return (BUILT_IN_TRIGGERS as readonly string[]).includes(name);
}

/** All triggers in the order the chips show them: built-in first, then the user's own. */
export function listTriggers(customTriggers: readonly string[]): TriggerType[] {
  return [...BUILT_IN_TRIGGERS, ...customTriggers];
}

/** The trigger with this name, ignoring upper and lower case, or `null` when there is none. */
export function findTrigger(name: string, customTriggers: readonly string[]): TriggerType | null {
  const wanted = normalizeTriggerName(name).toLowerCase();
  return listTriggers(customTriggers).find((trigger) => trigger.toLowerCase() === wanted) ?? null;
}

export type AddTriggerResult =
  /** Added. `customTriggers` is the new list. */
  | { ok: true; trigger: TriggerType; customTriggers: string[] }
  /** Nothing was typed. */
  | { ok: false; reason: 'empty' }
  /** A trigger with this name is already there; `trigger` is how it is spelled. */
  | { ok: false; reason: 'exists'; trigger: TriggerType }
  /** The user already has the most triggers allowed. */
  | { ok: false; reason: 'full' };

/** Adds a trigger of the user's own to the end of their list. */
export function addCustomTrigger(customTriggers: readonly string[], rawName: string): AddTriggerResult {
  const name = normalizeTriggerName(rawName);
  if (!name) {
    return { ok: false, reason: 'empty' };
  }
  const existing = findTrigger(name, customTriggers);
  if (existing !== null) {
    return { ok: false, reason: 'exists', trigger: existing };
  }
  if (customTriggers.length >= MAX_CUSTOM_TRIGGERS) {
    return { ok: false, reason: 'full' };
  }
  return { ok: true, trigger: name, customTriggers: [...customTriggers, name] };
}

/** Takes a trigger off the user's list. Cigarettes already tagged with it keep the tag. */
export function removeCustomTrigger(customTriggers: readonly string[], name: string): string[] {
  return customTriggers.filter((trigger) => trigger !== name);
}

/**
 * Reads a saved list of the user's triggers and keeps what is usable: text
 * only, tidied, no name twice, none that is built in, not more than allowed.
 * Anything that is not a list gives an empty list.
 */
export function sanitizeCustomTriggers(value: unknown): string[] {
  if (!Array.isArray(value)) {
    return [];
  }
  let triggers: string[] = [];
  for (const item of value) {
    if (typeof item !== 'string') {
      continue;
    }
    const result = addCustomTrigger(triggers, item);
    if (result.ok) {
      triggers = result.customTriggers;
    }
  }
  return triggers;
}
