/**
 * Remembers which AI model answered last, so the app does not start every
 * request with a model that keeps refusing.
 *
 * The memory wears off after a while: the main model is then tried first
 * again, in case it is available once more.
 */

import type { KeyValueStore } from '../storage/kv';

const STORAGE_KEY = 'answering_model';

export interface ModelMemory {
  /** The remembered model, or `null` when there is none or it is too old. */
  get(): string | null;
  /** Call with the model that just answered and the main model from the settings. */
  remember(answeredModel: string, mainModel: string): void;
}

interface Saved {
  model: string;
  /** When this model was first remembered, in milliseconds. */
  sinceMs: number;
}

function readSaved(kv: KeyValueStore): Saved | null {
  const raw = kv.getString(STORAGE_KEY);
  if (!raw) {
    return null;
  }
  try {
    const value = JSON.parse(raw) as Partial<Saved> | null;
    if (value && typeof value.model === 'string' && typeof value.sinceMs === 'number') {
      return { model: value.model, sinceMs: value.sinceMs };
    }
  } catch {
    // Unreadable memory counts as no memory.
  }
  return null;
}

export function createModelMemory(kv: KeyValueStore, maxAgeMs: number, nowMs: () => number = Date.now): ModelMemory {
  return {
    get: () => {
      const saved = readSaved(kv);
      if (!saved) {
        return null;
      }
      const ageMs = nowMs() - saved.sinceMs;
      return ageMs >= 0 && ageMs < maxAgeMs ? saved.model : null;
    },
    remember: (answeredModel, mainModel) => {
      if (answeredModel === mainModel) {
        // The main model works: nothing to remember.
        kv.remove(STORAGE_KEY);
        return;
      }
      const saved = readSaved(kv);
      const isStillRemembered = saved !== null && saved.model === answeredModel && nowMs() - saved.sinceMs < maxAgeMs;
      if (!isStillRemembered) {
        // The clock starts when a model is first remembered, not at each answer,
        // so the main model does get another chance later.
        kv.set(STORAGE_KEY, JSON.stringify({ model: answeredModel, sinceMs: nowMs() } satisfies Saved));
      }
    },
  };
}
