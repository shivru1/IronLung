/**
 * The words shown in the two Android notifications. Pure functions only.
 */

import type { DailyLogDoc, SmokeEntry } from '../types/schema';
import { formatDurationSpaced, formatInr } from '../utils/format';
import { formatDangerWindow, getAlertTime, parseDangerWindow } from './dangerWindow';

export interface NotificationText {
  title: string;
  body: string;
}

/** Minutes before the danger window opens at which the heads-up alert fires. */
export const DANGER_ALERT_LEAD_MINS = 10;

/** The always-there tracker notification with the "+1 Smoke" and "Craving Crushed" buttons. */
export function buildTrackerNotificationText(today: DailyLogDoc | undefined, lastSmoke: SmokeEntry | null): NotificationText {
  if (!today) {
    return { title: 'Smoke tracker', body: 'Open the app to start today.' };
  }
  const lastSmokeText = lastSmoke ? `Last smoke ${lastSmoke.timestamp.slice(11, 16)}` : 'No smoke logged yet';
  return {
    title: `${today.total_count} / ${today.daily_target} today · wait ${formatDurationSpaced(today.active_target_gap_mins)}`,
    body: `${lastSmokeText} · ${today.cravings_crushed} crushed · ₹${formatInr(today.money_saved_inr)} saved`,
  };
}

export interface DangerAlertPlan extends NotificationText {
  /** Local clock time at which the alert fires every day. */
  hour: number;
  minute: number;
}

/**
 * The daily alert shortly before the peak danger window. Returns `null` when
 * there is no window yet (nothing to warn about).
 */
export function buildDangerAlertPlan(peakDangerWindow: string | null | undefined, targetGapMins: number): DangerAlertPlan | null {
  const window = parseDangerWindow(peakDangerWindow);
  if (!window) {
    return null;
  }
  const { hour, minute } = getAlertTime(window, DANGER_ALERT_LEAD_MINS);
  return {
    hour,
    minute,
    title: `Danger window opens in ${DANGER_ALERT_LEAD_MINS} min`,
    body: `${formatDangerWindow(window, 'spaced')} is when you smoke most. Hold your ${formatDurationSpaced(targetGapMins)} gap. Walk. Water. Don't negotiate.`,
  };
}
