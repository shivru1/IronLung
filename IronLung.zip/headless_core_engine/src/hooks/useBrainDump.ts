/**
 * Everything the Brain Dump screen shows and does: recording, the live
 * transcript, today's tasks and the list of processed dumps.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import { APP_CONFIG } from '../config/appConfig';
import { processBrainDumpAI } from '../services/aiService';
import {
  isSpeechRecognitionAvailable,
  startSpeechRecognition,
  triggerChipSelectHaptic,
} from '../services/nativeAndroidService';
import type { SpeechSession } from '../services/nativeAndroidService';
import { EMPTY_TRANSCRIPT, getFullTranscript } from '../services/speechTranscript';
import type { TranscriptState } from '../services/speechTranscript';
import { useAppStore } from '../store/useAppStore';
import type { BrainDumpCategory, BrainDumpDoc } from '../types/schema';
import { getLogicalDateString } from '../utils/dateUtils';
import { useNow } from './useNow';

/** One task from a brain dump, with what the list needs to show it. */
export interface BrainDumpTask {
  dumpId: string;
  taskId: string;
  task: string;
  done: boolean;
  /** `HH:mm` when the user gave a deadline. */
  dueTime: string | null;
  category: BrainDumpCategory;
}

export interface BrainDump {
  /** Today's logical date (`YYYY-MM-DD`), for labels such as "TODAY 11:40". */
  todayDate: string;
  /** All brain dumps, newest first. */
  dumps: BrainDumpDoc[];
  isRecording: boolean;
  /** Everything heard in the current recording. */
  liveTranscript: string;
  /** The part of the live transcript the recogniser has settled on. */
  liveTranscriptFinal: string;
  /** The part that is still a guess and may change. */
  liveTranscriptInterim: string;
  /** Seconds since the recording started. */
  recordingSeconds: number;
  /** True while the AI is working on at least one dump. */
  isProcessingAi: boolean;
  /** Today's tasks that are not ticked off. */
  todaysUnfinishedTasks: BrainDumpTask[];
  /** All of today's tasks, in the order they were dumped. */
  todaysTasks: BrainDumpTask[];
  /** False on phones without a speech recognition service; typing still works. */
  isVoiceAvailable: boolean;
  /** Why recording stopped or could not start, for example a denied microphone permission. */
  voiceError: string | null;

  startVoiceRecording: () => Promise<void>;
  /** Stops recording and saves what was said as a brain dump. */
  stopAndSubmitVoiceRecording: () => Promise<void>;
  /** Stops recording and throws the transcript away. */
  cancelVoiceRecording: () => void;
  submitTextDump: (text: string) => Promise<void>;
  toggleTaskDone: (dumpId: string, taskId: string) => void;
  deleteDump: (dumpId: string) => void;
}

function tasksOf(dump: BrainDumpDoc): BrainDumpTask[] {
  return dump.ai_processed.action_items.map((item) => ({
    dumpId: dump.id,
    taskId: item.id,
    task: item.task,
    done: item.done,
    dueTime: item.due_time ?? null,
    category: dump.ai_processed.category,
  }));
}

export function useBrainDump(): BrainDump {
  const now = useNow(30_000);
  const todayDate = getLogicalDateString(now);
  const brainDumps = useAppStore((state) => state.brainDumps);
  const isProcessingAi = useAppStore((state) => state.processingDumpCount > 0);

  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState<TranscriptState>(EMPTY_TRANSCRIPT);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const sessionRef = useRef<SpeechSession | null>(null);
  const isStartingRef = useRef(false);
  const stopRequestedWhileStartingRef = useRef(false);
  const [isVoiceAvailable] = useState(() => isSpeechRecognitionAvailable());

  const dumps = useMemo(
    () => Object.values(brainDumps).sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at)),
    [brainDumps],
  );
  const todaysTasks = useMemo(
    () =>
      dumps
        .filter((dump) => dump.logical_date === todayDate)
        .reverse()
        .flatMap(tasksOf),
    [dumps, todayDate],
  );
  const todaysUnfinishedTasks = useMemo(() => todaysTasks.filter((task) => !task.done), [todaysTasks]);

  const submitTextDump = useCallback(async (text: string) => {
    if (text.trim()) {
      await processBrainDumpAI(text);
    }
  }, []);

  const startVoiceRecording = useCallback(async () => {
    if (sessionRef.current || isStartingRef.current) {
      return;
    }
    isStartingRef.current = true;
    stopRequestedWhileStartingRef.current = false;
    setVoiceError(null);
    setTranscript(EMPTY_TRANSCRIPT);
    setRecordingSeconds(0);
    try {
      const session = await startSpeechRecognition({
        onTranscript: setTranscript,
        onError: (message) => {
          setVoiceError(message);
          sessionRef.current = null;
          setIsRecording(false);
        },
      });
      if (stopRequestedWhileStartingRef.current) {
        // The button was released before the microphone was ready (for example
        // while the permission dialog was open): nothing was said yet.
        session.cancel();
        return;
      }
      sessionRef.current = session;
      setIsRecording(true);
      triggerChipSelectHaptic();
    } catch (error) {
      setVoiceError(error instanceof Error ? error.message : 'Could not start recording.');
    } finally {
      isStartingRef.current = false;
    }
  }, []);

  const stopAndSubmitVoiceRecording = useCallback(async () => {
    const session = sessionRef.current;
    if (!session) {
      stopRequestedWhileStartingRef.current = isStartingRef.current;
      return;
    }
    sessionRef.current = null;
    setIsRecording(false);
    const text = await session.stop();
    setTranscript(EMPTY_TRANSCRIPT);
    await submitTextDump(text);
  }, [submitTextDump]);

  const cancelVoiceRecording = useCallback(() => {
    const session = sessionRef.current;
    sessionRef.current = null;
    stopRequestedWhileStartingRef.current = isStartingRef.current;
    setIsRecording(false);
    setTranscript(EMPTY_TRANSCRIPT);
    if (session) {
      session.cancel();
    }
  }, []);

  // Counts the recording time and stops a recording that was left running.
  useEffect(() => {
    if (!isRecording) {
      return undefined;
    }
    const startedAt = Date.now();
    const timer = setInterval(() => {
      const seconds = Math.floor((Date.now() - startedAt) / 1000);
      setRecordingSeconds(seconds);
      if (seconds >= APP_CONFIG.speech.maxRecordingSeconds) {
        stopAndSubmitVoiceRecording().catch(() => undefined);
      }
    }, 500);
    return () => clearInterval(timer);
  }, [isRecording, stopAndSubmitVoiceRecording]);

  // Releases the microphone if the screen goes away mid-recording.
  useEffect(
    () => () => {
      if (sessionRef.current) {
        sessionRef.current.cancel();
        sessionRef.current = null;
      }
    },
    [],
  );

  const toggleTaskDone = useCallback((dumpId: string, taskId: string) => {
    triggerChipSelectHaptic();
    useAppStore.getState().toggleTaskDone(dumpId, taskId);
  }, []);

  const deleteDump = useCallback((dumpId: string) => {
    useAppStore.getState().deleteDump(dumpId);
  }, []);

  return {
    todayDate,
    dumps,
    isRecording,
    liveTranscript: getFullTranscript(transcript),
    liveTranscriptFinal: transcript.finalText,
    liveTranscriptInterim: transcript.interimText,
    recordingSeconds,
    isProcessingAi,
    todaysUnfinishedTasks,
    todaysTasks,
    isVoiceAvailable,
    voiceError,
    startVoiceRecording,
    stopAndSubmitVoiceRecording,
    cancelVoiceRecording,
    submitTextDump,
    toggleTaskDone,
    deleteDump,
  };
}
