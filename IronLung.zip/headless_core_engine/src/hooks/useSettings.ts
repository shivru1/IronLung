/**
 * Quick Settings: the daily baseline, the daily target, the price of a
 * cigarette and the AI API key.
 */

import { useCallback, useEffect, useSyncExternalStore } from 'react';

import { retryPendingBrainDumps } from '../services/aiService';
import { detectProvider } from '../services/llmClient';
import { triggerChipSelectHaptic } from '../services/nativeAndroidService';
import { getCachedApiKey, loadApiKey, saveApiKey, subscribeToApiKey } from '../storage/secureKey';
import { useAppStore } from '../store/useAppStore';
import type { LlmProvider } from '../config/appConfig';

export interface Settings {
  dailyBaseline: number;
  dailyTarget: number;
  costPerCigInr: number;
  /** The saved AI key, or `null` when none is set. */
  apiKey: string | null;
  /** Which AI the saved key belongs to. */
  apiProvider: LlmProvider | null;

  setDailyBaseline: (value: number) => void;
  /** Changes today's limit by `delta` (use +1 / -1 for the stepper). */
  stepDailyTarget: (delta: number) => void;
  setCostPerCig: (value: number) => void;
  /** Saves the key in secure storage. An empty string removes it. */
  setApiKey: (key: string) => Promise<void>;
}

export function useSettings(): Settings {
  const settings = useAppStore((state) => state.settings);
  const apiKey = useSyncExternalStore(subscribeToApiKey, getCachedApiKey);

  useEffect(() => {
    loadApiKey().catch(() => undefined);
  }, []);

  const setDailyBaseline = useCallback((value: number) => {
    useAppStore.getState().updateSettings({ daily_baseline: value });
  }, []);

  const stepDailyTarget = useCallback((delta: number) => {
    triggerChipSelectHaptic();
    const current = useAppStore.getState().settings.daily_target;
    useAppStore.getState().updateSettings({ daily_target: current + delta });
  }, []);

  const setCostPerCig = useCallback((value: number) => {
    useAppStore.getState().updateSettings({ cost_per_cig_inr: value });
  }, []);

  const setApiKey = useCallback(async (key: string) => {
    await saveApiKey(key);
    if (key.trim()) {
      // Brain dumps that were waiting for a key can be processed now.
      retryPendingBrainDumps().catch(() => undefined);
    }
  }, []);

  return {
    dailyBaseline: settings.daily_baseline,
    dailyTarget: settings.daily_target,
    costPerCigInr: settings.cost_per_cig_inr,
    apiKey,
    apiProvider: apiKey ? detectProvider(apiKey) : null,
    setDailyBaseline,
    stepDailyTarget,
    setCostPerCig,
    setApiKey,
  };
}
