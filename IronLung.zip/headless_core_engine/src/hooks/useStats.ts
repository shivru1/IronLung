/**
 * Numbers for the Stats screen: headline figures, the daily chart, the hours
 * of the day and the trigger ranking, for the last 7 or 30 days.
 */

import { useMemo } from 'react';

import { buildChartSlots, buildDangerProfile, computeStatsKpis, rankTriggersInRange } from '../services/statsEngine';
import type { ChartSlot, DangerProfile, StatsKpis, TriggerRank } from '../services/statsEngine';
import { useAppStore } from '../store/useAppStore';
import { getLogicalDateString } from '../utils/dateUtils';
import { useNow } from './useNow';

export type StatsRange = 7 | 30;

export interface Stats {
  kpis: StatsKpis;
  /** One slot per day of the range, oldest first, today last. */
  chart: ChartSlot[];
  /** Today's target, drawn as the dashed line on the chart. */
  dailyTarget: number;
  danger: DangerProfile;
  triggerRanking: TriggerRank[];
}

export function useStats(rangeDays: StatsRange): Stats {
  const now = useNow(60_000);
  const todayDate = getLogicalDateString(now);
  const dailyLogs = useAppStore((state) => state.dailyLogs);
  const chartCache = useAppStore((state) => state.rollingMemory?.chart_cache_30_days);
  const settingsTarget = useAppStore((state) => state.settings.daily_target);
  const today = dailyLogs[todayDate];

  const kpis = useMemo(() => computeStatsKpis({ logs: dailyLogs, todayDate, rangeDays }), [dailyLogs, todayDate, rangeDays]);
  const chart = useMemo(
    () => buildChartSlots({ chartCache: chartCache ?? [], todayLog: today, todayDate, numDays: rangeDays }),
    [chartCache, today, todayDate, rangeDays],
  );
  const danger = useMemo(() => buildDangerProfile(dailyLogs, todayDate, rangeDays), [dailyLogs, todayDate, rangeDays]);
  const triggerRanking = useMemo(() => rankTriggersInRange(dailyLogs, todayDate, rangeDays), [dailyLogs, todayDate, rangeDays]);

  return {
    kpis,
    chart,
    dailyTarget: today ? today.daily_target : settingsTarget,
    danger,
    triggerRanking,
  };
}
