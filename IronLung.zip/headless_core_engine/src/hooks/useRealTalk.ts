/**
 * Everything the Real Talk screen shows and does: the latest weekly briefing,
 * older ones, and the carryover tasks.
 */

import { useCallback, useMemo, useState } from 'react';

import { generateRealTalkAI } from '../services/aiService';
import { triggerChipSelectHaptic } from '../services/nativeAndroidService';
import { formatPeriodHeader, getBriefingPeriod } from '../services/realTalkEngine';
import { useAppStore } from '../store/useAppStore';
import type { RealTalkBriefingDoc } from '../types/schema';
import { diffInDays, getIsoWeek, getLogicalDateString } from '../utils/dateUtils';
import { useNow } from './useNow';

/** A carryover task with its live state. */
export interface CarryoverTaskView {
  id: string;
  task: string;
  /** Read from the brain dump that owns the task, so it is always current. */
  done: boolean;
  /** Days since the task was dumped. */
  ageDays: number;
}

export interface RealTalk {
  /** The most recently generated briefing, or `null` before the first one. */
  latestBriefing: RealTalkBriefingDoc | null;
  isGenerating: boolean;
  /** Earlier briefings, newest first. */
  historicalBriefings: RealTalkBriefingDoc[];
  /** `WEEK 47 // TUE 17 – MON 23` for the latest briefing, or for the week a new one would cover. */
  periodHeader: string;
  carryoverTasks: CarryoverTaskView[];
  openCarryoverCount: number;
  /** Why the last attempt produced no briefing (no key, no data, no internet). */
  errorMessage: string | null;

  generateFreshBriefing: () => Promise<void>;
  toggleCarryoverTask: (taskId: string) => void;
}

export function useRealTalk(): RealTalk {
  const now = useNow(60_000);
  const todayDate = getLogicalDateString(now);
  const briefings = useAppStore((state) => state.briefings);
  const brainDumps = useAppStore((state) => state.brainDumps);
  const isGenerating = useAppStore((state) => state.isGeneratingBriefing);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const sorted = useMemo(
    () => Object.values(briefings).sort((a, b) => Date.parse(b.generated_at) - Date.parse(a.generated_at)),
    [briefings],
  );
  const latestBriefing = sorted[0] ?? null;
  const historicalBriefings = useMemo(() => sorted.slice(1), [sorted]);

  const periodHeader = useMemo(() => {
    if (latestBriefing) {
      return formatPeriodHeader({
        start: latestBriefing.period_start,
        end: latestBriefing.period_end,
        weekNumber: getIsoWeek(latestBriefing.period_end).week,
      });
    }
    return formatPeriodHeader(getBriefingPeriod(todayDate));
  }, [latestBriefing, todayDate]);

  const carryoverTasks = useMemo<CarryoverTaskView[]>(() => {
    if (!latestBriefing) {
      return [];
    }
    const views: CarryoverTaskView[] = [];
    for (const task of latestBriefing.carryover_tasks) {
      const item = brainDumps[task.dump_id]?.ai_processed.action_items.find((candidate) => candidate.id === task.id);
      if (item) {
        views.push({
          id: task.id,
          task: item.task,
          done: item.done,
          ageDays: Math.max(0, diffInDays(task.source_date, todayDate)),
        });
      }
    }
    return views;
  }, [latestBriefing, brainDumps, todayDate]);

  const generateFreshBriefing = useCallback(async () => {
    setErrorMessage(null);
    const outcome = await generateRealTalkAI();
    setErrorMessage(outcome.ok ? null : outcome.message);
  }, []);

  const toggleCarryoverTask = useCallback(
    (taskId: string) => {
      const task = latestBriefing?.carryover_tasks.find((candidate) => candidate.id === taskId);
      if (task) {
        triggerChipSelectHaptic();
        useAppStore.getState().toggleTaskDone(task.dump_id, task.id);
      }
    },
    [latestBriefing],
  );

  return {
    latestBriefing,
    isGenerating,
    historicalBriefings,
    periodHeader,
    carryoverTasks,
    openCarryoverCount: carryoverTasks.filter((task) => !task.done).length,
    errorMessage,
    generateFreshBriefing,
    toggleCarryoverTask,
  };
}
