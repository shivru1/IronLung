/**
 * The store instance the app uses, saved with MMKV.
 *
 * Reading it in a component:   `const count = useAppStore((s) => s.settings.daily_target);`
 * Using it outside components: `useAppStore.getState().logSmoke();`
 */

import { createMmkvKv } from '../storage/mmkvKv';
import { createAppStore } from './createAppStore';

const { useStore, storage } = createAppStore(createMmkvKv('ironlung'));

export const useAppStore = useStore;

/** Direct access to the saved documents, used by the cloud sync. */
export const appStorage = storage;
