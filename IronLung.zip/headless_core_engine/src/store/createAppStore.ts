/**
 * The app's single source of truth: a Zustand store saved on the phone.
 *
 * Every action here is synchronous. It updates memory first and the storage
 * right after, so the UI never waits for the network. Slow work (AI calls,
 * cloud sync) lives in the services and reports back through these actions.
 *
 * `createAppStore` takes the storage as a parameter so tests can run it in
 * memory; the app uses the MMKV-backed instance from `useAppStore.ts`.
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

import { APP_CONFIG } from '../config/appConfig';
import { computeRollingMemory, shouldRunRollup } from '../services/rollupEngine';
import {
  addBrainDumpHeadline,
  addCravingCrushed,
  addSmoke,
  appendChatMessage,
  appendMemoryNote,
  applySettingsToDay,
  clampTargetGapMins,
  createDailyLog,
  defaultTargetGapMins,
  finalizeDay,
  removeBrainDumpHeadline,
  removeLastSmoke,
  retagLastSmoke,
} from '../services/smokeEngine';
import type { DailyLogs, DayDefaults } from '../services/smokeEngine';
import {
  addCustomTrigger,
  findTrigger,
  normalizeTriggerName,
  removeCustomTrigger,
  sanitizeCustomTriggers,
} from '../services/triggers';
import type { AddTriggerResult } from '../services/triggers';
import { DocStorage } from '../storage/docStorage';
import type { PersistedState } from '../storage/docStorage';
import type { KeyValueStore } from '../storage/kv';
import type {
  BrainDumpAiResult,
  BrainDumpDoc,
  ChatMessage,
  ChatRole,
  DailyLogDoc,
  RealTalkBriefingDoc,
  RollingMemoryDoc,
  SettingsDoc,
  SmokeEntry,
  TriggerType,
} from '../types/schema';
import { getLogicalDateString, toLocalIsoString } from '../utils/dateUtils';
import { createId } from '../utils/id';

const STORAGE_NAME = 'app-state';
const STORAGE_VERSION = 1;
const MS_PER_MINUTE = 60 * 1000;
/** "Undo" only reaches a cigarette from an earlier day if it is this recent. */
const UNDO_REACH_MS = 6 * 60 * MS_PER_MINUTE;
const MAX_BACKDATE_MINS = 24 * 60;

/** Things that are in progress right now. Not saved. */
export interface TransientState {
  isCoachLoading: boolean;
  /** Brain dumps the AI is working on. */
  processingDumpCount: number;
  isGeneratingBriefing: boolean;
}

export type AppState = PersistedState & TransientState;

export type EditableSettings = Pick<SettingsDoc, 'daily_baseline' | 'daily_target' | 'cost_per_cig_inr'>;

export interface AppActions {
  /**
   * Makes sure today's log exists. When a new logical day has started it also
   * closes the days before and rebuilds the rolling memory. Returns today's
   * logical date. Safe to call as often as you like.
   */
  ensureToday(now?: Date): string;

  /** Logs one cigarette. Uses the selected trigger unless one is given. */
  logSmoke(input?: { trigger?: TriggerType; backdateMins?: number; now?: Date }): SmokeEntry;
  /** Removes the most recent cigarette. Returns it, or `null` when there is nothing recent to undo. */
  undoLastSmoke(now?: Date): SmokeEntry | null;
  /** Changes the trigger of the most recent cigarette. */
  retagLastSmoke(trigger: TriggerType, now?: Date): SmokeEntry | null;
  /** Counts one craving the user resisted. */
  crushCraving(now?: Date): void;
  /** Picks the trigger for the next cigarette (also used by the lock-screen button). Unknown names are ignored. */
  selectTrigger(trigger: TriggerType): void;
  /**
   * Adds a trigger of the user's own and selects it. When a trigger with that
   * name already exists, that one is selected instead.
   */
  addCustomTrigger(name: string, now?: Date): AddTriggerResult;
  /** Removes one of the user's own triggers. Cigarettes already tagged with it keep the tag. */
  removeCustomTrigger(name: TriggerType, now?: Date): void;
  updateSettings(patch: Partial<EditableSettings>, now?: Date): void;

  /** Adds a message to today's coach conversation. */
  addChatMessage(role: ChatRole, text: string, now?: Date): ChatMessage;
  /** Stores what the coach decided: the new wait target and an optional memory note. */
  applyCoachResult(result: { suggestedTargetGapMins: number | null; newMemoryNote: string | null }, now?: Date): void;

  addBrainDump(dump: BrainDumpDoc): void;
  /** Replaces a pending brain dump's placeholder with the AI result. */
  completeBrainDump(dumpId: string, result: BrainDumpAiResult): void;
  toggleTaskDone(dumpId: string, taskId: string): void;
  deleteDump(dumpId: string): void;

  saveBriefing(briefing: RealTalkBriefingDoc): void;

  setCoachLoading(isLoading: boolean): void;
  adjustProcessingDumps(delta: number): void;
  setGeneratingBriefing(isGenerating: boolean): void;

  /** Adds documents from a cloud backup that are missing on this phone. Local data always wins. */
  mergeRemoteState(remote: Partial<PersistedState>, now?: Date): void;
}

export type AppStore = AppState & AppActions;

function createInitialState(): AppState {
  return {
    settings: {
      daily_baseline: APP_CONFIG.defaults.dailyBaseline,
      daily_target: APP_CONFIG.defaults.dailyTarget,
      cost_per_cig_inr: APP_CONFIG.defaults.costPerCigInr,
      selected_trigger: APP_CONFIG.defaults.selectedTrigger,
      custom_triggers: [],
      // Empty until the user changes a setting.
      updated_at: '',
    },
    dailyLogs: {},
    rollingMemory: null,
    brainDumps: {},
    briefings: {},
    isCoachLoading: false,
    processingDumpCount: 0,
    isGeneratingBriefing: false,
  };
}

/** Starting values for a day: today's settings, and the wait target carried over from the day before. */
function dayDefaultsFor(settings: SettingsDoc, logs: DailyLogs, logicalDate: string): DayDefaults {
  const earlierDates = Object.keys(logs)
    .filter((date) => date < logicalDate)
    .sort();
  const previous = logs[earlierDates[earlierDates.length - 1] ?? ''];
  return {
    dailyTarget: settings.daily_target,
    dailyBaseline: settings.daily_baseline,
    costPerCigInr: settings.cost_per_cig_inr,
    activeTargetGapMins: previous ? previous.active_target_gap_mins : defaultTargetGapMins(settings.daily_target),
  };
}

function rebuildMemory(state: Pick<AppState, 'settings' | 'rollingMemory'>, logs: DailyLogs, today: string): RollingMemoryDoc {
  return computeRollingMemory({
    logs: Object.values(logs),
    todayLogicalDate: today,
    currentDailyTarget: state.settings.daily_target,
    previous: state.rollingMemory,
  });
}

function sanitizeWholeNumber(value: number | undefined, fallback: number, max: number): number {
  if (value === undefined || !Number.isFinite(value)) {
    return fallback;
  }
  return Math.min(max, Math.max(0, Math.round(value)));
}

function withDay(logs: DailyLogs, date: string, update: (log: DailyLogDoc) => DailyLogDoc): DailyLogs {
  const log = logs[date];
  if (!log) {
    return logs;
  }
  const updated = update(log);
  return updated === log ? logs : { ...logs, [date]: updated };
}

export function createAppStore(kv: KeyValueStore) {
  const initialState = createInitialState();
  const storage = new DocStorage(kv, {
    settings: initialState.settings,
    dailyLogs: {},
    rollingMemory: null,
    brainDumps: {},
    briefings: {},
  });

  const useStore = create<AppStore>()(
    persist(
      (set, get) => ({
        ...initialState,

        ensureToday: (now = new Date()) => {
          const state = get();
          const today = getLogicalDateString(now);
          let logs: Record<string, DailyLogDoc> | null = null;
          let closedADay = false;

          for (const [date, log] of Object.entries(state.dailyLogs)) {
            if (date < today && !log.is_finalized) {
              logs = logs ?? { ...state.dailyLogs };
              logs[date] = finalizeDay(log);
              closedADay = true;
            }
          }
          if (!state.dailyLogs[today]) {
            logs = logs ?? { ...state.dailyLogs };
            logs[today] = createDailyLog(today, dayDefaultsFor(state.settings, logs, today));
          }

          const currentLogs = logs ?? state.dailyLogs;
          const needsRollup = closedADay || shouldRunRollup(state.rollingMemory, today);
          if (logs || needsRollup) {
            set({
              dailyLogs: currentLogs,
              rollingMemory: needsRollup ? rebuildMemory(state, currentLogs, today) : state.rollingMemory,
            });
          }
          return today;
        },

        logSmoke: (input = {}) => {
          const now = input.now ?? new Date();
          const today = get().ensureToday(now);
          const state = get();
          const backdateMins = sanitizeWholeNumber(input.backdateMins, 0, MAX_BACKDATE_MINS);
          const result = addSmoke(state.dailyLogs, {
            id: createId('smk'),
            trigger:
              normalizeTriggerName(input.trigger ?? '') ||
              state.settings.selected_trigger ||
              APP_CONFIG.defaults.selectedTrigger,
            smokedAt: new Date(now.getTime() - backdateMins * MS_PER_MINUTE),
            backdatedMins: backdateMins,
            defaultsFor: (date) => dayDefaultsFor(state.settings, state.dailyLogs, date),
          });

          if (result.logicalDate < today) {
            // The cigarette landed on a finished day: close that day again and redo the summary.
            const logs = withDay(result.logs, result.logicalDate, finalizeDay);
            set({ dailyLogs: logs, rollingMemory: rebuildMemory(state, logs, today) });
          } else {
            set({ dailyLogs: result.logs });
          }
          return result.entry;
        },

        undoLastSmoke: (now = new Date()) => {
          const today = get().ensureToday(now);
          const state = get();
          const result = removeLastSmoke(state.dailyLogs);
          if (!result) {
            return null;
          }
          const ageMs = now.getTime() - Date.parse(result.removed.timestamp);
          if (result.logicalDate !== today && ageMs > UNDO_REACH_MS) {
            return null;
          }
          set({
            dailyLogs: result.logs,
            rollingMemory:
              result.logicalDate < today ? rebuildMemory(state, result.logs, today) : state.rollingMemory,
          });
          return result.removed;
        },

        retagLastSmoke: (trigger, now = new Date()) => {
          const state = get();
          const name = normalizeTriggerName(trigger);
          const result = name ? retagLastSmoke(state.dailyLogs, name) : null;
          if (!result) {
            return null;
          }
          const today = getLogicalDateString(now);
          set({
            dailyLogs: result.logs,
            rollingMemory:
              result.logicalDate < today ? rebuildMemory(state, result.logs, today) : state.rollingMemory,
          });
          return result.entry;
        },

        crushCraving: (now = new Date()) => {
          const today = get().ensureToday(now);
          set({ dailyLogs: withDay(get().dailyLogs, today, addCravingCrushed) });
        },

        selectTrigger: (trigger) => {
          const { settings } = get();
          const known = findTrigger(trigger, sanitizeCustomTriggers(settings.custom_triggers));
          if (known !== null && settings.selected_trigger !== known) {
            set({ settings: { ...settings, selected_trigger: known } });
          }
        },

        addCustomTrigger: (name, now = new Date()) => {
          const { settings } = get();
          const result = addCustomTrigger(sanitizeCustomTriggers(settings.custom_triggers), name);
          if (result.ok) {
            set({
              settings: {
                ...settings,
                custom_triggers: result.customTriggers,
                selected_trigger: result.trigger,
                updated_at: toLocalIsoString(now),
              },
            });
          } else if (result.reason === 'exists') {
            get().selectTrigger(result.trigger);
          }
          return result;
        },

        removeCustomTrigger: (name, now = new Date()) => {
          const { settings } = get();
          const current = sanitizeCustomTriggers(settings.custom_triggers);
          if (!current.includes(name)) {
            return;
          }
          set({
            settings: {
              ...settings,
              custom_triggers: removeCustomTrigger(current, name),
              // The next cigarette must not be tagged with a trigger that is gone.
              selected_trigger: settings.selected_trigger === name ? APP_CONFIG.defaults.selectedTrigger : settings.selected_trigger,
              updated_at: toLocalIsoString(now),
            },
          });
        },

        updateSettings: (patch, now = new Date()) => {
          const today = get().ensureToday(now);
          const state = get();
          const settings: SettingsDoc = {
            ...state.settings,
            daily_baseline: sanitizeWholeNumber(patch.daily_baseline, state.settings.daily_baseline, 99),
            daily_target: sanitizeWholeNumber(patch.daily_target, state.settings.daily_target, 99),
            cost_per_cig_inr: sanitizeWholeNumber(patch.cost_per_cig_inr, state.settings.cost_per_cig_inr, 9999),
            updated_at: toLocalIsoString(now),
          };
          const memory = state.rollingMemory;
          set({
            settings,
            dailyLogs: withDay(state.dailyLogs, today, (log) => applySettingsToDay(log, settings)),
            rollingMemory:
              memory && memory.stats.current_daily_target !== settings.daily_target
                ? { ...memory, stats: { ...memory.stats, current_daily_target: settings.daily_target } }
                : memory,
          });
        },

        addChatMessage: (role, text, now = new Date()) => {
          const today = get().ensureToday(now);
          const message: ChatMessage = {
            id: createId('msg'),
            role,
            text: text.trim(),
            timestamp: toLocalIsoString(now),
          };
          set({ dailyLogs: withDay(get().dailyLogs, today, (log) => appendChatMessage(log, message)) });
          return message;
        },

        applyCoachResult: (result, now = new Date()) => {
          const today = get().ensureToday(now);
          const state = get();
          const gap = result.suggestedTargetGapMins;
          const logs =
            gap === null
              ? state.dailyLogs
              : withDay(state.dailyLogs, today, (log) => {
                  const clamped = clampTargetGapMins(gap);
                  return log.active_target_gap_mins === clamped ? log : { ...log, active_target_gap_mins: clamped };
                });
          const memory = state.rollingMemory ?? rebuildMemory(state, logs, today);
          const notes = appendMemoryNote(memory.ai_memory_notes, result.newMemoryNote);
          const notesChanged = notes.length !== memory.ai_memory_notes.length || notes.some((n, i) => n !== memory.ai_memory_notes[i]);
          set({
            dailyLogs: logs,
            rollingMemory: notesChanged ? { ...memory, ai_memory_notes: notes } : memory,
          });
        },

        addBrainDump: (dump) => {
          const state = get();
          set({
            brainDumps: { ...state.brainDumps, [dump.id]: dump },
            dailyLogs:
              dump.ai_status === 'done'
                ? withDay(state.dailyLogs, dump.logical_date, (log) => addBrainDumpHeadline(log, dump.ai_processed.headline))
                : state.dailyLogs,
          });
        },

        completeBrainDump: (dumpId, result) => {
          const state = get();
          const dump = state.brainDumps[dumpId];
          if (!dump) {
            return;
          }
          const wasDone = dump.ai_status === 'done';
          const updated: BrainDumpDoc = { ...dump, ai_processed: result, ai_status: 'done' };
          set({
            brainDumps: { ...state.brainDumps, [dumpId]: updated },
            dailyLogs: withDay(state.dailyLogs, dump.logical_date, (log) =>
              addBrainDumpHeadline(wasDone ? removeBrainDumpHeadline(log, dump.ai_processed.headline) : log, result.headline),
            ),
          });
        },

        toggleTaskDone: (dumpId, taskId) => {
          const state = get();
          const dump = state.brainDumps[dumpId];
          if (!dump || !dump.ai_processed.action_items.some((item) => item.id === taskId)) {
            return;
          }
          const items = dump.ai_processed.action_items.map((item) =>
            item.id === taskId ? { ...item, done: !item.done } : item,
          );
          set({
            brainDumps: {
              ...state.brainDumps,
              [dumpId]: { ...dump, ai_processed: { ...dump.ai_processed, action_items: items } },
            },
          });
        },

        deleteDump: (dumpId) => {
          const state = get();
          const dump = state.brainDumps[dumpId];
          if (!dump) {
            return;
          }
          const remaining = { ...state.brainDumps };
          delete remaining[dumpId];
          set({
            brainDumps: remaining,
            dailyLogs:
              dump.ai_status === 'done'
                ? withDay(state.dailyLogs, dump.logical_date, (log) => removeBrainDumpHeadline(log, dump.ai_processed.headline))
                : state.dailyLogs,
          });
        },

        saveBriefing: (briefing) => {
          set({ briefings: { ...get().briefings, [briefing.week_id]: briefing } });
        },

        setCoachLoading: (isLoading) => set({ isCoachLoading: isLoading }),
        adjustProcessingDumps: (delta) => set({ processingDumpCount: Math.max(0, get().processingDumpCount + delta) }),
        setGeneratingBriefing: (isGenerating) => set({ isGeneratingBriefing: isGenerating }),

        mergeRemoteState: (remote, now = new Date()) => {
          const state = get();
          const settingsNeverChanged = state.settings.updated_at === '';
          set({
            settings: remote.settings && settingsNeverChanged ? { ...state.settings, ...remote.settings } : state.settings,
            dailyLogs: { ...(remote.dailyLogs ?? {}), ...state.dailyLogs },
            brainDumps: { ...(remote.brainDumps ?? {}), ...state.brainDumps },
            briefings: { ...(remote.briefings ?? {}), ...state.briefings },
            rollingMemory: state.rollingMemory ?? remote.rollingMemory ?? null,
          });
          const today = get().ensureToday(now);
          // The restored days may change the summary, so build it again.
          const merged = get();
          set({ rollingMemory: rebuildMemory(merged, merged.dailyLogs, today) });
        },
      }),
      {
        name: STORAGE_NAME,
        version: STORAGE_VERSION,
        storage,
        partialize: (state): PersistedState => ({
          settings: state.settings,
          dailyLogs: state.dailyLogs,
          rollingMemory: state.rollingMemory,
          brainDumps: state.brainDumps,
          briefings: state.briefings,
        }),
      },
    ),
  );

  return { useStore, storage };
}

/** Today's log, or `undefined` before `ensureToday` has run for the day. */
export function selectTodayLog(state: Pick<AppState, 'dailyLogs'>, now: Date = new Date()): DailyLogDoc | undefined {
  return state.dailyLogs[getLogicalDateString(now)];
}
