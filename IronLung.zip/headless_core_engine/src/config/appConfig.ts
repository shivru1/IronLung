/**
 * Everything you may want to change without touching the logic.
 *
 * The AI API key is NOT set here. Paste it inside the app:
 * REAL TALK tab > QUICK SETTINGS > AI API Key. It is kept in the phone's
 * secure storage.
 */

import type { BuiltInTrigger } from '../types/schema';

export type LlmProvider = 'gemini' | 'openai' | 'anthropic';

export const APP_CONFIG = {
  /** Values used on first launch. All of them can be changed in Quick Settings. */
  defaults: {
    dailyBaseline: 15,
    dailyTarget: 8,
    costPerCigInr: 20,
    selectedTrigger: 'Craving' as BuiltInTrigger,
  },

  /** Limits for the "wait this long between cigarettes" target. */
  targetGap: {
    /** Waking minutes in a day, used to spread the daily target evenly. */
    wakingMinutes: 16 * 60,
    minMins: 15,
    maxMins: 8 * 60,
  },

  /** The "-15m" button: each tap moves the next logged cigarette further back. */
  backdate: {
    stepMins: 15,
    maxMins: 120,
  },

  ai: {
    /**
     * Model used for each provider. The provider is picked from the shape of
     * the API key (see `detectProvider` in `services/llmClient.ts`).
     * Model names change over time; update them here if a provider retires one.
     */
    models: {
      gemini: 'gemini-3.8-flash',
      openai: 'gpt-4o-mini',
      anthropic: 'claude-haiku-4-5',
    } as Record<LlmProvider, string>,
    /**
     * Models to try next, in this order, when the one above refuses the
     * request (out of quota, overloaded, or closed to this key). The app
     * remembers which one answered and starts with it for the next few hours.
     */
    backupModels: {
      gemini: ['gemini-3.7-flash', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-flash-latest', 'gemini-3-flash-preview'],
      openai: [],
      anthropic: [],
    } as Record<LlmProvider, readonly string[]>,
    /** How long the app keeps starting with a backup model before it tries the first model again. */
    rememberModelHours: 6,
    /** Provider used when the key's shape is not recognised. */
    fallbackProvider: 'gemini' as LlmProvider,
    requestTimeoutMs: 30_000,
  },

  speech: {
    /** Language for voice brain dumps (BCP 47 tag). */
    language: 'en-IN',
    /** Recording stops by itself after this long. */
    maxRecordingSeconds: 5 * 60,
  },

  /**
   * Optional cloud backup to Firebase Firestore. Leave `apiKey` empty and the
   * app works fully on the phone. To turn it on see "Cloud backup" in README.md.
   * Do not publish this file with real values in it.
   */
  firebase: {
    apiKey: '',
    projectId: '',
    /** Email/password of the single Firebase Auth user that owns the data. */
    email: '',
    password: '',
  },
} as const;

export function isFirebaseConfigured(): boolean {
  const { apiKey, projectId, email, password } = APP_CONFIG.firebase;
  return Boolean(apiKey && projectId && email && password);
}
