/** Makes ids for entries, messages, brain dumps and tasks. */

let counter = 0;

/**
 * Returns an id that is unique on this phone: the time, a counter (for ids
 * made in the same millisecond) and a few random characters.
 */
export function createId(prefix: string): string {
  counter = (counter + 1) % 1296;
  const time = Date.now().toString(36);
  const sequence = counter.toString(36).padStart(2, '0');
  const random = Math.random().toString(36).slice(2, 8).padEnd(6, '0');
  return `${prefix}_${time}${sequence}${random}`;
}
