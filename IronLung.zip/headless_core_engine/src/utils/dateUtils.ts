/**
 * Date helpers built around the app's "logical day".
 *
 * A logical day runs from 04:00 until 03:59:59 the next morning, in the phone's
 * local time. A cigarette at 1:30 AM therefore still counts toward the day the
 * user has not gone to sleep on yet. Logical days are written as `YYYY-MM-DD`
 * and are used as document keys.
 */

/** Local hour at which a new logical day starts. */
export const LOGICAL_DAY_START_HOUR = 4;

const MS_PER_DAY = 24 * 60 * 60 * 1000;

const DATE_STRING_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;

/**
 * Matches timestamps that carry their own UTC offset, such as
 * `2026-11-19T01:30:00.000+05:30`, and captures the wall-clock hour.
 */
const OFFSET_TIMESTAMP_PATTERN =
  /^\d{4}-\d{2}-\d{2}T(\d{2}):\d{2}(?::\d{2}(?:\.\d+)?)?[+-]\d{2}:\d{2}$/;

function pad(value: number, length = 2): string {
  return String(value).padStart(length, '0');
}

/** Formats the UTC calendar date of `date` as `YYYY-MM-DD`. */
function formatUtcDate(date: Date): string {
  return `${pad(date.getUTCFullYear(), 4)}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())}`;
}

/**
 * Turns `YYYY-MM-DD` into the timestamp of that date at midnight UTC.
 * Throws for anything that is not a real calendar date.
 */
function parseDateString(dateString: string): number {
  const match = DATE_STRING_PATTERN.exec(dateString);
  if (match) {
    const utcMs = Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
    if (formatUtcDate(new Date(utcMs)) === dateString) {
      return utcMs;
    }
  }
  throw new RangeError(`Expected a real YYYY-MM-DD date but got "${dateString}".`);
}

/**
 * Returns the logical date (`YYYY-MM-DD`) that `date` belongs to.
 * Anything from 00:00 to 03:59:59 local time belongs to the previous day.
 */
export function getLogicalDateString(date: Date = new Date()): string {
  if (Number.isNaN(date.getTime())) {
    throw new RangeError('Cannot get the logical date of an invalid Date.');
  }
  const daysBack = date.getHours() < LOGICAL_DAY_START_HOUR ? 1 : 0;
  // Step back on the local calendar instead of subtracting 4 hours of clock
  // time, which gives the wrong date on nights when the clocks change.
  return formatUtcDate(
    new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate() - daysBack)),
  );
}

/** Moves a `YYYY-MM-DD` date forward (or back, for negative `days`) by whole days. */
export function addDaysToDateString(dateString: string, days: number): string {
  if (!Number.isInteger(days)) {
    throw new RangeError(`Expected a whole number of days but got ${days}.`);
  }
  return formatUtcDate(new Date(parseDateString(dateString) + days * MS_PER_DAY));
}

/** Returns the logical date of the day before the one `now` belongs to. */
export function getYesterdayLogicalDateString(now: Date = new Date()): string {
  return addDaysToDateString(getLogicalDateString(now), -1);
}

/**
 * Lists the `numDays` logical dates that end on `endDateString` (inclusive),
 * oldest first.
 */
export function getLogicalDateRange(endDateString: string, numDays: number): string[] {
  const dates: string[] = [];
  for (let daysBack = numDays - 1; daysBack >= 0; daysBack -= 1) {
    dates.push(addDaysToDateString(endDateString, -daysBack));
  }
  return dates;
}

/**
 * Formats `date` as an ISO-8601 timestamp that keeps the phone's UTC offset,
 * for example `2026-11-19T01:30:00.000+05:30`. Every timestamp the app stores
 * uses this form, so the hour the user actually saw on the clock is never lost.
 */
export function toLocalIsoString(date: Date = new Date()): string {
  if (Number.isNaN(date.getTime())) {
    throw new RangeError('Cannot format an invalid Date.');
  }
  const offsetMins = -date.getTimezoneOffset();
  const sign = offsetMins < 0 ? '-' : '+';
  const absOffsetMins = Math.abs(offsetMins);
  const datePart = `${pad(date.getFullYear(), 4)}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  const timePart = `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}.${pad(date.getMilliseconds(), 3)}`;
  const offsetPart = `${sign}${pad(Math.floor(absOffsetMins / 60))}:${pad(absOffsetMins % 60)}`;
  return `${datePart}T${timePart}${offsetPart}`;
}

/**
 * Returns the hour (0-23) the user's clock showed at `timestamp`, or `null`
 * when the timestamp cannot be read.
 *
 * Timestamps written by `toLocalIsoString` carry their own offset, so the
 * answer does not change if the phone later moves to another time zone.
 * Timestamps without an offset (for example ending in `Z`) fall back to the
 * phone's current time zone.
 */
export function getWallClockHour(timestamp: string): number | null {
  const match = OFFSET_TIMESTAMP_PATTERN.exec(timestamp);
  if (match) {
    const hour = Number(match[1]);
    return hour <= 23 ? hour : null;
  }
  const parsed = new Date(timestamp);
  return Number.isNaN(parsed.getTime()) ? null : parsed.getHours();
}

/** Returns the logical date a stored timestamp belongs to. */
export function getLogicalDateOfTimestamp(timestamp: string): string {
  return getLogicalDateString(new Date(timestamp));
}

/** Whole days from `fromDateString` to `toDateString` (negative when `to` is earlier). */
export function diffInDays(fromDateString: string, toDateString: string): number {
  return Math.round((parseDateString(toDateString) - parseDateString(fromDateString)) / MS_PER_DAY);
}

/** Day names used on charts and headers, Monday first. */
export const WEEKDAY_LABELS = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'] as const;

/** Day of the week of a `YYYY-MM-DD` date: 0 = Monday ... 6 = Sunday. */
export function getWeekdayIndex(dateString: string): number {
  return (new Date(parseDateString(dateString)).getUTCDay() + 6) % 7;
}

/** `2026-11-24` -> `TUE`. */
export function getWeekdayLabel(dateString: string): string {
  return WEEKDAY_LABELS[getWeekdayIndex(dateString)] ?? '';
}

/** Day of the month of a `YYYY-MM-DD` date (1-31). */
export function getDayOfMonth(dateString: string): number {
  return new Date(parseDateString(dateString)).getUTCDate();
}

/**
 * ISO-8601 week of a `YYYY-MM-DD` date. Weeks start on Monday and week 1 is
 * the week that holds the year's first Thursday, so the first days of January
 * can belong to the last week of the year before.
 */
export function getIsoWeek(dateString: string): { year: number; week: number } {
  const thursday = new Date(parseDateString(dateString));
  thursday.setUTCDate(thursday.getUTCDate() - getWeekdayIndex(dateString) + 3);
  const year = thursday.getUTCFullYear();
  const firstThursday = new Date(Date.UTC(year, 0, 4));
  firstThursday.setUTCDate(firstThursday.getUTCDate() - ((firstThursday.getUTCDay() + 6) % 7) + 3);
  const week = 1 + Math.round((thursday.getTime() - firstThursday.getTime()) / (7 * MS_PER_DAY));
  return { year, week };
}

/** ISO week as a document key, for example `2026-W47`. */
export function getIsoWeekId(dateString: string): string {
  const { year, week } = getIsoWeek(dateString);
  return `${pad(year, 4)}-W${pad(week)}`;
}
