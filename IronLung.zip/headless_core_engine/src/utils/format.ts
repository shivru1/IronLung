/** Small formatting helpers shared by the hooks and the screens. */

export function pad2(value: number): string {
  return String(Math.trunc(value)).padStart(2, '0');
}

/** Splits whole minutes into hours and minutes. Negative input counts as 0. */
export function splitDuration(totalMins: number): { hours: number; minutes: number } {
  const safe = Math.max(0, Math.floor(totalMins));
  return { hours: Math.floor(safe / 60), minutes: safe % 60 };
}

/** `138` -> `{ hours: '02', minutes: '18' }`; `null` -> dashes. Used by the big gauge. */
export function formatGaugeParts(totalMins: number | null): { hours: string; minutes: string } {
  if (totalMins === null) {
    return { hours: '--', minutes: '--' };
  }
  const { hours, minutes } = splitDuration(totalMins);
  return { hours: pad2(hours), minutes: pad2(minutes) };
}

/** `150` -> `02h 30m`. */
export function formatDurationPadded(totalMins: number): string {
  const { hours, minutes } = splitDuration(totalMins);
  return `${pad2(hours)}h ${pad2(minutes)}m`;
}

/** `161` -> `2h 41m`, `45` -> `45m`, `120` -> `2h 00m`. */
export function formatDurationSpaced(totalMins: number): string {
  const { hours, minutes } = splitDuration(totalMins);
  return hours === 0 ? `${minutes}m` : `${hours}h ${pad2(minutes)}m`;
}

/** `150` -> `2h30`, `120` -> `2h`, `45` -> `45m`. Used for the short label at the end of the gauge. */
export function formatDurationCompact(totalMins: number): string {
  const { hours, minutes } = splitDuration(totalMins);
  if (hours === 0) {
    return `${minutes}m`;
  }
  return minutes === 0 ? `${hours}h` : `${hours}h${pad2(minutes)}`;
}

/** `12` -> `12m`, `75` -> `1h 15m`. Used for "12m TO GO". */
export function formatDurationLoose(totalMins: number): string {
  const { hours, minutes } = splitDuration(totalMins);
  if (hours === 0) {
    return `${minutes}m`;
  }
  return minutes === 0 ? `${hours}h` : `${hours}h ${minutes}m`;
}

/** `34` -> `+34m`, `-12` -> `-12m`, `0` -> `0m`. */
export function formatSignedMins(deltaMins: number): string {
  const rounded = Math.round(deltaMins);
  if (rounded === 0) {
    return '0m';
  }
  return `${rounded > 0 ? '+' : '-'}${formatDurationLoose(Math.abs(rounded))}`;
}

/** `-1.34` -> `-1.3`, `0.8` -> `+0.8`. */
export function formatSignedDecimal(value: number): string {
  const rounded = Math.round(value * 10) / 10;
  const text = Math.abs(rounded).toFixed(1);
  if (rounded === 0) {
    return text;
  }
  return `${rounded > 0 ? '+' : '-'}${text}`;
}

/** Rupees with Indian digit grouping and no symbol: `4840` -> `4,840`, `1234567` -> `12,34,567`. */
export function formatInr(amount: number): string {
  const rounded = Math.round(Math.abs(amount));
  const digits = String(rounded);
  const sign = amount < 0 && rounded !== 0 ? '-' : '';
  if (digits.length <= 3) {
    return sign + digits;
  }
  const lastThree = digits.slice(-3);
  const rest = digits.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return `${sign}${rest},${lastThree}`;
}

/** The time on the phone's clock as `HH:mm`. */
export function formatClockTime(date: Date): string {
  return `${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
}

/** Seconds as `mm:ss`, for the recording timer. */
export function formatTimer(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  return `${pad2(Math.floor(safe / 60))}:${pad2(safe % 60)}`;
}

/** Cuts text to at most `maxWords` words. */
export function truncateWords(text: string, maxWords: number): string {
  const words = text.trim().split(/\s+/).filter(Boolean);
  return words.slice(0, maxWords).join(' ');
}
