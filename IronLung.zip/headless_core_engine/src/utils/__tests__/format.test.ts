import {
  formatClockTime,
  formatDurationCompact,
  formatDurationLoose,
  formatDurationPadded,
  formatDurationSpaced,
  formatGaugeParts,
  formatInr,
  formatSignedDecimal,
  formatSignedMins,
  formatTimer,
  splitDuration,
  truncateWords,
} from '../format';

describe('splitDuration', () => {
  it('splits minutes into hours and minutes', () => {
    expect(splitDuration(138)).toEqual({ hours: 2, minutes: 18 });
  });

  it('treats a negative duration as zero', () => {
    expect(splitDuration(-5)).toEqual({ hours: 0, minutes: 0 });
  });
});

describe('formatGaugeParts', () => {
  it('pads both parts to two digits', () => {
    expect(formatGaugeParts(138)).toEqual({ hours: '02', minutes: '18' });
  });

  it('shows dashes when there is nothing to count from', () => {
    expect(formatGaugeParts(null)).toEqual({ hours: '--', minutes: '--' });
  });

  it('keeps counting past 99 hours', () => {
    expect(formatGaugeParts(6005)).toEqual({ hours: '100', minutes: '05' });
  });
});

describe('duration formats', () => {
  it('writes the padded form', () => {
    expect(formatDurationPadded(150)).toBe('02h 30m');
  });

  it('writes the spaced form', () => {
    expect(formatDurationSpaced(161)).toBe('2h 41m');
  });

  it('writes the spaced form without hours under one hour', () => {
    expect(formatDurationSpaced(45)).toBe('45m');
  });

  it('writes the compact form', () => {
    expect(formatDurationCompact(150)).toBe('2h30');
  });

  it('writes the compact form for whole hours', () => {
    expect(formatDurationCompact(120)).toBe('2h');
  });

  it('writes the compact form under one hour', () => {
    expect(formatDurationCompact(45)).toBe('45m');
  });

  it('writes the loose form', () => {
    expect(formatDurationLoose(75)).toBe('1h 15m');
  });

  it('writes the loose form under one hour', () => {
    expect(formatDurationLoose(12)).toBe('12m');
  });
});

describe('formatSignedMins', () => {
  it('marks a longer wait with a plus', () => {
    expect(formatSignedMins(34)).toBe('+34m');
  });

  it('marks a shorter wait with a minus', () => {
    expect(formatSignedMins(-75)).toBe('-1h 15m');
  });

  it('has no sign for zero', () => {
    expect(formatSignedMins(0)).toBe('0m');
  });
});

describe('formatSignedDecimal', () => {
  it('rounds to one decimal and keeps the minus', () => {
    expect(formatSignedDecimal(-1.34)).toBe('-1.3');
  });

  it('adds a plus to a rise', () => {
    expect(formatSignedDecimal(0.8)).toBe('+0.8');
  });

  it('has no sign for a change that rounds to zero', () => {
    expect(formatSignedDecimal(0.04)).toBe('0.0');
  });
});

describe('formatInr', () => {
  it('leaves small amounts as they are', () => {
    expect(formatInr(120)).toBe('120');
  });

  it('groups thousands', () => {
    expect(formatInr(4840)).toBe('4,840');
  });

  it('groups lakhs the Indian way', () => {
    expect(formatInr(1234567)).toBe('12,34,567');
  });

  it('rounds to whole rupees', () => {
    expect(formatInr(99.6)).toBe('100');
  });
});

describe('formatClockTime', () => {
  it('writes the local time with leading zeros', () => {
    expect(formatClockTime(new Date(2026, 10, 19, 9, 5))).toBe('09:05');
  });
});

describe('formatTimer', () => {
  it('writes minutes and seconds', () => {
    expect(formatTimer(24)).toBe('00:24');
  });

  it('carries seconds into minutes', () => {
    expect(formatTimer(125)).toBe('02:05');
  });
});

describe('truncateWords', () => {
  it('keeps the first words only', () => {
    expect(truncateWords('one two three four five', 3)).toBe('one two three');
  });

  it('collapses extra spaces', () => {
    expect(truncateWords('  one   two  ', 8)).toBe('one two');
  });
});
