import {
  addDaysToDateString,
  diffInDays,
  getDayOfMonth,
  getIsoWeek,
  getIsoWeekId,
  getLogicalDateOfTimestamp,
  getLogicalDateRange,
  getLogicalDateString,
  getWallClockHour,
  getWeekdayIndex,
  getWeekdayLabel,
  getYesterdayLogicalDateString,
  toLocalIsoString,
} from '../dateUtils';

// `new Date(year, monthIndex, day, hour, minute)` builds a time on the local
// clock, so these tests give the same result in every time zone.

describe('getLogicalDateString', () => {
  it('counts a 1:30 AM smoke toward the previous day', () => {
    const lateNight = new Date(2026, 10, 19, 1, 30);

    expect(getLogicalDateString(lateNight)).toBe('2026-11-18');
  });

  it('treats midnight as part of the previous day', () => {
    const midnight = new Date(2026, 10, 19, 0, 0, 0);

    expect(getLogicalDateString(midnight)).toBe('2026-11-18');
  });

  it('treats 03:59:59 as still the previous day', () => {
    const lastMoment = new Date(2026, 10, 19, 3, 59, 59, 999);

    expect(getLogicalDateString(lastMoment)).toBe('2026-11-18');
  });

  it('starts the new day at exactly 04:00:00', () => {
    const firstMoment = new Date(2026, 10, 19, 4, 0, 0, 0);

    expect(getLogicalDateString(firstMoment)).toBe('2026-11-19');
  });

  it('keeps the late evening on the same day', () => {
    const lateEvening = new Date(2026, 10, 19, 23, 59, 59);

    expect(getLogicalDateString(lateEvening)).toBe('2026-11-19');
  });

  it('steps back across a month boundary', () => {
    const firstOfDecember = new Date(2026, 11, 1, 2, 0);

    expect(getLogicalDateString(firstOfDecember)).toBe('2026-11-30');
  });

  it('steps back across a year boundary', () => {
    const newYearsNight = new Date(2027, 0, 1, 0, 30);

    expect(getLogicalDateString(newYearsNight)).toBe('2026-12-31');
  });

  it('steps back onto 29 February in a leap year', () => {
    const firstOfMarch = new Date(2028, 2, 1, 3, 0);

    expect(getLogicalDateString(firstOfMarch)).toBe('2028-02-29');
  });

  it('rejects an invalid Date', () => {
    const invalid = new Date('not a date');

    expect(() => getLogicalDateString(invalid)).toThrow(RangeError);
  });
});

describe('addDaysToDateString', () => {
  it('moves back one day', () => {
    expect(addDaysToDateString('2026-11-19', -1)).toBe('2026-11-18');
  });

  it('returns the same date for zero days', () => {
    expect(addDaysToDateString('2026-11-19', 0)).toBe('2026-11-19');
  });

  it('moves forward across a year boundary', () => {
    expect(addDaysToDateString('2026-12-31', 1)).toBe('2027-01-01');
  });

  it('moves back onto 28 February in a normal year', () => {
    expect(addDaysToDateString('2026-03-01', -1)).toBe('2026-02-28');
  });

  it('moves back onto 29 February in a leap year', () => {
    expect(addDaysToDateString('2028-03-01', -1)).toBe('2028-02-29');
  });

  it('moves back 30 days across two month boundaries', () => {
    expect(addDaysToDateString('2026-11-18', -30)).toBe('2026-10-19');
  });

  it('rejects a date that is not written as YYYY-MM-DD', () => {
    expect(() => addDaysToDateString('2026-2-3', 1)).toThrow(RangeError);
  });

  it('rejects a date that does not exist', () => {
    expect(() => addDaysToDateString('2026-02-31', 1)).toThrow(RangeError);
  });

  it('rejects a fraction of a day', () => {
    expect(() => addDaysToDateString('2026-11-19', 0.5)).toThrow(RangeError);
  });
});

describe('getYesterdayLogicalDateString', () => {
  it('goes two calendar days back when it is before 4 AM', () => {
    const lateNight = new Date(2026, 10, 19, 1, 30);

    expect(getYesterdayLogicalDateString(lateNight)).toBe('2026-11-17');
  });

  it('goes one calendar day back after 4 AM', () => {
    const morning = new Date(2026, 10, 19, 9, 0);

    expect(getYesterdayLogicalDateString(morning)).toBe('2026-11-18');
  });
});

describe('getLogicalDateRange', () => {
  it('lists the days ending on the given date, oldest first', () => {
    expect(getLogicalDateRange('2026-11-02', 4)).toEqual([
      '2026-10-30',
      '2026-10-31',
      '2026-11-01',
      '2026-11-02',
    ]);
  });

  it('returns only the end date for a one-day range', () => {
    expect(getLogicalDateRange('2026-11-02', 1)).toEqual(['2026-11-02']);
  });
});

describe('toLocalIsoString', () => {
  it('writes the local clock time followed by the UTC offset', () => {
    const date = new Date(2026, 10, 19, 1, 30, 5, 7);

    expect(toLocalIsoString(date)).toMatch(/^2026-11-19T01:30:05\.007[+-]\d{2}:\d{2}$/);
  });

  it('can be read back as the same moment', () => {
    const date = new Date(2026, 10, 19, 1, 30, 5, 7);

    expect(new Date(toLocalIsoString(date)).getTime()).toBe(date.getTime());
  });

  it('rejects an invalid Date', () => {
    const invalid = new Date('not a date');

    expect(() => toLocalIsoString(invalid)).toThrow(RangeError);
  });
});

describe('getWallClockHour', () => {
  it('reads the hour written in a timestamp that has an offset', () => {
    expect(getWallClockHour('2026-11-19T15:20:00.000+05:30')).toBe(15);
  });

  it('does not convert the hour to another time zone', () => {
    expect(getWallClockHour('2026-11-19T23:59:59.999-08:00')).toBe(23);
  });

  it('reads the hour written by toLocalIsoString', () => {
    const date = new Date(2026, 10, 19, 1, 30);

    expect(getWallClockHour(toLocalIsoString(date))).toBe(1);
  });

  it('uses the local clock for a timestamp without an offset', () => {
    const utcTimestamp = new Date(2026, 10, 19, 15, 20).toISOString();

    expect(getWallClockHour(utcTimestamp)).toBe(15);
  });

  it('returns null for text that is not a timestamp', () => {
    expect(getWallClockHour('not a date')).toBeNull();
  });
});

describe('getLogicalDateOfTimestamp', () => {
  it('files a stored 1:30 AM timestamp under the previous day', () => {
    const timestamp = toLocalIsoString(new Date(2026, 10, 20, 1, 30));

    expect(getLogicalDateOfTimestamp(timestamp)).toBe('2026-11-19');
  });
});

describe('diffInDays', () => {
  it('counts forward across a month boundary', () => {
    expect(diffInDays('2026-10-30', '2026-11-02')).toBe(3);
  });

  it('is negative when the second date is earlier', () => {
    expect(diffInDays('2026-11-19', '2026-11-14')).toBe(-5);
  });

  it('is zero for the same date', () => {
    expect(diffInDays('2026-11-19', '2026-11-19')).toBe(0);
  });
});

describe('weekdays', () => {
  it('numbers Monday as 0', () => {
    expect(getWeekdayIndex('2026-11-23')).toBe(0);
  });

  it('numbers Sunday as 6', () => {
    expect(getWeekdayIndex('2026-11-22')).toBe(6);
  });

  it('names the day', () => {
    expect(getWeekdayLabel('2026-11-24')).toBe('TUE');
  });

  it('reads the day of the month', () => {
    expect(getDayOfMonth('2026-11-03')).toBe(3);
  });
});

describe('getIsoWeekId', () => {
  it('starts a new week on Monday', () => {
    expect(getIsoWeekId('2026-11-23')).toBe('2026-W48');
  });

  it('keeps Sunday in the week that started on the Monday before', () => {
    expect(getIsoWeekId('2026-11-22')).toBe('2026-W47');
  });

  it('puts 1 January in week 1 when it is a Thursday', () => {
    expect(getIsoWeekId('2026-01-01')).toBe('2026-W01');
  });

  it('puts late December days in week 1 of the next year', () => {
    expect(getIsoWeekId('2025-12-29')).toBe('2026-W01');
  });

  it('puts early January days in the last week of the year before', () => {
    expect(getIsoWeekId('2027-01-03')).toBe('2026-W53');
  });

  it('pads the week number', () => {
    expect(getIsoWeek('2027-01-04')).toEqual({ year: 2027, week: 1 });
  });
});
