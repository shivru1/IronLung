/**
 * The app shell: loads the fonts, starts the background services and shows
 * the four tabs.
 *
 * A screen is created the first time its tab is opened and then kept alive,
 * so switching tabs is instant and nothing typed or scrolled is lost.
 */

import {
  BarlowCondensed_500Medium,
  BarlowCondensed_700Bold,
  BarlowCondensed_800ExtraBold,
} from '@expo-google-fonts/barlow-condensed';
import { Inter_400Regular, Inter_500Medium, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { JetBrainsMono_400Regular, JetBrainsMono_500Medium, JetBrainsMono_700Bold } from '@expo-google-fonts/jetbrains-mono';
import { useFonts } from 'expo-font';
import { StatusBar } from 'expo-status-bar';
import React, { useCallback, useEffect, useState } from 'react';
import { BackHandler, Keyboard, KeyboardAvoidingView, StyleSheet, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { startAppServices } from './src/services/appBootstrap';
import { triggerChipSelectHaptic } from './src/services/nativeAndroidService';
import { BrainDumpScreen } from './src/ui/screens/BrainDumpScreen';
import { RealTalkScreen } from './src/ui/screens/RealTalkScreen';
import { StatsScreen } from './src/ui/screens/StatsScreen';
import { TrackerScreen } from './src/ui/screens/TrackerScreen';
import { TabBar } from './src/ui/TabBar';
import type { TabKey } from './src/ui/TabBar';
import { colors, fonts } from './src/ui/theme';

const HOME_TAB: TabKey = 'tracker';

export default function App() {
  // The names on the left are the ones `theme.fonts` uses.
  const [areFontsLoaded, fontError] = useFonts({
    [fonts.display500]: BarlowCondensed_500Medium,
    [fonts.display700]: BarlowCondensed_700Bold,
    [fonts.display800]: BarlowCondensed_800ExtraBold,
    [fonts.mono400]: JetBrainsMono_400Regular,
    [fonts.mono500]: JetBrainsMono_500Medium,
    [fonts.mono700]: JetBrainsMono_700Bold,
    [fonts.body400]: Inter_400Regular,
    [fonts.body500]: Inter_500Medium,
    [fonts.body600]: Inter_600SemiBold,
  });

  const [activeTab, setActiveTab] = useState<TabKey>(HOME_TAB);
  const [openedTabs, setOpenedTabs] = useState<Record<TabKey, boolean>>({
    tracker: true,
    stats: false,
    brainDump: false,
    realTalk: false,
  });
  // Grows by one each time the gear on the Tracker is tapped.
  const [settingsRequest, setSettingsRequest] = useState(0);
  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);

  const showTab = useCallback((tab: TabKey) => {
    Keyboard.dismiss();
    setOpenedTabs((opened) => (opened[tab] ? opened : { ...opened, [tab]: true }));
    setActiveTab(tab);
  }, []);

  const onTabPress = useCallback(
    (tab: TabKey) => {
      triggerChipSelectHaptic();
      showTab(tab);
    },
    [showTab],
  );

  const openSettings = useCallback(() => {
    setSettingsRequest((count) => count + 1);
    showTab('realTalk');
  }, [showTab]);

  // Notifications, pending brain dumps, the cloud backup and the daily roll-over.
  useEffect(() => startAppServices(), []);

  // The back button returns to the Tracker first; from the Tracker it leaves the app as usual.
  useEffect(() => {
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      if (activeTab === HOME_TAB) {
        return false;
      }
      showTab(HOME_TAB);
      return true;
    });
    return () => subscription.remove();
  }, [activeTab, showTab]);

  // The tab bar steps aside while the keyboard is open, so the text being typed has room.
  useEffect(() => {
    const onShow = Keyboard.addListener('keyboardDidShow', () => setIsKeyboardOpen(true));
    const onHide = Keyboard.addListener('keyboardDidHide', () => setIsKeyboardOpen(false));
    return () => {
      onShow.remove();
      onHide.remove();
    };
  }, []);

  // If a font cannot be loaded the app still opens, with the phone's own font.
  if (!areFontsLoaded && !fontError) {
    return <View style={styles.root} />;
  }

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <KeyboardAvoidingView style={styles.root} behavior="padding">
        <View style={styles.screens}>
          <View style={activeTab === 'tracker' ? styles.screen : styles.hidden}>
            <TrackerScreen onOpenSettings={openSettings} />
          </View>
          {openedTabs.stats ? (
            <View style={activeTab === 'stats' ? styles.screen : styles.hidden}>
              <StatsScreen />
            </View>
          ) : null}
          {openedTabs.brainDump ? (
            <View style={activeTab === 'brainDump' ? styles.screen : styles.hidden}>
              <BrainDumpScreen />
            </View>
          ) : null}
          {openedTabs.realTalk ? (
            <View style={activeTab === 'realTalk' ? styles.screen : styles.hidden}>
              <RealTalkScreen settingsRequest={settingsRequest} />
            </View>
          ) : null}
        </View>
        {isKeyboardOpen ? null : <TabBar active={activeTab} onChange={onTabPress} />}
      </KeyboardAvoidingView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.obsidian,
  },
  screens: {
    flex: 1,
  },
  screen: {
    flex: 1,
  },
  hidden: {
    display: 'none',
  },
});
