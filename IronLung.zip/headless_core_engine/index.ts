/**
 * Where the app starts.
 *
 * The two lock-screen buttons are wired up here, before any screen exists,
 * because Android can start this file in the background just to deliver a tap
 * on "+1 Smoke" or "Craving Crushed".
 */

import { registerRootComponent } from 'expo';

import App from './App';
import { registerNotificationActions } from './src/services/trackerActions';

registerNotificationActions();

registerRootComponent(App);
