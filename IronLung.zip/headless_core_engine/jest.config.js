/** Runs the `*.test.ts` files (plain logic, no phone needed): `npm test`. */
module.exports = {
  preset: 'jest-expo',
  testMatch: ['**/__tests__/**/*.test.ts'],
};
